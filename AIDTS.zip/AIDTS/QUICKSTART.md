# AIDTIS Quick Start Guide

## 🚀 Complete End-to-End Command Checklist

Copy and paste these commands to run the full AIDTIS pipeline on your laptop:

### Prerequisites
- NVIDIA RTX 4060 (or compatible CUDA GPU)
- 16GB+ RAM
- 50GB+ free disk space
- Docker installed
- Python 3.9+ installed

### 1. Environment Setup

```bash
# Clone the repository
git clone <your-repo-url>
cd AIDTIS

# Create conda environment with GPU support
conda env create -f environment.yml
conda activate aidtis

# Alternative: Use pip
pip install -r requirements.txt
```

### 2. Download Datasets (Manual Step Required)

```bash
# Create data directory
mkdir -p data

# Download datasets manually from:
# NSL-KDD: https://www.unb.ca/cic/datasets/nsl.html
# CICIDS2017: https://www.unb.ca/cic/datasets/ids-2017.html
# CICIDS2018: https://www.unb.ca/cic/datasets/ids-2018.html
# UNSW-NB15: https://www.unsw.adfa.edu.au/unsw-canberra-cyber/cybersecurity/ADFA-NB15-Datasets/
# Bot-IoT: https://research.unsw.edu.au/projects/bot-iot-dataset

# Place downloaded files in data/ directory
```

### 3. Data Processing

```bash
# Parse datasets (example with NSL-KDD)
python src/data/dataset_parser.py nsl_kdd data/nsl_kdd/KDDTrain+.txt data/nsl_kdd_parsed.csv

# Create unified dataset
python -c "
import pandas as pd
from src.data.dataset_parser import DatasetParser

parser = DatasetParser('data')
# Add your dataset files here
dataset_files = {
    'nsl_kdd': ['data/nsl_kdd_parsed.csv'],
    # Add other datasets as available
}
parser.create_unified_dataset(dataset_files, 'data/unified_dataset.csv')
"

# Create train/val/test splits
python src/data/data_balancer.py data/unified_dataset.csv data/splits --balance_method none --split_method stratified
```

### 4. Feature Engineering

```bash
# Apply feature engineering
python src/utils/feature_engineering.py data/splits/train.csv data/processed/train_processed.csv --pipeline_file data/processed/feature_pipeline.pkl --mode fit_transform

# Transform validation and test sets
python src/utils/feature_engineering.py data/splits/val.csv data/processed/val_processed.csv --pipeline_file data/processed/feature_pipeline.pkl --mode transform
python src/utils/feature_engineering.py data/splits/test.csv data/processed/test_processed.csv --pipeline_file data/processed/feature_pipeline.pkl --mode transform
```

### 5. Model Training

```bash
# Train all models
python src/models/train_model.py data/processed/train_processed.csv data/processed/val_processed.csv data/processed/test_processed.csv models/

# Check training results
ls -la models/
cat models/model_comparison.csv
```

### 6. Start Services

```bash
# Option 1: Using Docker (Recommended)
make docker-up

# Option 2: Manual startup
# Terminal 1: Start API
python -m uvicorn src.api.api:app --host 0.0.0.0 --port 8000

# Terminal 2: Start Dashboard
streamlit run src/streamlit_app.py --server.port 8501 --server.address 0.0.0.0

# Terminal 3: Start Jupyter (Optional)
jupyter lab --ip 0.0.0.0 --port 8888 --no-browser --allow-root
```

### 7. Test the System

```bash
# Test API health
curl http://localhost:8000/health

# Test single prediction
curl -X POST "http://localhost:8000/predict" \
  -H "Content-Type: application/json" \
  -d '{
    "flow": {
      "src_ip": "192.168.1.100",
      "dst_ip": "10.0.0.1",
      "src_port": 12345,
      "dst_port": 80,
      "protocol": 6,
      "start_time": "2024-01-01T10:00:00",
      "end_time": "2024-01-01T10:00:01",
      "duration": 1.0,
      "total_bytes": 1024,
      "total_packets": 10,
      "avg_pkt_size": 102.4,
      "pkt_rate": 10.0,
      "mean_iat": 0.1,
      "tcp_flag_counts": "0,1,0,0,1,0,0,0"
    },
    "model_name": "random_forest"
  }'

# Test batch prediction
curl -X POST "http://localhost:8000/predict/batch" \
  -H "Content-Type: application/json" \
  -d '{
    "flows": [
      {
        "src_ip": "192.168.1.100",
        "dst_ip": "10.0.0.1",
        "src_port": 12345,
        "dst_port": 80,
        "protocol": 6,
        "start_time": "2024-01-01T10:00:00",
        "end_time": "2024-01-01T10:00:01",
        "duration": 1.0,
        "total_bytes": 1024,
        "total_packets": 10,
        "avg_pkt_size": 102.4,
        "pkt_rate": 10.0,
        "mean_iat": 0.1,
        "tcp_flag_counts": "0,1,0,0,1,0,0,0"
      }
    ],
    "model_name": "random_forest"
  }'
```

### 8. Access the Dashboard

```bash
# Open in browser
# Dashboard: http://localhost:8501
# API Docs: http://localhost:8000/docs
# Jupyter: http://localhost:8888
```

### 9. Run Notebooks (Optional)

```bash
# Convert Python notebooks to Jupyter format
jupyter nbconvert --to notebook notebooks/01_data_ingest.py --output 01_data_ingest.ipynb
jupyter nbconvert --to notebook notebooks/02_feature_engineering.py --output 02_feature_engineering.ipynb
jupyter nbconvert --to notebook notebooks/03_train_eval.py --output 03_train_eval.ipynb
jupyter nbconvert --to notebook notebooks/04_deployment_demo.py --output 04_deployment_demo.ipynb

# Open Jupyter Lab
jupyter lab
```

### 10. Generate Synthetic Data (For Testing)

```bash
# Generate synthetic PCAP files (Docker only!)
python scripts/synthetic_pcap_generator.py dos --duration 60 --packets 1000 --output test_dos.pcap

# Extract flows from synthetic PCAP
python src/data/flow_extractor.py test_dos.pcap test_flows.csv --method scapy
```

### 11. Run Tests

```bash
# Run unit tests
python -m pytest tests/ -v

# Run with coverage
python -m pytest tests/ -v --cov=src --cov-report=html

# Run linting
flake8 src/ tests/
black --check src/ tests/
isort --check-only src/ tests/
mypy src/
```

### 12. Performance Testing

```bash
# Test API performance
python -c "
import requests
import time
import json

# Test single prediction performance
start_time = time.time()
response = requests.post('http://localhost:8000/predict', json={
    'flow': {
        'src_ip': '192.168.1.100',
        'dst_ip': '10.0.0.1',
        'src_port': 12345,
        'dst_port': 80,
        'protocol': 6,
        'start_time': '2024-01-01T10:00:00',
        'end_time': '2024-01-01T10:00:01',
        'duration': 1.0,
        'total_bytes': 1024,
        'total_packets': 10,
        'avg_pkt_size': 102.4,
        'pkt_rate': 10.0,
        'mean_iat': 0.1,
        'tcp_flag_counts': '0,1,0,0,1,0,0,0'
    }
})
end_time = time.time()
print(f'Single prediction time: {end_time - start_time:.3f}s')
print(f'Response: {response.json()}')
"
```

### 13. Monitoring and Logs

```bash
# View Docker logs
make docker-logs

# View specific service logs
docker-compose logs -f api
docker-compose logs -f dashboard

# Monitor system resources
htop
nvidia-smi
```

### 14. Cleanup

```bash
# Stop all services
make docker-down

# Clean up temporary files
make clean

# Remove Docker images (optional)
docker system prune -a
```

## 🎯 Expected Outputs

After running the complete pipeline, you should have:

1. **Models**: `models/` directory with trained ML models
2. **API**: Running on http://localhost:8000
3. **Dashboard**: Running on http://localhost:8501
4. **Data**: Processed datasets in `data/processed/`
5. **Logs**: System logs in `logs/`
6. **Tests**: Test results and coverage reports

## ⚠️ Safety Reminders

- **Never run on production networks**
- **Use only in isolated Docker environments**
- **All traffic generation must be in test networks**
- **Obtain proper authorization before testing**
- **Follow local laws and regulations**

## 🆘 Troubleshooting

### Common Issues:

1. **CUDA not found**: Install CUDA 11.8 and compatible drivers
2. **Out of memory**: Reduce batch sizes or use smaller datasets
3. **Port conflicts**: Change ports in docker-compose.yml
4. **Permission errors**: Run with appropriate permissions
5. **Model loading errors**: Check model files exist in models/ directory

### Getting Help:

- Check logs: `make docker-logs`
- Run tests: `python -m pytest tests/ -v`
- Check API health: `curl http://localhost:8000/health`
- Review documentation: `README.md`

## 🚀 Next Steps

1. **Customize**: Modify models and features for your use case
2. **Scale**: Deploy to production with proper security
3. **Monitor**: Set up monitoring and alerting
4. **Extend**: Add new datasets and attack types
5. **Integrate**: Connect with existing security tools

---

**Happy Intrusion Detection! 🛡️**
