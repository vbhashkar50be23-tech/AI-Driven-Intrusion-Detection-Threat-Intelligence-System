-- AIDTIS Database Initialization Script
-- Creates tables for storing alerts, predictions, and system metadata

-- Create alerts table
CREATE TABLE IF NOT EXISTS alerts (
    id SERIAL PRIMARY KEY,
    flow_id VARCHAR(255),
    src_ip INET,
    dst_ip INET,
    src_port INTEGER,
    dst_port INTEGER,
    protocol INTEGER,
    prediction VARCHAR(100),
    confidence DECIMAL(5,4),
    model_used VARCHAR(100),
    severity VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed BOOLEAN DEFAULT FALSE
);

-- Create predictions table for storing all predictions
CREATE TABLE IF NOT EXISTS predictions (
    id SERIAL PRIMARY KEY,
    flow_id VARCHAR(255),
    src_ip INET,
    dst_ip INET,
    prediction VARCHAR(100),
    confidence DECIMAL(5,4),
    probabilities JSONB,
    model_used VARCHAR(100),
    feature_importance JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create model performance table
CREATE TABLE IF NOT EXISTS model_performance (
    id SERIAL PRIMARY KEY,
    model_name VARCHAR(100),
    accuracy DECIMAL(5,4),
    precision_score DECIMAL(5,4),
    recall_score DECIMAL(5,4),
    f1_score DECIMAL(5,4),
    roc_auc DECIMAL(5,4),
    evaluation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create system metrics table
CREATE TABLE IF NOT EXISTS system_metrics (
    id SERIAL PRIMARY KEY,
    metric_name VARCHAR(100),
    metric_value DECIMAL(10,4),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_alerts_created_at ON alerts(created_at);
CREATE INDEX IF NOT EXISTS idx_alerts_src_ip ON alerts(src_ip);
CREATE INDEX IF NOT EXISTS idx_alerts_dst_ip ON alerts(dst_ip);
CREATE INDEX IF NOT EXISTS idx_alerts_prediction ON alerts(prediction);
CREATE INDEX IF NOT EXISTS idx_alerts_severity ON alerts(severity);

CREATE INDEX IF NOT EXISTS idx_predictions_created_at ON predictions(created_at);
CREATE INDEX IF NOT EXISTS idx_predictions_src_ip ON predictions(src_ip);
CREATE INDEX IF NOT EXISTS idx_predictions_dst_ip ON predictions(dst_ip);
CREATE INDEX IF NOT EXISTS idx_predictions_model_used ON predictions(model_used);

CREATE INDEX IF NOT EXISTS idx_model_performance_model_name ON model_performance(model_name);
CREATE INDEX IF NOT EXISTS idx_model_performance_evaluation_date ON model_performance(evaluation_date);

CREATE INDEX IF NOT EXISTS idx_system_metrics_metric_name ON system_metrics(metric_name);
CREATE INDEX IF NOT EXISTS idx_system_metrics_timestamp ON system_metrics(timestamp);

-- Insert initial system metrics
INSERT INTO system_metrics (metric_name, metric_value) VALUES 
('total_predictions', 0),
('total_alerts', 0),
('false_positive_rate', 0.0),
('detection_rate', 0.0)
ON CONFLICT DO NOTHING;

-- Create views for common queries
CREATE OR REPLACE VIEW recent_alerts AS
SELECT 
    id,
    flow_id,
    src_ip,
    dst_ip,
    prediction,
    confidence,
    severity,
    created_at
FROM alerts 
WHERE created_at >= NOW() - INTERVAL '24 hours'
ORDER BY created_at DESC;

CREATE OR REPLACE VIEW top_attackers AS
SELECT 
    src_ip,
    COUNT(*) as attack_count,
    MAX(confidence) as max_confidence,
    MAX(created_at) as last_attack
FROM alerts 
WHERE prediction != 'BENIGN'
GROUP BY src_ip
ORDER BY attack_count DESC;

CREATE OR REPLACE VIEW attack_statistics AS
SELECT 
    prediction,
    COUNT(*) as count,
    AVG(confidence) as avg_confidence,
    MAX(confidence) as max_confidence,
    MIN(confidence) as min_confidence
FROM alerts 
WHERE created_at >= NOW() - INTERVAL '24 hours'
GROUP BY prediction
ORDER BY count DESC;

-- Grant permissions
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO aidtis;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO aidtis;
GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA public TO aidtis;
