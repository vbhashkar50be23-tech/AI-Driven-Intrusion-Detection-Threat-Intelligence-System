"""
Synthetic PCAP Generator for AIDTIS Testing
⚠️ SAFETY WARNING: Only use in isolated Docker networks!
"""

import os
import sys
import time
import random
import logging
from typing import List, Dict, Optional
from datetime import datetime, timedelta
import socket
import struct

# Add scapy to path
try:
    from scapy.all import *
    from scapy.layers.inet import IP, TCP, UDP, ICMP
    from scapy.layers.l2 import Ether
except ImportError:
    print("Scapy not installed. Install with: pip install scapy")
    sys.exit(1)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SyntheticPCAPGenerator:
    """
    Generate synthetic PCAP files for testing
    ⚠️ SAFETY WARNING: Only use in isolated environments!
    """
    
    def __init__(self, output_dir: str = "synthetic_pcaps"):
        """
        Initialize PCAP generator
        
        Args:
            output_dir: Directory to save generated PCAP files
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        # Safety check
        self._safety_check()
        
        # Network configuration
        self.base_src_ip = "172.20.0.100"
        self.base_dst_ip = "172.20.0.1"
        self.src_mac = "02:00:00:00:00:01"
        self.dst_mac = "02:00:00:00:00:02"
        
        # Attack patterns
        self.attack_patterns = {
            "dos": self._generate_dos_traffic,
            "probe": self._generate_probe_traffic,
            "r2l": self._generate_r2l_traffic,
            "u2r": self._generate_u2r_traffic,
            "web_attack": self._generate_web_attack_traffic,
            "bot": self._generate_bot_traffic,
            "benign": self._generate_benign_traffic
        }
    
    def _safety_check(self):
        """Perform safety checks"""
        logger.warning("⚠️ SAFETY WARNING ⚠️")
        logger.warning("This tool generates synthetic network traffic")
        logger.warning("Only use in isolated Docker networks or VMs!")
        logger.warning("Never run on production networks!")
        
        # Check if we're in a Docker container
        if not os.path.exists('/.dockerenv'):
            logger.warning("⚠️ Not running in Docker - be extra careful!")
        
        logger.info("✅ Safety check completed")
    
    def generate_pcap(self, attack_type: str, duration: int = 60, 
                     packet_count: int = 1000, filename: Optional[str] = None) -> str:
        """
        Generate synthetic PCAP file
        
        Args:
            attack_type: Type of attack to simulate
            duration: Duration in seconds
            packet_count: Number of packets to generate
            filename: Output filename (optional)
            
        Returns:
            Path to generated PCAP file
        """
        if attack_type not in self.attack_patterns:
            raise ValueError(f"Unknown attack type: {attack_type}")
        
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{attack_type}_{timestamp}.pcap"
        
        filepath = os.path.join(self.output_dir, filename)
        
        logger.info(f"Generating {attack_type} PCAP: {filepath}")
        
        # Generate packets
        packets = self.attack_patterns[attack_type](duration, packet_count)
        
        # Write to PCAP file
        wrpcap(filepath, packets)
        
        logger.info(f"Generated {len(packets)} packets in {filepath}")
        return filepath
    
    def _generate_benign_traffic(self, duration: int, packet_count: int) -> List:
        """Generate benign network traffic"""
        packets = []
        start_time = time.time()
        
        for i in range(packet_count):
            # Random source IP in allowed range
            src_ip = f"172.20.0.{random.randint(100, 200)}"
            dst_ip = f"172.20.0.{random.randint(1, 99)}"
            
            # Random ports
            src_port = random.randint(1024, 65535)
            dst_port = random.choice([80, 443, 22, 25, 53, 110, 143, 993, 995])
            
            # Random protocol
            protocol = random.choice([6, 17])  # TCP or UDP
            
            if protocol == 6:  # TCP
                packet = Ether(src=self.src_mac, dst=self.dst_mac) / \
                        IP(src=src_ip, dst=dst_ip) / \
                        TCP(sport=src_port, dport=dst_port, flags="S")
            else:  # UDP
                packet = Ether(src=self.src_mac, dst=self.dst_mac) / \
                        IP(src=src_ip, dst=dst_ip) / \
                        UDP(sport=src_port, dport=dst_port) / \
                        Raw(b"GET / HTTP/1.1\r\nHost: example.com\r\n\r\n")
            
            packets.append(packet)
            
            # Add time delay
            if i % 100 == 0:
                time.sleep(0.01)
        
        return packets
    
    def _generate_dos_traffic(self, duration: int, packet_count: int) -> List:
        """Generate DoS attack traffic"""
        packets = []
        
        # Single attacking IP
        attacker_ip = "172.20.0.100"
        target_ip = "172.20.0.1"
        
        for i in range(packet_count):
            # High packet rate
            src_port = random.randint(1024, 65535)
            
            # SYN flood
            packet = Ether(src=self.src_mac, dst=self.dst_mac) / \
                    IP(src=attacker_ip, dst=target_ip) / \
                    TCP(sport=src_port, dport=80, flags="S")
            
            packets.append(packet)
            
            # Very short delay for high rate
            if i % 1000 == 0:
                time.sleep(0.001)
        
        return packets
    
    def _generate_probe_traffic(self, duration: int, packet_count: int) -> List:
        """Generate port scanning traffic"""
        packets = []
        
        attacker_ip = "172.20.0.100"
        target_ip = "172.20.0.1"
        
        # Scan common ports
        common_ports = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 993, 995, 1723, 3389]
        
        for i in range(packet_count):
            dst_port = random.choice(common_ports)
            src_port = random.randint(1024, 65535)
            
            # SYN scan
            packet = Ether(src=self.src_mac, dst=self.dst_mac) / \
                    IP(src=attacker_ip, dst=target_ip) / \
                    TCP(sport=src_port, dport=dst_port, flags="S")
            
            packets.append(packet)
            
            # Moderate delay
            if i % 50 == 0:
                time.sleep(0.1)
        
        return packets
    
    def _generate_r2l_traffic(self, duration: int, packet_count: int) -> List:
        """Generate Remote-to-Local attack traffic"""
        packets = []
        
        attacker_ip = "172.20.0.100"
        target_ip = "172.20.0.1"
        
        for i in range(packet_count):
            # Attempt to access restricted services
            dst_port = random.choice([22, 23, 135, 139, 445, 1433, 3389])
            src_port = random.randint(1024, 65535)
            
            # Multiple connection attempts
            packet = Ether(src=self.src_mac, dst=self.dst_mac) / \
                    IP(src=attacker_ip, dst=target_ip) / \
                    TCP(sport=src_port, dport=dst_port, flags="S")
            
            packets.append(packet)
            
            # Slow and persistent
            if i % 10 == 0:
                time.sleep(0.5)
        
        return packets
    
    def _generate_u2r_traffic(self, duration: int, packet_count: int) -> List:
        """Generate User-to-Root attack traffic"""
        packets = []
        
        # Internal IP (already compromised)
        attacker_ip = "172.20.0.50"
        target_ip = "172.20.0.1"
        
        for i in range(packet_count):
            # Privilege escalation attempts
            dst_port = random.choice([22, 23, 135, 139, 445])
            src_port = random.randint(1024, 65535)
            
            # Suspicious payload
            payload = b"sudo su -" + b"A" * random.randint(10, 100)
            
            packet = Ether(src=self.src_mac, dst=self.dst_mac) / \
                    IP(src=attacker_ip, dst=target_ip) / \
                    TCP(sport=src_port, dport=dst_port, flags="PA") / \
                    Raw(payload)
            
            packets.append(packet)
            
            # Very slow
            if i % 5 == 0:
                time.sleep(1.0)
        
        return packets
    
    def _generate_web_attack_traffic(self, duration: int, packet_count: int) -> List:
        """Generate web attack traffic"""
        packets = []
        
        attacker_ip = "172.20.0.100"
        target_ip = "172.20.0.1"
        
        # Web attack payloads
        attack_payloads = [
            b"GET /admin.php?id=1' OR '1'='1 HTTP/1.1\r\nHost: target.com\r\n\r\n",
            b"GET /index.php?page=<script>alert('XSS')</script> HTTP/1.1\r\nHost: target.com\r\n\r\n",
            b"POST /login.php HTTP/1.1\r\nHost: target.com\r\nContent-Length: 100\r\n\r\nusername=admin&password=admin",
            b"GET /../../../etc/passwd HTTP/1.1\r\nHost: target.com\r\n\r\n"
        ]
        
        for i in range(packet_count):
            src_port = random.randint(1024, 65535)
            payload = random.choice(attack_payloads)
            
            packet = Ether(src=self.src_mac, dst=self.dst_mac) / \
                    IP(src=attacker_ip, dst=target_ip) / \
                    TCP(sport=src_port, dport=80, flags="PA") / \
                    Raw(payload)
            
            packets.append(packet)
            
            # Moderate delay
            if i % 20 == 0:
                time.sleep(0.2)
        
        return packets
    
    def _generate_bot_traffic(self, duration: int, packet_count: int) -> List:
        """Generate botnet traffic"""
        packets = []
        
        # Multiple bot IPs
        bot_ips = [f"172.20.0.{i}" for i in range(100, 110)]
        target_ip = "172.20.0.1"
        
        for i in range(packet_count):
            bot_ip = random.choice(bot_ips)
            src_port = random.randint(1024, 65535)
            
            # Bot communication
            payload = b"BOT_COMMAND: " + b"A" * random.randint(10, 50)
            
            packet = Ether(src=self.src_mac, dst=self.dst_mac) / \
                    IP(src=bot_ip, dst=target_ip) / \
                    TCP(sport=src_port, dport=random.choice([6667, 8080, 9999]), flags="PA") / \
                    Raw(payload)
            
            packets.append(packet)
            
            # Regular intervals
            if i % 30 == 0:
                time.sleep(0.3)
        
        return packets
    
    def generate_mixed_traffic(self, duration: int = 300, 
                             attack_ratio: float = 0.1) -> str:
        """
        Generate mixed traffic with both benign and attack patterns
        
        Args:
            duration: Duration in seconds
            attack_ratio: Ratio of attack traffic to benign traffic
            
        Returns:
            Path to generated PCAP file
        """
        logger.info(f"Generating mixed traffic (attack ratio: {attack_ratio})")
        
        all_packets = []
        total_packets = 10000
        attack_packets = int(total_packets * attack_ratio)
        benign_packets = total_packets - attack_packets
        
        # Generate benign traffic
        benign_packets_list = self._generate_benign_traffic(duration, benign_packets)
        all_packets.extend(benign_packets_list)
        
        # Generate attack traffic
        attack_types = ["dos", "probe", "r2l", "web_attack", "bot"]
        for i in range(attack_packets):
            attack_type = random.choice(attack_types)
            attack_packets_list = self.attack_patterns[attack_type](duration, 1)
            all_packets.extend(attack_packets_list)
        
        # Shuffle packets
        random.shuffle(all_packets)
        
        # Save to file
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"mixed_traffic_{timestamp}.pcap"
        filepath = os.path.join(self.output_dir, filename)
        
        wrpcap(filepath, all_packets)
        
        logger.info(f"Generated mixed traffic: {filepath}")
        return filepath

def main():
    """Main function for command-line usage"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Generate synthetic PCAP files for testing")
    parser.add_argument("attack_type", choices=["benign", "dos", "probe", "r2l", "u2r", "web_attack", "bot", "mixed"],
                       help="Type of traffic to generate")
    parser.add_argument("--duration", type=int, default=60, help="Duration in seconds")
    parser.add_argument("--packets", type=int, default=1000, help="Number of packets")
    parser.add_argument("--output", help="Output filename")
    parser.add_argument("--attack-ratio", type=float, default=0.1, help="Attack ratio for mixed traffic")
    
    args = parser.parse_args()
    
    # Safety warning
    print("⚠️ SAFETY WARNING ⚠️")
    print("This tool generates synthetic network traffic")
    print("Only use in isolated Docker networks or VMs!")
    print("Never run on production networks!")
    
    response = input("Do you understand and agree to use this safely? (yes/no): ")
    if response.lower() != "yes":
        print("Aborting for safety.")
        sys.exit(1)
    
    # Generate PCAP
    generator = SyntheticPCAPGenerator()
    
    if args.attack_type == "mixed":
        filepath = generator.generate_mixed_traffic(args.duration, args.attack_ratio)
    else:
        filepath = generator.generate_pcap(args.attack_type, args.duration, args.packets, args.output)
    
    print(f"Generated PCAP file: {filepath}")
    print("You can now use this file for testing AIDTIS flow extraction and prediction.")

if __name__ == "__main__":
    main()
