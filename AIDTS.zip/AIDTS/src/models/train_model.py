"""
Model Training Pipeline for Intrusion Detection
Supports supervised and unsupervised learning approaches
"""

import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Tuple, Optional, Any, Union
from pathlib import Path
import joblib
import pickle
import json
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# ML Libraries
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.model_selection import cross_val_score, GridSearchCV, RandomizedSearchCV
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_auc_score, 
    precision_recall_curve, roc_curve, accuracy_score,
    precision_score, recall_score, f1_score
)
from sklearn.preprocessing import LabelEncoder
import xgboost as xgb
import lightgbm as lgb
from pyod.models.auto_encoder import AutoEncoder
from pyod.models.lof import LOF
from pyod.models.ocsvm import OCSVM

# Deep Learning
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import optuna

# Visualization
import matplotlib.pyplot as plt
import seaborn as sns

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class IntrusionDetectionModel:
    """
    Base class for intrusion detection models
    """
    
    def __init__(self, model_type: str, config: Optional[Dict] = None):
        """
        Initialize model
        
        Args:
            model_type: Type of model ('supervised' or 'unsupervised')
            config: Model configuration
        """
        self.model_type = model_type
        self.config = config or {}
        self.model = None
        self.label_encoder = None
        self.feature_names = []
        self.is_fitted = False
        self.training_history = {}
        
    def fit(self, X: pd.DataFrame, y: Optional[pd.Series] = None) -> 'IntrusionDetectionModel':
        """Fit the model"""
        raise NotImplementedError
    
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Make predictions"""
        raise NotImplementedError
    
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Predict probabilities"""
        raise NotImplementedError
    
    def save_model(self, filepath: str):
        """Save the trained model"""
        raise NotImplementedError
    
    def load_model(self, filepath: str):
        """Load a trained model"""
        raise NotImplementedError

class SupervisedModel(IntrusionDetectionModel):
    """
    Supervised learning models for intrusion detection
    """
    
    def __init__(self, algorithm: str = 'random_forest', config: Optional[Dict] = None):
        """
        Initialize supervised model
        
        Args:
            algorithm: Algorithm to use ('random_forest', 'xgboost', 'lightgbm')
            config: Model configuration
        """
        super().__init__('supervised', config)
        self.algorithm = algorithm
        self.model = self._create_model()
        
    def _create_model(self):
        """Create model based on algorithm"""
        if self.algorithm == 'random_forest':
            return RandomForestClassifier(
                n_estimators=self.config.get('n_estimators', 100),
                max_depth=self.config.get('max_depth', None),
                min_samples_split=self.config.get('min_samples_split', 2),
                min_samples_leaf=self.config.get('min_samples_leaf', 1),
                random_state=self.config.get('random_state', 42),
                n_jobs=self.config.get('n_jobs', -1)
            )
        elif self.algorithm == 'xgboost':
            return xgb.XGBClassifier(
                n_estimators=self.config.get('n_estimators', 100),
                max_depth=self.config.get('max_depth', 6),
                learning_rate=self.config.get('learning_rate', 0.1),
                subsample=self.config.get('subsample', 0.8),
                colsample_bytree=self.config.get('colsample_bytree', 0.8),
                random_state=self.config.get('random_state', 42),
                n_jobs=self.config.get('n_jobs', -1)
            )
        elif self.algorithm == 'lightgbm':
            return lgb.LGBMClassifier(
                n_estimators=self.config.get('n_estimators', 100),
                max_depth=self.config.get('max_depth', 6),
                learning_rate=self.config.get('learning_rate', 0.1),
                subsample=self.config.get('subsample', 0.8),
                colsample_bytree=self.config.get('colsample_bytree', 0.8),
                random_state=self.config.get('random_state', 42),
                n_jobs=self.config.get('n_jobs', -1),
                verbose=-1
            )
        else:
            raise ValueError(f"Unknown algorithm: {self.algorithm}")
    
    def fit(self, X: pd.DataFrame, y: pd.Series) -> 'SupervisedModel':
        """Fit the supervised model"""
        logger.info(f"Training {self.algorithm} model")
        
        # Store feature names
        self.feature_names = X.columns.tolist()
        
        # Encode labels
        self.label_encoder = LabelEncoder()
        y_encoded = self.label_encoder.fit_transform(y)
        
        # Train model
        self.model.fit(X, y_encoded)
        self.is_fitted = True
        
        logger.info(f"Model training completed")
        return self
    
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Make predictions"""
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction")
        
        predictions = self.model.predict(X)
        return self.label_encoder.inverse_transform(predictions)
    
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Predict probabilities"""
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction")
        
        return self.model.predict_proba(X)
    
    def save_model(self, filepath: str):
        """Save the trained model"""
        model_data = {
            'model': self.model,
            'label_encoder': self.label_encoder,
            'feature_names': self.feature_names,
            'algorithm': self.algorithm,
            'config': self.config,
            'is_fitted': self.is_fitted
        }
        
        joblib.dump(model_data, filepath)
        logger.info(f"Saved model to {filepath}")
    
    def load_model(self, filepath: str):
        """Load a trained model"""
        model_data = joblib.load(filepath)
        
        self.model = model_data['model']
        self.label_encoder = model_data['label_encoder']
        self.feature_names = model_data['feature_names']
        self.algorithm = model_data['algorithm']
        self.config = model_data['config']
        self.is_fitted = model_data['is_fitted']
        
        logger.info(f"Loaded model from {filepath}")

class UnsupervisedModel(IntrusionDetectionModel):
    """
    Unsupervised learning models for anomaly detection
    """
    
    def __init__(self, algorithm: str = 'isolation_forest', config: Optional[Dict] = None):
        """
        Initialize unsupervised model
        
        Args:
            algorithm: Algorithm to use ('isolation_forest', 'autoencoder', 'lof', 'ocsvm')
            config: Model configuration
        """
        super().__init__('unsupervised', config)
        self.algorithm = algorithm
        self.model = self._create_model()
        
    def _create_model(self):
        """Create model based on algorithm"""
        if self.algorithm == 'isolation_forest':
            return IsolationForest(
                n_estimators=self.config.get('n_estimators', 100),
                contamination=self.config.get('contamination', 0.1),
                random_state=self.config.get('random_state', 42),
                n_jobs=self.config.get('n_jobs', -1)
            )
        elif self.algorithm == 'autoencoder':
            return AutoEncoder(
                hidden_neurons=self.config.get('hidden_neurons', [64, 32, 16, 32, 64]),
                contamination=self.config.get('contamination', 0.1),
                epochs=self.config.get('epochs', 100),
                batch_size=self.config.get('batch_size', 32),
                learning_rate=self.config.get('learning_rate', 0.001),
                random_state=self.config.get('random_state', 42)
            )
        elif self.algorithm == 'lof':
            return LOF(
                n_neighbors=self.config.get('n_neighbors', 20),
                contamination=self.config.get('contamination', 0.1)
            )
        elif self.algorithm == 'ocsvm':
            return OCSVM(
                kernel=self.config.get('kernel', 'rbf'),
                nu=self.config.get('nu', 0.1),
                gamma=self.config.get('gamma', 'scale')
            )
        else:
            raise ValueError(f"Unknown algorithm: {self.algorithm}")
    
    def fit(self, X: pd.DataFrame, y: Optional[pd.Series] = None) -> 'UnsupervisedModel':
        """Fit the unsupervised model"""
        logger.info(f"Training {self.algorithm} model")
        
        # Store feature names
        self.feature_names = X.columns.tolist()
        
        # Train model (unsupervised, so no labels needed)
        self.model.fit(X)
        self.is_fitted = True
        
        logger.info(f"Model training completed")
        return self
    
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Make predictions (1 for normal, -1 for anomaly)"""
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction")
        
        predictions = self.model.predict(X)
        return predictions
    
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Predict anomaly scores"""
        if not self.is_fitted:
            raise ValueError("Model must be fitted before prediction")
        
        if hasattr(self.model, 'decision_function'):
            scores = self.model.decision_function(X)
            # Convert to probabilities (higher score = more normal)
            probabilities = 1 / (1 + np.exp(-scores))
            return np.column_stack([probabilities, 1 - probabilities])
        else:
            # For models without decision_function, use predict
            predictions = self.model.predict(X)
            probabilities = np.where(predictions == 1, 0.9, 0.1)
            return np.column_stack([probabilities, 1 - probabilities])
    
    def save_model(self, filepath: str):
        """Save the trained model"""
        model_data = {
            'model': self.model,
            'feature_names': self.feature_names,
            'algorithm': self.algorithm,
            'config': self.config,
            'is_fitted': self.is_fitted
        }
        
        joblib.dump(model_data, filepath)
        logger.info(f"Saved model to {filepath}")
    
    def load_model(self, filepath: str):
        """Load a trained model"""
        model_data = joblib.load(filepath)
        
        self.model = model_data['model']
        self.feature_names = model_data['feature_names']
        self.algorithm = model_data['algorithm']
        self.config = model_data['config']
        self.is_fitted = model_data['is_fitted']
        
        logger.info(f"Loaded model from {filepath}")

class LSTMModel(nn.Module):
    """
    LSTM model for sequence-based intrusion detection
    """
    
    def __init__(self, input_size: int, hidden_size: int = 64, num_layers: int = 2, 
                 num_classes: int = 2, dropout: float = 0.2):
        super(LSTMModel, self).__init__()
        
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, 
                           batch_first=True, dropout=dropout)
        self.fc = nn.Linear(hidden_size, num_classes)
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, x):
        # Initialize hidden state
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        
        # LSTM forward pass
        out, _ = self.lstm(x, (h0, c0))
        
        # Take the last output
        out = self.dropout(out[:, -1, :])
        out = self.fc(out)
        
        return out

class ModelTrainer:
    """
    Model training and evaluation pipeline
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize model trainer
        
        Args:
            config: Training configuration
        """
        self.config = config or self._default_config()
        self.models = {}
        self.results = {}
        
    def _default_config(self) -> Dict:
        """Default training configuration"""
        return {
            'supervised_algorithms': ['random_forest', 'xgboost', 'lightgbm'],
            'unsupervised_algorithms': ['isolation_forest', 'autoencoder'],
            'hyperparameter_tuning': True,
            'cv_folds': 5,
            'random_state': 42,
            'test_size': 0.2,
            'val_size': 0.1,
            'n_trials': 50,  # For Optuna
            'output_dir': 'models'
        }
    
    def train_supervised_models(self, X_train: pd.DataFrame, y_train: pd.Series,
                              X_val: pd.DataFrame, y_val: pd.Series) -> Dict[str, SupervisedModel]:
        """Train supervised models"""
        logger.info("Training supervised models")
        
        trained_models = {}
        
        for algorithm in self.config['supervised_algorithms']:
            logger.info(f"Training {algorithm}")
            
            # Create model
            model = SupervisedModel(algorithm)
            
            # Hyperparameter tuning if enabled
            if self.config['hyperparameter_tuning']:
                model = self._tune_hyperparameters(model, X_train, y_train, X_val, y_val)
            
            # Train final model
            model.fit(X_train, y_train)
            
            # Evaluate
            val_predictions = model.predict(X_val)
            val_accuracy = accuracy_score(y_val, val_predictions)
            
            logger.info(f"{algorithm} validation accuracy: {val_accuracy:.4f}")
            
            trained_models[algorithm] = model
        
        return trained_models
    
    def train_unsupervised_models(self, X_train: pd.DataFrame, 
                                X_val: pd.DataFrame, y_val: pd.Series) -> Dict[str, UnsupervisedModel]:
        """Train unsupervised models"""
        logger.info("Training unsupervised models")
        
        trained_models = {}
        
        for algorithm in self.config['unsupervised_algorithms']:
            logger.info(f"Training {algorithm}")
            
            # Create model
            model = UnsupervisedModel(algorithm)
            
            # Train model
            model.fit(X_train)
            
            # Evaluate (convert labels to binary: BENIGN=1, others=-1)
            y_val_binary = np.where(y_val == 'BENIGN', 1, -1)
            val_predictions = model.predict(X_val)
            val_accuracy = accuracy_score(y_val_binary, val_predictions)
            
            logger.info(f"{algorithm} validation accuracy: {val_accuracy:.4f}")
            
            trained_models[algorithm] = model
        
        return trained_models
    
    def _tune_hyperparameters(self, model: IntrusionDetectionModel, 
                            X_train: pd.DataFrame, y_train: pd.Series,
                            X_val: pd.DataFrame, y_val: pd.Series) -> IntrusionDetectionModel:
        """Tune hyperparameters using Optuna"""
        logger.info(f"Tuning hyperparameters for {model.algorithm}")
        
        def objective(trial):
            # Suggest hyperparameters based on algorithm
            if model.algorithm == 'random_forest':
                config = {
                    'n_estimators': trial.suggest_int('n_estimators', 50, 200),
                    'max_depth': trial.suggest_int('max_depth', 5, 20),
                    'min_samples_split': trial.suggest_int('min_samples_split', 2, 10),
                    'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 5)
                }
            elif model.algorithm == 'xgboost':
                config = {
                    'n_estimators': trial.suggest_int('n_estimators', 50, 200),
                    'max_depth': trial.suggest_int('max_depth', 3, 10),
                    'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3),
                    'subsample': trial.suggest_float('subsample', 0.6, 1.0),
                    'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0)
                }
            elif model.algorithm == 'lightgbm':
                config = {
                    'n_estimators': trial.suggest_int('n_estimators', 50, 200),
                    'max_depth': trial.suggest_int('max_depth', 3, 10),
                    'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3),
                    'subsample': trial.suggest_float('subsample', 0.6, 1.0),
                    'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0)
                }
            else:
                return 0.0
            
            # Create model with suggested config
            tuned_model = SupervisedModel(model.algorithm, config)
            tuned_model.fit(X_train, y_train)
            
            # Evaluate
            val_predictions = tuned_model.predict(X_val)
            accuracy = accuracy_score(y_val, val_predictions)
            
            return accuracy
        
        # Run optimization
        study = optuna.create_study(direction='maximize')
        study.optimize(objective, n_trials=self.config['n_trials'])
        
        # Get best parameters
        best_params = study.best_params
        logger.info(f"Best parameters for {model.algorithm}: {best_params}")
        
        # Create model with best parameters
        best_model = SupervisedModel(model.algorithm, best_params)
        return best_model
    
    def evaluate_models(self, models: Dict[str, IntrusionDetectionModel], 
                       X_test: pd.DataFrame, y_test: pd.Series) -> Dict[str, Dict]:
        """Evaluate all models"""
        logger.info("Evaluating models")
        
        results = {}
        
        for name, model in models.items():
            logger.info(f"Evaluating {name}")
            
            # Make predictions
            predictions = model.predict(X_test)
            probabilities = model.predict_proba(X_test)
            
            # Calculate metrics
            if model.model_type == 'supervised':
                # Multi-class metrics
                accuracy = accuracy_score(y_test, predictions)
                precision = precision_score(y_test, predictions, average='weighted')
                recall = recall_score(y_test, predictions, average='weighted')
                f1 = f1_score(y_test, predictions, average='weighted')
                
                # ROC AUC (multi-class)
                try:
                    roc_auc = roc_auc_score(y_test, probabilities, multi_class='ovr')
                except:
                    roc_auc = 0.0
                
            else:
                # Binary metrics (convert to binary)
                y_test_binary = np.where(y_test == 'BENIGN', 1, -1)
                accuracy = accuracy_score(y_test_binary, predictions)
                precision = precision_score(y_test_binary, predictions, average='weighted')
                recall = recall_score(y_test_binary, predictions, average='weighted')
                f1 = f1_score(y_test_binary, predictions, average='weighted')
                roc_auc = 0.0  # Not applicable for unsupervised
            
            results[name] = {
                'accuracy': accuracy,
                'precision': precision,
                'recall': recall,
                'f1': f1,
                'roc_auc': roc_auc,
                'predictions': predictions,
                'probabilities': probabilities
            }
            
            logger.info(f"{name} - Accuracy: {accuracy:.4f}, F1: {f1:.4f}")
        
        return results
    
    def save_models(self, models: Dict[str, IntrusionDetectionModel], output_dir: str):
        """Save all trained models"""
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        for name, model in models.items():
            model_path = output_path / f"{name}_model.joblib"
            model.save_model(str(model_path))
        
        logger.info(f"Saved {len(models)} models to {output_dir}")
    
    def create_evaluation_report(self, results: Dict[str, Dict], output_dir: str):
        """Create evaluation report with visualizations"""
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        # Create summary table
        summary_data = []
        for name, metrics in results.items():
            summary_data.append({
                'Model': name,
                'Accuracy': metrics['accuracy'],
                'Precision': metrics['precision'],
                'Recall': metrics['recall'],
                'F1-Score': metrics['f1'],
                'ROC-AUC': metrics['roc_auc']
            })
        
        summary_df = pd.DataFrame(summary_data)
        summary_df.to_csv(output_path / 'model_comparison.csv', index=False)
        
        # Create visualizations
        self._create_metrics_plot(summary_df, output_path)
        
        # Save detailed results
        with open(output_path / 'detailed_results.json', 'w') as f:
            # Convert numpy arrays to lists for JSON serialization
            json_results = {}
            for name, metrics in results.items():
                json_results[name] = {
                    'accuracy': float(metrics['accuracy']),
                    'precision': float(metrics['precision']),
                    'recall': float(metrics['recall']),
                    'f1': float(metrics['f1']),
                    'roc_auc': float(metrics['roc_auc'])
                }
            json.dump(json_results, f, indent=2)
        
        logger.info(f"Created evaluation report in {output_dir}")
    
    def _create_metrics_plot(self, summary_df: pd.DataFrame, output_path: Path):
        """Create metrics comparison plot"""
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        metrics = ['Accuracy', 'Precision', 'Recall', 'F1-Score']
        
        for i, metric in enumerate(metrics):
            ax = axes[i // 2, i % 2]
            summary_df.plot(x='Model', y=metric, kind='bar', ax=ax, legend=False)
            ax.set_title(f'{metric} Comparison')
            ax.set_ylabel(metric)
            ax.tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        plt.savefig(output_path / 'metrics_comparison.png', dpi=300, bbox_inches='tight')
        plt.close()

def train_intrusion_detection_models(train_file: str, val_file: str, test_file: str,
                                   output_dir: str, config: Optional[Dict] = None) -> Dict[str, Dict]:
    """
    Complete training pipeline for intrusion detection models
    
    Args:
        train_file: Path to training data
        val_file: Path to validation data
        test_file: Path to test data
        output_dir: Output directory for models and results
        config: Training configuration
        
    Returns:
        Dictionary with evaluation results
    """
    logger.info("Starting intrusion detection model training")
    
    # Load data
    train_df = pd.read_csv(train_file)
    val_df = pd.read_csv(val_file)
    test_df = pd.read_csv(test_file)
    
    logger.info(f"Loaded data - Train: {len(train_df)}, Val: {len(val_df)}, Test: {len(test_df)}")
    
    # Separate features and labels
    feature_columns = [col for col in train_df.columns if col not in ['flow_id', 'label']]
    
    X_train = train_df[feature_columns]
    y_train = train_df['label']
    X_val = val_df[feature_columns]
    y_val = val_df['label']
    X_test = test_df[feature_columns]
    y_test = test_df['label']
    
    # Create trainer
    trainer = ModelTrainer(config)
    
    # Train supervised models
    supervised_models = trainer.train_supervised_models(X_train, y_train, X_val, y_val)
    
    # Train unsupervised models
    unsupervised_models = trainer.train_unsupervised_models(X_train, X_val, y_val)
    
    # Combine all models
    all_models = {**supervised_models, **unsupervised_models}
    
    # Evaluate models
    results = trainer.evaluate_models(all_models, X_test, y_test)
    
    # Save models and results
    trainer.save_models(all_models, output_dir)
    trainer.create_evaluation_report(results, output_dir)
    
    logger.info("Model training completed")
    return results

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Train intrusion detection models")
    parser.add_argument("train_file", help="Training data CSV file")
    parser.add_argument("val_file", help="Validation data CSV file")
    parser.add_argument("test_file", help="Test data CSV file")
    parser.add_argument("output_dir", help="Output directory for models and results")
    parser.add_argument("--config", help="Configuration JSON file")
    
    args = parser.parse_args()
    
    # Load config if provided
    config = None
    if args.config:
        with open(args.config, 'r') as f:
            config = json.load(f)
    
    # Train models
    results = train_intrusion_detection_models(
        args.train_file, args.val_file, args.test_file, args.output_dir, config
    )
    
    print("Training completed successfully!")
    print(f"Results saved to {args.output_dir}")
