"""
FastAPI Inference Service for AIDTIS
Provides REST API endpoints for intrusion detection
"""

import os
import json
import logging
import asyncio
from typing import Dict, List, Optional, Any, Union
from datetime import datetime
from pathlib import Path
import pandas as pd
import numpy as np
from fastapi import FastAPI, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel, Field
import uvicorn
import joblib
import pickle
from contextlib import asynccontextmanager

# Import our models and utilities
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from models.train_model import SupervisedModel, UnsupervisedModel
from utils.feature_engineering import FeatureEngineer
from data.flow_extractor import FlowExtractor

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global variables for models and feature engineer
models = {}
feature_engineer = None
config = {}

class FlowData(BaseModel):
    """Single flow data model"""
    flow_id: Optional[str] = None
    src_ip: str = Field(..., description="Source IP address")
    dst_ip: str = Field(..., description="Destination IP address")
    src_port: int = Field(..., description="Source port")
    dst_port: int = Field(..., description="Destination port")
    protocol: int = Field(..., description="Protocol number")
    start_time: str = Field(..., description="Start time (ISO format)")
    end_time: str = Field(..., description="End time (ISO format)")
    duration: float = Field(..., description="Flow duration in seconds")
    total_bytes: int = Field(..., description="Total bytes")
    total_packets: int = Field(..., description="Total packets")
    avg_pkt_size: float = Field(..., description="Average packet size")
    pkt_rate: float = Field(..., description="Packet rate")
    mean_iat: float = Field(..., description="Mean inter-arrival time")
    tcp_flag_counts: str = Field(default="0,0,0,0,0,0,0,0", description="TCP flags")

class PredictionRequest(BaseModel):
    """Prediction request model"""
    flow: FlowData
    model_name: Optional[str] = Field(default="random_forest", description="Model to use for prediction")

class BatchPredictionRequest(BaseModel):
    """Batch prediction request model"""
    flows: List[FlowData]
    model_name: Optional[str] = Field(default="random_forest", description="Model to use for prediction")

class PredictionResponse(BaseModel):
    """Prediction response model"""
    flow_id: Optional[str]
    prediction: str
    confidence: float
    probabilities: Dict[str, float]
    model_used: str
    timestamp: str
    feature_importance: Optional[Dict[str, float]] = None

class BatchPredictionResponse(BaseModel):
    """Batch prediction response model"""
    predictions: List[PredictionResponse]
    total_flows: int
    processing_time: float
    model_used: str

class HealthResponse(BaseModel):
    """Health check response model"""
    status: str
    timestamp: str
    models_loaded: List[str]
    version: str

class ModelInfo(BaseModel):
    """Model information model"""
    name: str
    type: str
    algorithm: str
    is_fitted: bool
    feature_count: int
    classes: Optional[List[str]] = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    # Startup
    logger.info("Starting AIDTIS API service")
    await load_models()
    yield
    # Shutdown
    logger.info("Shutting down AIDTIS API service")

# Create FastAPI app
app = FastAPI(
    title="AIDTIS - AI-Driven Intrusion Detection & Threat Intelligence System",
    description="REST API for real-time intrusion detection and threat analysis",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

async def load_models():
    """Load trained models and feature engineering pipeline"""
    global models, feature_engineer, config
    
    try:
        # Load configuration
        config_path = Path("config/api_config.json")
        if config_path.exists():
            with open(config_path, 'r') as f:
                config = json.load(f)
        else:
            config = {
                "models_dir": "models",
                "feature_pipeline_path": "models/feature_pipeline.pkl",
                "default_model": "random_forest",
                "max_batch_size": 1000,
                "supported_models": ["random_forest", "xgboost", "lightgbm", "isolation_forest", "autoencoder"]
            }
        
        models_dir = Path(config["models_dir"])
        if not models_dir.exists():
            logger.warning(f"Models directory {models_dir} does not exist")
            return
        
        # Load feature engineering pipeline
        feature_pipeline_path = Path(config["feature_pipeline_path"])
        if feature_pipeline_path.exists():
            feature_engineer = FeatureEngineer()
            feature_engineer.load_pipeline(str(feature_pipeline_path))
            logger.info("Loaded feature engineering pipeline")
        else:
            logger.warning(f"Feature pipeline {feature_pipeline_path} not found")
        
        # Load models
        model_files = list(models_dir.glob("*_model.joblib"))
        for model_file in model_files:
            model_name = model_file.stem.replace("_model", "")
            
            try:
                if "isolation_forest" in model_name or "autoencoder" in model_name:
                    model = UnsupervisedModel()
                else:
                    model = SupervisedModel()
                
                model.load_model(str(model_file))
                models[model_name] = model
                logger.info(f"Loaded model: {model_name}")
                
            except Exception as e:
                logger.error(f"Failed to load model {model_name}: {e}")
        
        logger.info(f"Loaded {len(models)} models")
        
    except Exception as e:
        logger.error(f"Error loading models: {e}")

def flow_data_to_dataframe(flow_data: Union[FlowData, List[FlowData]]) -> pd.DataFrame:
    """Convert flow data to DataFrame"""
    if isinstance(flow_data, FlowData):
        flow_dict = flow_data.dict()
    else:
        flow_dict = [flow.dict() for flow in flow_data]
    
    df = pd.DataFrame([flow_dict] if isinstance(flow_dict, dict) else flow_dict)
    
    # Convert time columns
    for col in ['start_time', 'end_time']:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col])
    
    return df

def get_feature_importance(model, X: pd.DataFrame) -> Optional[Dict[str, float]]:
    """Get feature importance from model"""
    try:
        if hasattr(model.model, 'feature_importances_'):
            importances = model.model.feature_importances_
            feature_names = model.feature_names if hasattr(model, 'feature_names') else X.columns.tolist()
            
            # Get top 10 most important features
            importance_dict = dict(zip(feature_names, importances))
            sorted_importance = dict(sorted(importance_dict.items(), key=lambda x: x[1], reverse=True)[:10])
            
            return sorted_importance
    except Exception as e:
        logger.warning(f"Could not get feature importance: {e}")
    
    return None

@app.get("/", response_model=Dict[str, str])
async def root():
    """Root endpoint"""
    return {
        "message": "AIDTIS - AI-Driven Intrusion Detection & Threat Intelligence System",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health"
    }

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        timestamp=datetime.now().isoformat(),
        models_loaded=list(models.keys()),
        version="1.0.0"
    )

@app.get("/models", response_model=List[ModelInfo])
async def list_models():
    """List available models"""
    model_info = []
    
    for name, model in models.items():
        info = ModelInfo(
            name=name,
            type=model.model_type,
            algorithm=model.algorithm if hasattr(model, 'algorithm') else 'unknown',
            is_fitted=model.is_fitted,
            feature_count=len(model.feature_names) if hasattr(model, 'feature_names') else 0
        )
        
        # Add classes for supervised models
        if model.model_type == 'supervised' and hasattr(model, 'label_encoder'):
            info.classes = model.label_encoder.classes_.tolist()
        
        model_info.append(info)
    
    return model_info

@app.post("/predict", response_model=PredictionResponse)
async def predict_single_flow(request: PredictionRequest):
    """Predict single flow"""
    try:
        # Validate model
        model_name = request.model_name or config.get("default_model", "random_forest")
        if model_name not in models:
            raise HTTPException(status_code=400, detail=f"Model {model_name} not found")
        
        model = models[model_name]
        
        # Convert flow data to DataFrame
        df = flow_data_to_dataframe(request.flow)
        
        # Apply feature engineering
        if feature_engineer:
            df = feature_engineer.transform(df)
        
        # Select features used by model
        if hasattr(model, 'feature_names'):
            available_features = [col for col in model.feature_names if col in df.columns]
            if not available_features:
                raise HTTPException(status_code=400, detail="No matching features found")
            X = df[available_features]
        else:
            X = df.select_dtypes(include=[np.number])
        
        # Make prediction
        start_time = datetime.now()
        prediction = model.predict(X)[0]
        probabilities = model.predict_proba(X)[0]
        end_time = datetime.now()
        
        # Get confidence (max probability)
        confidence = float(np.max(probabilities))
        
        # Convert probabilities to dictionary
        if model.model_type == 'supervised' and hasattr(model, 'label_encoder'):
            prob_dict = dict(zip(model.label_encoder.classes_, probabilities))
        else:
            prob_dict = {"normal": float(probabilities[0]), "anomaly": float(probabilities[1])}
        
        # Get feature importance
        feature_importance = get_feature_importance(model, X)
        
        return PredictionResponse(
            flow_id=request.flow.flow_id,
            prediction=str(prediction),
            confidence=confidence,
            probabilities=prob_dict,
            model_used=model_name,
            timestamp=datetime.now().isoformat(),
            feature_importance=feature_importance
        )
        
    except Exception as e:
        logger.error(f"Error in prediction: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/predict/batch", response_model=BatchPredictionResponse)
async def predict_batch_flows(request: BatchPredictionRequest):
    """Predict batch of flows"""
    try:
        # Validate model
        model_name = request.model_name or config.get("default_model", "random_forest")
        if model_name not in models:
            raise HTTPException(status_code=400, detail=f"Model {model_name} not found")
        
        model = models[model_name]
        
        # Check batch size
        max_batch_size = config.get("max_batch_size", 1000)
        if len(request.flows) > max_batch_size:
            raise HTTPException(status_code=400, detail=f"Batch size exceeds maximum of {max_batch_size}")
        
        # Convert flow data to DataFrame
        df = flow_data_to_dataframe(request.flows)
        
        # Apply feature engineering
        if feature_engineer:
            df = feature_engineer.transform(df)
        
        # Select features used by model
        if hasattr(model, 'feature_names'):
            available_features = [col for col in model.feature_names if col in df.columns]
            if not available_features:
                raise HTTPException(status_code=400, detail="No matching features found")
            X = df[available_features]
        else:
            X = df.select_dtypes(include=[np.number])
        
        # Make predictions
        start_time = datetime.now()
        predictions = model.predict(X)
        probabilities = model.predict_proba(X)
        end_time = datetime.now()
        
        # Create response
        prediction_responses = []
        for i, (pred, probs) in enumerate(zip(predictions, probabilities)):
            confidence = float(np.max(probs))
            
            # Convert probabilities to dictionary
            if model.model_type == 'supervised' and hasattr(model, 'label_encoder'):
                prob_dict = dict(zip(model.label_encoder.classes_, probs))
            else:
                prob_dict = {"normal": float(probs[0]), "anomaly": float(probs[1])}
            
            # Get feature importance for first few samples
            feature_importance = None
            if i < 5:  # Only for first 5 samples to avoid performance issues
                feature_importance = get_feature_importance(model, X.iloc[[i]])
            
            prediction_responses.append(PredictionResponse(
                flow_id=request.flows[i].flow_id,
                prediction=str(pred),
                confidence=confidence,
                probabilities=prob_dict,
                model_used=model_name,
                timestamp=datetime.now().isoformat(),
                feature_importance=feature_importance
            ))
        
        processing_time = (end_time - start_time).total_seconds()
        
        return BatchPredictionResponse(
            predictions=prediction_responses,
            total_flows=len(request.flows),
            processing_time=processing_time,
            model_used=model_name
        )
        
    except Exception as e:
        logger.error(f"Error in batch prediction: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/predict/csv", response_model=BatchPredictionResponse)
async def predict_csv_file(file: UploadFile = File(...), model_name: str = "random_forest"):
    """Predict from uploaded CSV file"""
    try:
        # Validate model
        if model_name not in models:
            raise HTTPException(status_code=400, detail=f"Model {model_name} not found")
        
        model = models[model_name]
        
        # Read CSV file
        content = await file.read()
        df = pd.read_csv(pd.io.common.StringIO(content.decode('utf-8')))
        
        # Check batch size
        max_batch_size = config.get("max_batch_size", 1000)
        if len(df) > max_batch_size:
            raise HTTPException(status_code=400, detail=f"File size exceeds maximum of {max_batch_size} rows")
        
        # Apply feature engineering
        if feature_engineer:
            df = feature_engineer.transform(df)
        
        # Select features used by model
        if hasattr(model, 'feature_names'):
            available_features = [col for col in model.feature_names if col in df.columns]
            if not available_features:
                raise HTTPException(status_code=400, detail="No matching features found")
            X = df[available_features]
        else:
            X = df.select_dtypes(include=[np.number])
        
        # Make predictions
        start_time = datetime.now()
        predictions = model.predict(X)
        probabilities = model.predict_proba(X)
        end_time = datetime.now()
        
        # Create response
        prediction_responses = []
        for i, (pred, probs) in enumerate(zip(predictions, probabilities)):
            confidence = float(np.max(probs))
            
            # Convert probabilities to dictionary
            if model.model_type == 'supervised' and hasattr(model, 'label_encoder'):
                prob_dict = dict(zip(model.label_encoder.classes_, probs))
            else:
                prob_dict = {"normal": float(probs[0]), "anomaly": float(probs[1])}
            
            prediction_responses.append(PredictionResponse(
                flow_id=str(i),
                prediction=str(pred),
                confidence=confidence,
                probabilities=prob_dict,
                model_used=model_name,
                timestamp=datetime.now().isoformat()
            ))
        
        processing_time = (end_time - start_time).total_seconds()
        
        return BatchPredictionResponse(
            predictions=prediction_responses,
            total_flows=len(df),
            processing_time=processing_time,
            model_used=model_name
        )
        
    except Exception as e:
        logger.error(f"Error in CSV prediction: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/ingest/pcap")
async def ingest_pcap_file(file: UploadFile = File(...), model_name: str = "random_forest"):
    """Ingest PCAP file and return predictions (DEV MODE ONLY)"""
    # Safety check - only allow in development mode
    if os.getenv("AIDTIS_MODE", "dev") != "dev":
        raise HTTPException(status_code=403, detail="PCAP ingestion only available in development mode")
    
    try:
        # Validate model
        if model_name not in models:
            raise HTTPException(status_code=400, detail=f"Model {model_name} not found")
        
        model = models[model_name]
        
        # Save uploaded file temporarily
        temp_pcap_path = f"temp_{file.filename}"
        with open(temp_pcap_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)
        
        # Extract flows from PCAP
        temp_flows_path = "temp_flows.csv"
        extractor = FlowExtractor()
        
        # Use dpkt method for better compatibility
        flows = extractor.extract_flows_dpkt(temp_pcap_path)
        
        if not flows:
            raise HTTPException(status_code=400, detail="No flows extracted from PCAP")
        
        # Save flows to CSV
        extractor.save_flows_to_csv(flows, temp_flows_path)
        
        # Load flows as DataFrame
        df = pd.read_csv(temp_flows_path)
        
        # Apply feature engineering
        if feature_engineer:
            df = feature_engineer.transform(df)
        
        # Select features used by model
        if hasattr(model, 'feature_names'):
            available_features = [col for col in model.feature_names if col in df.columns]
            if not available_features:
                raise HTTPException(status_code=400, detail="No matching features found")
            X = df[available_features]
        else:
            X = df.select_dtypes(include=[np.number])
        
        # Make predictions
        predictions = model.predict(X)
        probabilities = model.predict_proba(X)
        
        # Create response
        results = []
        for i, (pred, probs) in enumerate(zip(predictions, probabilities)):
            confidence = float(np.max(probs))
            
            # Convert probabilities to dictionary
            if model.model_type == 'supervised' and hasattr(model, 'label_encoder'):
                prob_dict = dict(zip(model.label_encoder.classes_, probs))
            else:
                prob_dict = {"normal": float(probs[0]), "anomaly": float(probs[1])}
            
            results.append({
                "flow_id": str(i),
                "prediction": str(pred),
                "confidence": confidence,
                "probabilities": prob_dict,
                "flow_data": flows[i] if i < len(flows) else {}
            })
        
        # Clean up temporary files
        os.remove(temp_pcap_path)
        os.remove(temp_flows_path)
        
        return {
            "message": "PCAP processed successfully",
            "total_flows": len(flows),
            "model_used": model_name,
            "results": results,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error in PCAP ingestion: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/stats")
async def get_statistics():
    """Get API statistics"""
    return {
        "models_loaded": len(models),
        "available_models": list(models.keys()),
        "feature_engineer_loaded": feature_engineer is not None,
        "uptime": "N/A",  # Could implement proper uptime tracking
        "version": "1.0.0"
    }

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="AIDTIS API Server")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind to")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")
    parser.add_argument("--workers", type=int, default=1, help="Number of workers")
    
    args = parser.parse_args()
    
    uvicorn.run(
        "api:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        workers=args.workers
    )
