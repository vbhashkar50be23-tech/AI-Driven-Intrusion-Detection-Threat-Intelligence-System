"""
Flow Extractor for PCAP to Flow Conversion
Converts PCAP files to standardized flow-level CSV format
"""

import os
import csv
import json
import logging
from typing import Dict, List, Tuple, Optional, Any
from datetime import datetime, timedelta
from collections import defaultdict
import pandas as pd
import numpy as np
from scapy.all import *
from scapy.layers.inet import IP, TCP, UDP, ICMP
from scapy.layers.l2 import Ether
import dpkt
import pyshark

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FlowExtractor:
    """
    Extract network flows from PCAP files and convert to standardized format
    """
    
    def __init__(self, flow_timeout: int = 600, max_flows: int = 1000000):
        """
        Initialize flow extractor
        
        Args:
            flow_timeout: Timeout for flow expiration (seconds)
            max_flows: Maximum number of flows to process
        """
        self.flow_timeout = flow_timeout
        self.max_flows = max_flows
        self.flows = {}
        self.flow_id_counter = 0
        
    def _get_flow_key(self, packet: Any) -> Tuple[str, str, int, int, int]:
        """
        Generate flow key from packet
        Returns: (src_ip, dst_ip, src_port, dst_port, protocol)
        """
        if hasattr(packet, 'ip'):  # Scapy packet
            src_ip = packet[IP].src
            dst_ip = packet[IP].dst
            protocol = packet[IP].proto
            
            if hasattr(packet, 'tcp'):
                src_port = packet[TCP].sport
                dst_port = packet[TCP].dport
            elif hasattr(packet, 'udp'):
                src_port = packet[UDP].sport
                dst_port = packet[UDP].dport
            else:
                src_port = 0
                dst_port = 0
        else:  # dpkt packet
            src_ip = socket.inet_ntoa(packet.src)
            dst_ip = socket.inet_ntoa(packet.dst)
            protocol = packet.p
            src_port = packet.sport if hasattr(packet, 'sport') else 0
            dst_port = packet.dport if hasattr(packet, 'dport') else 0
            
        # Ensure consistent ordering
        if src_ip > dst_ip or (src_ip == dst_ip and src_port > dst_port):
            src_ip, dst_ip = dst_ip, src_ip
            src_port, dst_port = dst_port, src_port
            
        return (src_ip, dst_ip, src_port, dst_port, protocol)
    
    def _extract_tcp_flags(self, packet: Any) -> Dict[str, int]:
        """Extract TCP flags from packet"""
        flags = {
            'FIN': 0, 'SYN': 0, 'RST': 0, 'PSH': 0, 'ACK': 0, 'URG': 0, 'ECE': 0, 'CWR': 0
        }
        
        if hasattr(packet, 'tcp'):  # Scapy
            tcp = packet[TCP]
            flags['FIN'] = int(tcp.flags & 0x01)
            flags['SYN'] = int(tcp.flags & 0x02)
            flags['RST'] = int(tcp.flags & 0x04)
            flags['PSH'] = int(tcp.flags & 0x08)
            flags['ACK'] = int(tcp.flags & 0x10)
            flags['URG'] = int(tcp.flags & 0x20)
            flags['ECE'] = int(tcp.flags & 0x40)
            flags['CWR'] = int(tcp.flags & 0x80)
        elif hasattr(packet, 'flags'):  # dpkt
            tcp_flags = packet.flags
            flags['FIN'] = int(tcp_flags & 0x01)
            flags['SYN'] = int(tcp_flags & 0x02)
            flags['RST'] = int(tcp_flags & 0x04)
            flags['PSH'] = int(tcp_flags & 0x08)
            flags['ACK'] = int(tcp_flags & 0x10)
            flags['URG'] = int(tcp_flags & 0x20)
            flags['ECE'] = int(tcp_flags & 0x40)
            flags['CWR'] = int(tcp_flags & 0x80)
            
        return flags
    
    def _update_flow(self, flow_key: Tuple, packet: Any, timestamp: float):
        """Update flow statistics with new packet"""
        if flow_key not in self.flows:
            self.flows[flow_key] = {
                'flow_id': self.flow_id_counter,
                'src_ip': flow_key[0],
                'dst_ip': flow_key[1],
                'src_port': flow_key[2],
                'dst_port': flow_key[3],
                'protocol': flow_key[4],
                'start_time': timestamp,
                'end_time': timestamp,
                'packet_count': 0,
                'byte_count': 0,
                'tcp_flags': {'FIN': 0, 'SYN': 0, 'RST': 0, 'PSH': 0, 'ACK': 0, 'URG': 0, 'ECE': 0, 'CWR': 0},
                'packet_sizes': [],
                'inter_arrival_times': [],
                'last_timestamp': timestamp
            }
            self.flow_id_counter += 1
        
        flow = self.flows[flow_key]
        flow['end_time'] = timestamp
        flow['packet_count'] += 1
        
        # Calculate packet size
        if hasattr(packet, 'len'):
            packet_size = packet.len
        else:
            packet_size = len(packet)
        flow['byte_count'] += packet_size
        flow['packet_sizes'].append(packet_size)
        
        # Update TCP flags
        if flow['protocol'] == 6:  # TCP
            tcp_flags = self._extract_tcp_flags(packet)
            for flag, count in tcp_flags.items():
                flow['tcp_flags'][flag] += count
        
        # Calculate inter-arrival time
        if flow['packet_count'] > 1:
            iat = timestamp - flow['last_timestamp']
            flow['inter_arrival_times'].append(iat)
        flow['last_timestamp'] = timestamp
    
    def _finalize_flow(self, flow_key: Tuple) -> Dict[str, Any]:
        """Finalize flow and calculate derived features"""
        flow = self.flows[flow_key]
        
        # Calculate duration
        duration = flow['end_time'] - flow['start_time']
        
        # Calculate average packet size
        avg_pkt_size = np.mean(flow['packet_sizes']) if flow['packet_sizes'] else 0
        
        # Calculate packet rate
        pkt_rate = flow['packet_count'] / duration if duration > 0 else 0
        
        # Calculate mean inter-arrival time
        mean_iat = np.mean(flow['inter_arrival_times']) if flow['inter_arrival_times'] else 0
        
        # Create TCP flag counts string
        tcp_flag_counts = f"{flow['tcp_flags']['FIN']},{flow['tcp_flags']['SYN']},{flow['tcp_flags']['RST']},{flow['tcp_flags']['PSH']},{flow['tcp_flags']['ACK']},{flow['tcp_flags']['URG']},{flow['tcp_flags']['ECE']},{flow['tcp_flags']['CWR']}"
        
        return {
            'flow_id': flow['flow_id'],
            'src_ip': flow['src_ip'],
            'dst_ip': flow['dst_ip'],
            'src_port': flow['src_port'],
            'dst_port': flow['dst_port'],
            'protocol': flow['protocol'],
            'start_time': flow['start_time'],
            'end_time': flow['end_time'],
            'duration': duration,
            'total_bytes': flow['byte_count'],
            'total_packets': flow['packet_count'],
            'avg_pkt_size': avg_pkt_size,
            'pkt_rate': pkt_rate,
            'mean_iat': mean_iat,
            'tcp_flag_counts': tcp_flag_counts,
            'label': 'UNKNOWN'  # Will be set by dataset-specific parsers
        }
    
    def extract_flows_scapy(self, pcap_file: str) -> List[Dict[str, Any]]:
        """
        Extract flows from PCAP using Scapy
        
        Args:
            pcap_file: Path to PCAP file
            
        Returns:
            List of flow dictionaries
        """
        logger.info(f"Extracting flows from {pcap_file} using Scapy")
        
        try:
            packets = rdpcap(pcap_file)
            logger.info(f"Loaded {len(packets)} packets")
            
            for i, packet in enumerate(packets):
                if i % 10000 == 0:
                    logger.info(f"Processed {i} packets")
                
                if IP in packet:
                    flow_key = self._get_flow_key(packet)
                    timestamp = float(packet.time)
                    self._update_flow(flow_key, packet, timestamp)
                    
                    # Clean up expired flows periodically
                    if i % 1000 == 0:
                        self._cleanup_expired_flows(timestamp)
                        
        except Exception as e:
            logger.error(f"Error processing PCAP with Scapy: {e}")
            return []
        
        # Finalize all remaining flows
        flows = []
        for flow_key in list(self.flows.keys()):
            flows.append(self._finalize_flow(flow_key))
            
        logger.info(f"Extracted {len(flows)} flows")
        return flows
    
    def extract_flows_dpkt(self, pcap_file: str) -> List[Dict[str, Any]]:
        """
        Extract flows from PCAP using dpkt
        
        Args:
            pcap_file: Path to PCAP file
            
        Returns:
            List of flow dictionaries
        """
        logger.info(f"Extracting flows from {pcap_file} using dpkt")
        
        try:
            with open(pcap_file, 'rb') as f:
                pcap = dpkt.pcap.Reader(f)
                
                packet_count = 0
                for timestamp, buf in pcap:
                    packet_count += 1
                    if packet_count % 10000 == 0:
                        logger.info(f"Processed {packet_count} packets")
                    
                    try:
                        eth = dpkt.ethernet.Ethernet(buf)
                        if isinstance(eth.data, dpkt.ip.IP):
                            ip = eth.data
                            flow_key = self._get_flow_key(ip)
                            self._update_flow(flow_key, ip, timestamp)
                            
                            # Clean up expired flows periodically
                            if packet_count % 1000 == 0:
                                self._cleanup_expired_flows(timestamp)
                                
                    except Exception as e:
                        continue
                        
        except Exception as e:
            logger.error(f"Error processing PCAP with dpkt: {e}")
            return []
        
        # Finalize all remaining flows
        flows = []
        for flow_key in list(self.flows.keys()):
            flows.append(self._finalize_flow(flow_key))
            
        logger.info(f"Extracted {len(flows)} flows")
        return flows
    
    def _cleanup_expired_flows(self, current_time: float):
        """Remove flows that have expired"""
        expired_keys = []
        for flow_key, flow in self.flows.items():
            if current_time - flow['last_timestamp'] > self.flow_timeout:
                expired_keys.append(flow_key)
        
        for key in expired_keys:
            del self.flows[key]
    
    def save_flows_to_csv(self, flows: List[Dict[str, Any]], output_file: str):
        """
        Save flows to CSV file
        
        Args:
            flows: List of flow dictionaries
            output_file: Output CSV file path
        """
        if not flows:
            logger.warning("No flows to save")
            return
            
        df = pd.DataFrame(flows)
        df.to_csv(output_file, index=False)
        logger.info(f"Saved {len(flows)} flows to {output_file}")

def extract_pcap_to_flows(pcap_file: str, output_file: str, method: str = 'scapy') -> bool:
    """
    Extract flows from PCAP file and save to CSV
    
    Args:
        pcap_file: Path to input PCAP file
        output_file: Path to output CSV file
        method: Extraction method ('scapy' or 'dpkt')
        
    Returns:
        True if successful, False otherwise
    """
    extractor = FlowExtractor()
    
    try:
        if method == 'scapy':
            flows = extractor.extract_flows_scapy(pcap_file)
        elif method == 'dpkt':
            flows = extractor.extract_flows_dpkt(pcap_file)
        else:
            logger.error(f"Unknown extraction method: {method}")
            return False
            
        if flows:
            extractor.save_flows_to_csv(flows, output_file)
            return True
        else:
            logger.error("No flows extracted")
            return False
            
    except Exception as e:
        logger.error(f"Error extracting flows: {e}")
        return False

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Extract flows from PCAP files")
    parser.add_argument("pcap_file", help="Input PCAP file")
    parser.add_argument("output_file", help="Output CSV file")
    parser.add_argument("--method", choices=['scapy', 'dpkt'], default='scapy',
                       help="Extraction method")
    
    args = parser.parse_args()
    
    success = extract_pcap_to_flows(args.pcap_file, args.output_file, args.method)
    if success:
        print(f"Successfully extracted flows to {args.output_file}")
    else:
        print("Failed to extract flows")
        exit(1)
