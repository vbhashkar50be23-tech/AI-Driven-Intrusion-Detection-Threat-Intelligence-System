"""
Data Balancing and Splitting Utilities
Handles imbalanced datasets and creates train/validation/test splits
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.utils import resample
from imblearn.over_sampling import SMOTE, ADASYN, BorderlineSMOTE
from imblearn.under_sampling import RandomUnderSampler, EditedNearestNeighbours
from imblearn.combine import SMOTEENN, SMOTETomek
import logging
from typing import Dict, List, Tuple, Optional, Any
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DataBalancer:
    """
    Handle data balancing and splitting for intrusion detection datasets
    """
    
    def __init__(self, random_state: int = 42):
        """
        Initialize data balancer
        
        Args:
            random_state: Random seed for reproducibility
        """
        self.random_state = random_state
        np.random.seed(random_state)
        
    def analyze_class_distribution(self, df: pd.DataFrame, label_column: str = 'label') -> Dict[str, Any]:
        """
        Analyze class distribution in dataset
        
        Args:
            df: DataFrame with labels
            label_column: Name of label column
            
        Returns:
            Dictionary with distribution analysis
        """
        logger.info("Analyzing class distribution")
        
        class_counts = df[label_column].value_counts()
        class_proportions = df[label_column].value_counts(normalize=True)
        
        analysis = {
            'class_counts': class_counts.to_dict(),
            'class_proportions': class_proportions.to_dict(),
            'total_samples': len(df),
            'num_classes': len(class_counts),
            'majority_class': class_counts.index[0],
            'minority_class': class_counts.index[-1],
            'imbalance_ratio': class_counts.iloc[0] / class_counts.iloc[-1]
        }
        
        logger.info(f"Total samples: {analysis['total_samples']}")
        logger.info(f"Number of classes: {analysis['num_classes']}")
        logger.info(f"Imbalance ratio: {analysis['imbalance_ratio']:.2f}")
        logger.info("Class distribution:")
        for class_name, count in class_counts.items():
            proportion = class_proportions[class_name]
            logger.info(f"  {class_name}: {count} ({proportion:.3f})")
        
        return analysis
    
    def balance_data_undersampling(self, df: pd.DataFrame, label_column: str = 'label',
                                 strategy: str = 'auto') -> pd.DataFrame:
        """
        Balance data using undersampling
        
        Args:
            df: DataFrame to balance
            label_column: Name of label column
            strategy: Undersampling strategy
            
        Returns:
            Balanced DataFrame
        """
        logger.info(f"Balancing data using undersampling with strategy: {strategy}")
        
        # Separate features and labels
        X = df.drop(columns=[label_column])
        y = df[label_column]
        
        # Apply undersampling
        if strategy == 'auto':
            # Use RandomUnderSampler with majority class size
            class_counts = y.value_counts()
            majority_size = class_counts.iloc[0]
            sampling_strategy = {class_name: min(count, majority_size) 
                               for class_name, count in class_counts.items()}
        else:
            sampling_strategy = strategy
        
        undersampler = RandomUnderSampler(
            sampling_strategy=sampling_strategy,
            random_state=self.random_state
        )
        
        X_resampled, y_resampled = undersampler.fit_resample(X, y)
        
        # Create balanced DataFrame
        balanced_df = pd.DataFrame(X_resampled, columns=X.columns)
        balanced_df[label_column] = y_resampled
        
        logger.info(f"Original size: {len(df)}, Balanced size: {len(balanced_df)}")
        return balanced_df
    
    def balance_data_oversampling(self, df: pd.DataFrame, label_column: str = 'label',
                                method: str = 'smote', k_neighbors: int = 5) -> pd.DataFrame:
        """
        Balance data using oversampling
        
        Args:
            df: DataFrame to balance
            label_column: Name of label column
            method: Oversampling method ('smote', 'adasyn', 'borderline_smote')
            k_neighbors: Number of neighbors for SMOTE variants
            
        Returns:
            Balanced DataFrame
        """
        logger.info(f"Balancing data using oversampling with method: {method}")
        
        # Separate features and labels
        X = df.drop(columns=[label_column])
        y = df[label_column]
        
        # Select oversampling method
        if method == 'smote':
            oversampler = SMOTE(
                sampling_strategy='auto',
                k_neighbors=k_neighbors,
                random_state=self.random_state
            )
        elif method == 'adasyn':
            oversampler = ADASYN(
                sampling_strategy='auto',
                n_neighbors=k_neighbors,
                random_state=self.random_state
            )
        elif method == 'borderline_smote':
            oversampler = BorderlineSMOTE(
                sampling_strategy='auto',
                k_neighbors=k_neighbors,
                random_state=self.random_state
            )
        else:
            raise ValueError(f"Unknown oversampling method: {method}")
        
        X_resampled, y_resampled = oversampler.fit_resample(X, y)
        
        # Create balanced DataFrame
        balanced_df = pd.DataFrame(X_resampled, columns=X.columns)
        balanced_df[label_column] = y_resampled
        
        logger.info(f"Original size: {len(df)}, Balanced size: {len(balanced_df)}")
        return balanced_df
    
    def balance_data_combined(self, df: pd.DataFrame, label_column: str = 'label',
                            method: str = 'smoteenn') -> pd.DataFrame:
        """
        Balance data using combined over/under sampling
        
        Args:
            df: DataFrame to balance
            label_column: Name of label column
            method: Combined method ('smoteenn', 'smotetomek')
            
        Returns:
            Balanced DataFrame
        """
        logger.info(f"Balancing data using combined method: {method}")
        
        # Separate features and labels
        X = df.drop(columns=[label_column])
        y = df[label_column]
        
        # Select combined method
        if method == 'smoteenn':
            combiner = SMOTEENN(random_state=self.random_state)
        elif method == 'smotetomek':
            combiner = SMOTETomek(random_state=self.random_state)
        else:
            raise ValueError(f"Unknown combined method: {method}")
        
        X_resampled, y_resampled = combiner.fit_resample(X, y)
        
        # Create balanced DataFrame
        balanced_df = pd.DataFrame(X_resampled, columns=X.columns)
        balanced_df[label_column] = y_resampled
        
        logger.info(f"Original size: {len(df)}, Balanced size: {len(balanced_df)}")
        return balanced_df
    
    def create_stratified_splits(self, df: pd.DataFrame, label_column: str = 'label',
                               test_size: float = 0.2, val_size: float = 0.1) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Create stratified train/validation/test splits
        
        Args:
            df: DataFrame to split
            label_column: Name of label column
            test_size: Proportion for test set
            val_size: Proportion for validation set (from remaining data)
            
        Returns:
            Tuple of (train_df, val_df, test_df)
        """
        logger.info("Creating stratified train/validation/test splits")
        
        # First split: separate test set
        train_val_df, test_df = train_test_split(
            df, 
            test_size=test_size, 
            stratify=df[label_column],
            random_state=self.random_state
        )
        
        # Second split: separate validation set from train+val
        val_size_adjusted = val_size / (1 - test_size)  # Adjust for remaining data
        train_df, val_df = train_test_split(
            train_val_df,
            test_size=val_size_adjusted,
            stratify=train_val_df[label_column],
            random_state=self.random_state
        )
        
        logger.info(f"Train set: {len(train_df)} samples")
        logger.info(f"Validation set: {len(val_df)} samples")
        logger.info(f"Test set: {len(test_df)} samples")
        
        # Verify stratification
        for split_name, split_df in [('Train', train_df), ('Validation', val_df), ('Test', test_df)]:
            logger.info(f"{split_name} class distribution:")
            for class_name, count in split_df[label_column].value_counts().items():
                proportion = count / len(split_df)
                logger.info(f"  {class_name}: {count} ({proportion:.3f})")
        
        return train_df, val_df, test_df
    
    def create_time_based_splits(self, df: pd.DataFrame, time_column: str = 'start_time',
                               test_size: float = 0.2, val_size: float = 0.1) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Create time-based train/validation/test splits
        
        Args:
            df: DataFrame to split
            time_column: Name of time column
            test_size: Proportion for test set
            val_size: Proportion for validation set
            
        Returns:
            Tuple of (train_df, val_df, test_df)
        """
        logger.info("Creating time-based train/validation/test splits")
        
        # Sort by time
        df_sorted = df.sort_values(time_column).reset_index(drop=True)
        
        # Calculate split indices
        total_size = len(df_sorted)
        test_start = int(total_size * (1 - test_size))
        val_start = int(total_size * (1 - test_size - val_size))
        
        # Create splits
        train_df = df_sorted.iloc[:val_start].copy()
        val_df = df_sorted.iloc[val_start:test_start].copy()
        test_df = df_sorted.iloc[test_start:].copy()
        
        logger.info(f"Train set: {len(train_df)} samples (time range: {train_df[time_column].min()} to {train_df[time_column].max()})")
        logger.info(f"Validation set: {len(val_df)} samples (time range: {val_df[time_column].min()} to {val_df[time_column].max()})")
        logger.info(f"Test set: {len(test_df)} samples (time range: {test_df[time_column].min()} to {test_df[time_column].max()})")
        
        return train_df, val_df, test_df
    
    def balance_and_split(self, df: pd.DataFrame, label_column: str = 'label',
                         balance_method: str = 'none', split_method: str = 'stratified',
                         test_size: float = 0.2, val_size: float = 0.1,
                         **balance_kwargs) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Balance data and create splits in one operation
        
        Args:
            df: DataFrame to process
            label_column: Name of label column
            balance_method: Balancing method ('none', 'undersample', 'oversample', 'combined')
            split_method: Splitting method ('stratified', 'time_based')
            test_size: Proportion for test set
            val_size: Proportion for validation set
            **balance_kwargs: Additional arguments for balancing methods
            
        Returns:
            Tuple of (train_df, val_df, test_df)
        """
        logger.info(f"Balancing data with method: {balance_method}")
        logger.info(f"Creating splits with method: {split_method}")
        
        # Apply balancing
        if balance_method == 'undersample':
            balanced_df = self.balance_data_undersampling(df, label_column, **balance_kwargs)
        elif balance_method == 'oversample':
            balanced_df = self.balance_data_oversampling(df, label_column, **balance_kwargs)
        elif balance_method == 'combined':
            balanced_df = self.balance_data_combined(df, label_column, **balance_kwargs)
        else:
            balanced_df = df.copy()
        
        # Create splits
        if split_method == 'stratified':
            train_df, val_df, test_df = self.create_stratified_splits(
                balanced_df, label_column, test_size, val_size
            )
        elif split_method == 'time_based':
            train_df, val_df, test_df = self.create_time_based_splits(
                balanced_df, label_column, test_size, val_size
            )
        else:
            raise ValueError(f"Unknown split method: {split_method}")
        
        return train_df, val_df, test_df
    
    def save_splits(self, train_df: pd.DataFrame, val_df: pd.DataFrame, test_df: pd.DataFrame,
                   output_dir: str):
        """
        Save train/validation/test splits to CSV files
        
        Args:
            train_df: Training DataFrame
            val_df: Validation DataFrame
            test_df: Test DataFrame
            output_dir: Output directory
        """
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        train_df.to_csv(output_path / 'train.csv', index=False)
        val_df.to_csv(output_path / 'val.csv', index=False)
        test_df.to_csv(output_path / 'test.csv', index=False)
        
        logger.info(f"Saved splits to {output_dir}")
        logger.info(f"  Train: {len(train_df)} samples")
        logger.info(f"  Validation: {len(val_df)} samples")
        logger.info(f"  Test: {len(test_df)} samples")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Balance and split intrusion detection datasets")
    parser.add_argument("input_file", help="Input CSV file")
    parser.add_argument("output_dir", help="Output directory for splits")
    parser.add_argument("--balance_method", choices=['none', 'undersample', 'oversample', 'combined'],
                       default='none', help="Data balancing method")
    parser.add_argument("--split_method", choices=['stratified', 'time_based'],
                       default='stratified', help="Data splitting method")
    parser.add_argument("--test_size", type=float, default=0.2, help="Test set proportion")
    parser.add_argument("--val_size", type=float, default=0.1, help="Validation set proportion")
    parser.add_argument("--label_column", default='label', help="Label column name")
    
    args = parser.parse_args()
    
    # Load data
    df = pd.read_csv(args.input_file)
    logger.info(f"Loaded {len(df)} samples")
    
    # Create balancer
    balancer = DataBalancer()
    
    # Analyze class distribution
    analysis = balancer.analyze_class_distribution(df, args.label_column)
    
    # Balance and split
    train_df, val_df, test_df = balancer.balance_and_split(
        df, 
        label_column=args.label_column,
        balance_method=args.balance_method,
        split_method=args.split_method,
        test_size=args.test_size,
        val_size=args.val_size
    )
    
    # Save splits
    balancer.save_splits(train_df, val_df, test_df, args.output_dir)
    
    print(f"Successfully created splits in {args.output_dir}")
