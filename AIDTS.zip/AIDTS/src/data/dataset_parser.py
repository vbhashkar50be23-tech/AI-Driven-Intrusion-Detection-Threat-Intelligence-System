"""
Dataset Parser for Multiple Intrusion Detection Datasets
Supports NSL-KDD, CICIDS2017/2018, UNSW-NB15, and Bot-IoT
"""

import os
import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Tuple, Optional, Any
from pathlib import Path
import requests
import zipfile
import tarfile
from urllib.parse import urlparse

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatasetParser:
    """
    Parse and standardize multiple intrusion detection datasets
    """
    
    def __init__(self, data_dir: str = "data"):
        """
        Initialize dataset parser
        
        Args:
            data_dir: Directory to store datasets
        """
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        # Dataset URLs and information
        self.datasets = {
            'nsl_kdd': {
                'url': 'https://www.unb.ca/cic/datasets/nsl.html',
                'files': ['KDDTrain+.txt', 'KDDTest+.txt', 'KDDTrain+_20Percent.txt', 'KDDTest-21.txt'],
                'description': 'NSL-KDD dataset - classic intrusion detection benchmark'
            },
            'cicids2017': {
                'url': 'https://www.unb.ca/cic/datasets/ids-2017.html',
                'files': ['MachineLearningCSV.zip'],
                'description': 'CICIDS2017 - modern network traffic dataset'
            },
            'cicids2018': {
                'url': 'https://www.unb.ca/cic/datasets/ids-2018.html',
                'files': ['MachineLearningCSV.zip'],
                'description': 'CICIDS2018 - updated network traffic dataset'
            },
            'unsw_nb15': {
                'url': 'https://www.unsw.adfa.edu.au/unsw-canberra-cyber/cybersecurity/ADFA-NB15-Datasets/',
                'files': ['UNSW_NB15_training-set.csv', 'UNSW_NB15_testing-set.csv'],
                'description': 'UNSW-NB15 - updated intrusion detection dataset'
            },
            'bot_iot': {
                'url': 'https://research.unsw.edu.au/projects/bot-iot-dataset',
                'files': ['UNSW_2018_IoT_Botnet_Dataset_*.csv'],
                'description': 'Bot-IoT - IoT-specific attack dataset'
            }
        }
        
        # Standardized label mapping
        self.label_mapping = {
            'nsl_kdd': {
                'normal': 'BENIGN',
                'dos': 'DOS',
                'probe': 'PROBE',
                'r2l': 'R2L',
                'u2r': 'U2R'
            },
            'cicids2017': {
                'BENIGN': 'BENIGN',
                'DDoS': 'DOS',
                'DoS GoldenEye': 'DOS',
                'DoS Hulk': 'DOS',
                'DoS Slowhttptest': 'DOS',
                'DoS slowloris': 'DOS',
                'Heartbleed': 'DOS',
                'Web Attack – Brute Force': 'WEB_ATTACK',
                'Web Attack – XSS': 'WEB_ATTACK',
                'Web Attack – Sql Injection': 'WEB_ATTACK',
                'Infiltration': 'INFILTRATION',
                'Bot': 'BOT',
                'PortScan': 'PROBE',
                'FTP-Patator': 'BRUTE_FORCE',
                'SSH-Patator': 'BRUTE_FORCE'
            },
            'cicids2018': {
                'BENIGN': 'BENIGN',
                'DDoS': 'DOS',
                'DoS': 'DOS',
                'Web Attack': 'WEB_ATTACK',
                'Infiltration': 'INFILTRATION',
                'Bot': 'BOT',
                'PortScan': 'PROBE',
                'Brute Force': 'BRUTE_FORCE',
                'FTP-BruteForce': 'BRUTE_FORCE',
                'SSH-BruteForce': 'BRUTE_FORCE'
            },
            'unsw_nb15': {
                'Normal': 'BENIGN',
                'Fuzzers': 'FUZZER',
                'Analysis': 'ANALYSIS',
                'Backdoors': 'BACKDOOR',
                'DoS': 'DOS',
                'Exploits': 'EXPLOIT',
                'Generic': 'GENERIC',
                'Reconnaissance': 'PROBE',
                'Shellcode': 'SHELLCODE',
                'Worms': 'WORM'
            },
            'bot_iot': {
                'Normal': 'BENIGN',
                'DDoS': 'DOS',
                'DoS': 'DOS',
                'Reconnaissance': 'PROBE',
                'Theft': 'THEFT'
            }
        }
    
    def download_dataset(self, dataset_name: str, force_download: bool = False) -> bool:
        """
        Download dataset files (placeholder - actual URLs need to be provided)
        
        Args:
            dataset_name: Name of dataset to download
            force_download: Force download even if files exist
            
        Returns:
            True if successful, False otherwise
        """
        if dataset_name not in self.datasets:
            logger.error(f"Unknown dataset: {dataset_name}")
            return False
            
        dataset_info = self.datasets[dataset_name]
        dataset_dir = self.data_dir / dataset_name
        dataset_dir.mkdir(exist_ok=True)
        
        logger.info(f"Dataset {dataset_name} requires manual download from: {dataset_info['url']}")
        logger.info(f"Please download the following files to {dataset_dir}:")
        for file in dataset_info['files']:
            logger.info(f"  - {file}")
            
        return True
    
    def parse_nsl_kdd(self, file_path: str) -> pd.DataFrame:
        """
        Parse NSL-KDD dataset
        
        Args:
            file_path: Path to NSL-KDD file
            
        Returns:
            Standardized DataFrame
        """
        logger.info(f"Parsing NSL-KDD file: {file_path}")
        
        # NSL-KDD column names
        columns = [
            'duration', 'protocol_type', 'service', 'flag', 'src_bytes', 'dst_bytes',
            'land', 'wrong_fragment', 'urgent', 'hot', 'num_failed_logins', 'logged_in',
            'num_compromised', 'root_shell', 'su_attempted', 'num_root', 'num_file_creations',
            'num_shells', 'num_access_files', 'num_outbound_cmds', 'is_host_login',
            'is_guest_login', 'count', 'srv_count', 'serror_rate', 'srv_serror_rate',
            'rerror_rate', 'srv_rerror_rate', 'same_srv_rate', 'diff_srv_rate',
            'srv_diff_host_rate', 'dst_host_count', 'dst_host_srv_count',
            'dst_host_same_srv_rate', 'dst_host_diff_srv_rate', 'dst_host_same_src_port_rate',
            'dst_host_srv_diff_host_rate', 'dst_host_serror_rate', 'dst_host_srv_serror_rate',
            'dst_host_rerror_rate', 'dst_host_srv_rerror_rate', 'label'
        ]
        
        try:
            df = pd.read_csv(file_path, names=columns)
            
            # Create flow_id
            df['flow_id'] = range(len(df))
            
            # Map protocol types to numbers
            protocol_map = {'tcp': 6, 'udp': 17, 'icmp': 1}
            df['protocol'] = df['protocol_type'].map(protocol_map).fillna(0)
            
            # Create dummy IP addresses (NSL-KDD doesn't have real IPs)
            df['src_ip'] = '192.168.1.' + (df['flow_id'] % 254 + 1).astype(str)
            df['dst_ip'] = '10.0.0.' + (df['flow_id'] % 254 + 1).astype(str)
            df['src_port'] = 1000 + (df['flow_id'] % 50000)
            df['dst_port'] = 2000 + (df['flow_id'] % 50000)
            
            # Calculate derived features
            df['total_bytes'] = df['src_bytes'] + df['dst_bytes']
            df['total_packets'] = df['count'] + df['srv_count']
            df['avg_pkt_size'] = df['total_bytes'] / df['total_packets'].replace(0, 1)
            df['pkt_rate'] = df['total_packets'] / df['duration'].replace(0, 1)
            df['mean_iat'] = df['duration'] / df['total_packets'].replace(0, 1)
            
            # Create TCP flag counts (dummy for NSL-KDD)
            df['tcp_flag_counts'] = '0,0,0,0,0,0,0,0'
            
            # Map labels
            df['label'] = df['label'].map(self.label_mapping['nsl_kdd']).fillna('UNKNOWN')
            
            # Create time features
            df['start_time'] = pd.Timestamp.now() - pd.Timedelta(seconds=df['duration'])
            df['end_time'] = pd.Timestamp.now()
            
            # Select and reorder columns
            standard_columns = [
                'flow_id', 'src_ip', 'dst_ip', 'src_port', 'dst_port', 'protocol',
                'start_time', 'end_time', 'duration', 'total_bytes', 'total_packets',
                'avg_pkt_size', 'pkt_rate', 'mean_iat', 'tcp_flag_counts', 'label'
            ]
            
            return df[standard_columns]
            
        except Exception as e:
            logger.error(f"Error parsing NSL-KDD file: {e}")
            return pd.DataFrame()
    
    def parse_cicids(self, file_path: str, dataset_year: str) -> pd.DataFrame:
        """
        Parse CICIDS2017/2018 dataset
        
        Args:
            file_path: Path to CICIDS CSV file
            dataset_year: '2017' or '2018'
            
        Returns:
            Standardized DataFrame
        """
        logger.info(f"Parsing CICIDS{dataset_year} file: {file_path}")
        
        try:
            df = pd.read_csv(file_path)
            
            # Create flow_id
            df['flow_id'] = range(len(df))
            
            # Map labels
            label_key = f'cicids{dataset_year}'
            df['label'] = df['Label'].map(self.label_mapping[label_key]).fillna('UNKNOWN')
            
            # Rename columns to match standard schema
            column_mapping = {
                'Source IP': 'src_ip',
                'Destination IP': 'dst_ip',
                'Source Port': 'src_port',
                'Destination Port': 'dst_port',
                'Protocol': 'protocol',
                'Timestamp': 'start_time',
                'Flow Duration': 'duration',
                'Total Fwd Packets': 'total_packets',
                'Total Length of Fwd Packets': 'total_bytes',
                'Flow IAT Mean': 'mean_iat',
                'Fwd Packet Length Mean': 'avg_pkt_size',
                'Flow Packets/s': 'pkt_rate'
            }
            
            df = df.rename(columns=column_mapping)
            
            # Calculate end_time
            df['end_time'] = pd.to_datetime(df['start_time']) + pd.to_timedelta(df['duration'], unit='s')
            
            # Create TCP flag counts
            tcp_flag_cols = ['Fwd PSH Flags', 'Bwd PSH Flags', 'Fwd URG Flags', 'Bwd URG Flags',
                           'Fwd RST Flags', 'Bwd RST Flags', 'Fwd SYN Flags', 'Bwd SYN Flags']
            
            if all(col in df.columns for col in tcp_flag_cols):
                df['tcp_flag_counts'] = (df['Fwd PSH Flags'].astype(str) + ',' +
                                       df['Bwd PSH Flags'].astype(str) + ',' +
                                       df['Fwd URG Flags'].astype(str) + ',' +
                                       df['Bwd URG Flags'].astype(str) + ',' +
                                       df['Fwd RST Flags'].astype(str) + ',' +
                                       df['Bwd RST Flags'].astype(str) + ',' +
                                       df['Fwd SYN Flags'].astype(str) + ',' +
                                       df['Bwd SYN Flags'].astype(str))
            else:
                df['tcp_flag_counts'] = '0,0,0,0,0,0,0,0'
            
            # Select and reorder columns
            standard_columns = [
                'flow_id', 'src_ip', 'dst_ip', 'src_port', 'dst_port', 'protocol',
                'start_time', 'end_time', 'duration', 'total_bytes', 'total_packets',
                'avg_pkt_size', 'pkt_rate', 'mean_iat', 'tcp_flag_counts', 'label'
            ]
            
            available_columns = [col for col in standard_columns if col in df.columns]
            return df[available_columns]
            
        except Exception as e:
            logger.error(f"Error parsing CICIDS{dataset_year} file: {e}")
            return pd.DataFrame()
    
    def parse_unsw_nb15(self, file_path: str) -> pd.DataFrame:
        """
        Parse UNSW-NB15 dataset
        
        Args:
            file_path: Path to UNSW-NB15 CSV file
            
        Returns:
            Standardized DataFrame
        """
        logger.info(f"Parsing UNSW-NB15 file: {file_path}")
        
        try:
            df = pd.read_csv(file_path)
            
            # Create flow_id
            df['flow_id'] = range(len(df))
            
            # Map labels
            df['label'] = df['label'].map(self.label_mapping['unsw_nb15']).fillna('UNKNOWN')
            
            # Rename columns to match standard schema
            column_mapping = {
                'srcip': 'src_ip',
                'dstip': 'dst_ip',
                'sport': 'src_port',
                'dsport': 'dst_port',
                'proto': 'protocol',
                'stime': 'start_time',
                'dur': 'duration',
                'sbytes': 'total_bytes',
                'dbytes': 'total_bytes',  # Will be updated below
                'spkts': 'total_packets',
                'dpkts': 'total_packets',  # Will be updated below
                'smean': 'avg_pkt_size',
                'dmean': 'avg_pkt_size',  # Will be updated below
                'srate': 'pkt_rate',
                'drate': 'pkt_rate',  # Will be updated below
                'sintpkt': 'mean_iat',
                'dintpkt': 'mean_iat'  # Will be updated below
            }
            
            df = df.rename(columns=column_mapping)
            
            # Calculate combined features
            df['total_bytes'] = df['sbytes'] + df['dbytes']
            df['total_packets'] = df['spkts'] + df['dpkts']
            df['avg_pkt_size'] = (df['smean'] + df['dmean']) / 2
            df['pkt_rate'] = (df['srate'] + df['drate']) / 2
            df['mean_iat'] = (df['sintpkt'] + df['dintpkt']) / 2
            
            # Calculate end_time
            df['end_time'] = pd.to_datetime(df['start_time']) + pd.to_timedelta(df['duration'], unit='s')
            
            # Create TCP flag counts
            tcp_flag_cols = ['tcprtt', 'synack', 'ackdat', 'is_sm_ips_ports']
            if all(col in df.columns for col in tcp_flag_cols):
                df['tcp_flag_counts'] = '0,0,0,0,0,0,0,0'  # Simplified for UNSW-NB15
            else:
                df['tcp_flag_counts'] = '0,0,0,0,0,0,0,0'
            
            # Select and reorder columns
            standard_columns = [
                'flow_id', 'src_ip', 'dst_ip', 'src_port', 'dst_port', 'protocol',
                'start_time', 'end_time', 'duration', 'total_bytes', 'total_packets',
                'avg_pkt_size', 'pkt_rate', 'mean_iat', 'tcp_flag_counts', 'label'
            ]
            
            available_columns = [col for col in standard_columns if col in df.columns]
            return df[available_columns]
            
        except Exception as e:
            logger.error(f"Error parsing UNSW-NB15 file: {e}")
            return pd.DataFrame()
    
    def parse_bot_iot(self, file_path: str) -> pd.DataFrame:
        """
        Parse Bot-IoT dataset
        
        Args:
            file_path: Path to Bot-IoT CSV file
            
        Returns:
            Standardized DataFrame
        """
        logger.info(f"Parsing Bot-IoT file: {file_path}")
        
        try:
            df = pd.read_csv(file_path)
            
            # Create flow_id
            df['flow_id'] = range(len(df))
            
            # Map labels
            df['label'] = df['category'].map(self.label_mapping['bot_iot']).fillna('UNKNOWN')
            
            # Rename columns to match standard schema
            column_mapping = {
                'src_ip': 'src_ip',
                'dst_ip': 'dst_ip',
                'src_port': 'src_port',
                'dst_port': 'dst_port',
                'proto': 'protocol',
                'ts': 'start_time',
                'duration': 'duration',
                'pkt': 'total_packets',
                'bytes': 'total_bytes',
                'pkt_iat_avg': 'mean_iat',
                'pkt_size_avg': 'avg_pkt_size',
                'pkt_rate': 'pkt_rate'
            }
            
            df = df.rename(columns=column_mapping)
            
            # Calculate end_time
            df['end_time'] = pd.to_datetime(df['start_time']) + pd.to_timedelta(df['duration'], unit='s')
            
            # Create TCP flag counts (simplified for Bot-IoT)
            df['tcp_flag_counts'] = '0,0,0,0,0,0,0,0'
            
            # Select and reorder columns
            standard_columns = [
                'flow_id', 'src_ip', 'dst_ip', 'src_port', 'dst_port', 'protocol',
                'start_time', 'end_time', 'duration', 'total_bytes', 'total_packets',
                'avg_pkt_size', 'pkt_rate', 'mean_iat', 'tcp_flag_counts', 'label'
            ]
            
            available_columns = [col for col in standard_columns if col in df.columns]
            return df[available_columns]
            
        except Exception as e:
            logger.error(f"Error parsing Bot-IoT file: {e}")
            return pd.DataFrame()
    
    def parse_dataset(self, dataset_name: str, file_path: str) -> pd.DataFrame:
        """
        Parse dataset file based on dataset name
        
        Args:
            dataset_name: Name of the dataset
            file_path: Path to the dataset file
            
        Returns:
            Standardized DataFrame
        """
        if dataset_name == 'nsl_kdd':
            return self.parse_nsl_kdd(file_path)
        elif dataset_name in ['cicids2017', 'cicids2018']:
            year = dataset_name[-4:]
            return self.parse_cicids(file_path, year)
        elif dataset_name == 'unsw_nb15':
            return self.parse_unsw_nb15(file_path)
        elif dataset_name == 'bot_iot':
            return self.parse_bot_iot(file_path)
        else:
            logger.error(f"Unknown dataset: {dataset_name}")
            return pd.DataFrame()
    
    def create_unified_dataset(self, dataset_files: Dict[str, List[str]], 
                             output_file: str) -> bool:
        """
        Create unified dataset from multiple dataset files
        
        Args:
            dataset_files: Dictionary mapping dataset names to file paths
            output_file: Output CSV file path
            
        Returns:
            True if successful, False otherwise
        """
        logger.info("Creating unified dataset")
        
        all_dataframes = []
        
        for dataset_name, file_paths in dataset_files.items():
            for file_path in file_paths:
                if os.path.exists(file_path):
                    df = self.parse_dataset(dataset_name, file_path)
                    if not df.empty:
                        all_dataframes.append(df)
                        logger.info(f"Parsed {len(df)} flows from {file_path}")
                else:
                    logger.warning(f"File not found: {file_path}")
        
        if all_dataframes:
            unified_df = pd.concat(all_dataframes, ignore_index=True)
            unified_df.to_csv(output_file, index=False)
            logger.info(f"Created unified dataset with {len(unified_df)} flows: {output_file}")
            return True
        else:
            logger.error("No data to create unified dataset")
            return False

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Parse intrusion detection datasets")
    parser.add_argument("dataset", choices=['nsl_kdd', 'cicids2017', 'cicids2018', 'unsw_nb15', 'bot_iot'],
                       help="Dataset name")
    parser.add_argument("file_path", help="Path to dataset file")
    parser.add_argument("output_file", help="Output CSV file")
    
    args = parser.parse_args()
    
    parser_obj = DatasetParser()
    df = parser_obj.parse_dataset(args.dataset, args.file_path)
    
    if not df.empty:
        df.to_csv(args.output_file, index=False)
        print(f"Successfully parsed {len(df)} flows to {args.output_file}")
    else:
        print("Failed to parse dataset")
        exit(1)
