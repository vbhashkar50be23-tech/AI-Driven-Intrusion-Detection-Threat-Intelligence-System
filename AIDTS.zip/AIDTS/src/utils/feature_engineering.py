"""
Feature Engineering Pipeline for Intrusion Detection
Computes advanced features from flow-level data
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy import stats
from scipy.stats import entropy
import logging
from typing import Dict, List, Tuple, Optional, Any, Union
from pathlib import Path
import joblib
import pickle
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class FeatureEngineer:
    """
    Advanced feature engineering for network flow data
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize feature engineer
        
        Args:
            config: Configuration dictionary
        """
        self.config = config or self._default_config()
        self.scalers = {}
        self.encoders = {}
        self.feature_names = []
        self.is_fitted = False
        
    def _default_config(self) -> Dict:
        """Default configuration for feature engineering"""
        return {
            'numerical_features': [
                'duration', 'total_bytes', 'total_packets', 'avg_pkt_size',
                'pkt_rate', 'mean_iat'
            ],
            'categorical_features': ['protocol'],
            'ip_features': ['src_ip', 'dst_ip'],
            'port_features': ['src_port', 'dst_port'],
            'time_features': ['start_time', 'end_time'],
            'tcp_flag_features': ['tcp_flag_counts'],
            'rolling_window': 100,  # For rolling statistics
            'entropy_window': 50,   # For entropy calculations
            'time_bins': 24,        # Hours in day
            'port_bins': 1000,      # Port ranges
            'ip_embedding_dim': 16, # IP embedding dimension
            'normalize_features': True,
            'create_interactions': True,
            'create_polynomial': True,
            'polynomial_degree': 2
        }
    
    def _extract_tcp_flags(self, tcp_flag_string: str) -> List[int]:
        """Extract TCP flags from string format"""
        try:
            return [int(x) for x in tcp_flag_string.split(',')]
        except:
            return [0] * 8
    
    def _calculate_entropy(self, series: pd.Series, window: int = None) -> pd.Series:
        """Calculate entropy of a series"""
        if window is None:
            window = self.config['entropy_window']
        
        def _entropy_func(x):
            if len(x) == 0:
                return 0
            value_counts = x.value_counts()
            probabilities = value_counts / len(x)
            return entropy(probabilities)
        
        return series.rolling(window=window, min_periods=1).apply(_entropy_func, raw=False)
    
    def _create_time_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create time-based features"""
        logger.info("Creating time-based features")
        
        # Convert to datetime if not already
        for col in ['start_time', 'end_time']:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col])
        
        # Time of day features
        if 'start_time' in df.columns:
            df['hour'] = df['start_time'].dt.hour
            df['day_of_week'] = df['start_time'].dt.dayofweek
            df['is_weekend'] = (df['day_of_week'] >= 5).astype(int)
            df['is_night'] = ((df['hour'] >= 22) | (df['hour'] <= 6)).astype(int)
            df['is_business_hours'] = ((df['hour'] >= 9) & (df['hour'] <= 17)).astype(int)
        
        # Time since epoch (for trend analysis)
        if 'start_time' in df.columns:
            df['time_since_epoch'] = df['start_time'].astype('int64') // 10**9
        
        return df
    
    def _create_protocol_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create protocol-based features"""
        logger.info("Creating protocol-based features")
        
        if 'protocol' in df.columns:
            # Protocol frequency
            protocol_counts = df['protocol'].value_counts()
            df['protocol_frequency'] = df['protocol'].map(protocol_counts)
            
            # Protocol entropy
            df['protocol_entropy'] = self._calculate_entropy(df['protocol'])
            
            # One-hot encoding for common protocols
            common_protocols = [1, 6, 17]  # ICMP, TCP, UDP
            for protocol in common_protocols:
                df[f'is_protocol_{protocol}'] = (df['protocol'] == protocol).astype(int)
        
        return df
    
    def _create_port_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create port-based features"""
        logger.info("Creating port-based features")
        
        for port_col in ['src_port', 'dst_port']:
            if port_col in df.columns:
                # Port ranges
                df[f'{port_col}_range'] = pd.cut(df[port_col], 
                                                bins=[0, 1024, 49152, 65535], 
                                                labels=['well_known', 'registered', 'dynamic'])
                
                # Well-known ports
                df[f'{port_col}_is_well_known'] = (df[port_col] < 1024).astype(int)
                df[f'{port_col}_is_privileged'] = (df[port_col] < 1024).astype(int)
                
                # Port entropy
                df[f'{port_col}_entropy'] = self._calculate_entropy(df[port_col])
                
                # Port frequency
                port_counts = df[port_col].value_counts()
                df[f'{port_col}_frequency'] = df[port_col].map(port_counts)
        
        return df
    
    def _create_ip_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create IP-based features"""
        logger.info("Creating IP-based features")
        
        for ip_col in ['src_ip', 'dst_ip']:
            if ip_col in df.columns:
                # IP frequency
                ip_counts = df[ip_col].value_counts()
                df[f'{ip_col}_frequency'] = df[ip_col].map(ip_counts)
                
                # IP entropy
                df[f'{ip_col}_entropy'] = self._calculate_entropy(df[ip_col])
                
                # Private IP detection
                df[f'{ip_col}_is_private'] = df[ip_col].str.match(
                    r'^(10\.|172\.(1[6-9]|2[0-9]|3[01])\.|192\.168\.)'
                ).astype(int)
                
                # IP class (simplified)
                df[f'{ip_col}_class'] = df[ip_col].str.split('.').str[0].astype(int)
        
        return df
    
    def _create_tcp_flag_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create TCP flag-based features"""
        logger.info("Creating TCP flag features")
        
        if 'tcp_flag_counts' in df.columns:
            # Parse TCP flags
            tcp_flags = df['tcp_flag_counts'].apply(self._extract_tcp_flags)
            tcp_flag_df = pd.DataFrame(tcp_flags.tolist(), 
                                     columns=['FIN', 'SYN', 'RST', 'PSH', 'ACK', 'URG', 'ECE', 'CWR'])
            
            # Add individual flag columns
            for flag in tcp_flag_df.columns:
                df[f'tcp_{flag.lower()}'] = tcp_flag_df[flag]
            
            # Flag combinations
            df['tcp_syn_ack'] = ((df['tcp_syn'] == 1) & (df['tcp_ack'] == 1)).astype(int)
            df['tcp_fin_ack'] = ((df['tcp_fin'] == 1) & (df['tcp_ack'] == 1)).astype(int)
            df['tcp_rst_ack'] = ((df['tcp_rst'] == 1) & (df['tcp_ack'] == 1)).astype(int)
            
            # Total flags
            df['tcp_total_flags'] = tcp_flag_df.sum(axis=1)
            
            # Flag entropy
            df['tcp_flag_entropy'] = tcp_flag_df.apply(
                lambda x: entropy(x + 1) if x.sum() > 0 else 0, axis=1
            )
        
        return df
    
    def _create_statistical_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create statistical features"""
        logger.info("Creating statistical features")
        
        # Basic statistics for numerical features
        numerical_cols = [col for col in self.config['numerical_features'] if col in df.columns]
        
        for col in numerical_cols:
            if col in df.columns:
                # Log transform for skewed features
                if col in ['total_bytes', 'total_packets', 'duration']:
                    df[f'{col}_log'] = np.log1p(df[col])
                
                # Square root transform
                df[f'{col}_sqrt'] = np.sqrt(df[col])
                
                # Z-score normalization
                df[f'{col}_zscore'] = stats.zscore(df[col])
                
                # Percentile features
                df[f'{col}_percentile'] = df[col].rank(pct=True)
        
        return df
    
    def _create_rolling_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create rolling window features"""
        logger.info("Creating rolling window features")
        
        window = self.config['rolling_window']
        numerical_cols = [col for col in self.config['numerical_features'] if col in df.columns]
        
        # Sort by time if available
        if 'start_time' in df.columns:
            df = df.sort_values('start_time').reset_index(drop=True)
        
        for col in numerical_cols:
            if col in df.columns:
                # Rolling statistics
                df[f'{col}_rolling_mean'] = df[col].rolling(window=window, min_periods=1).mean()
                df[f'{col}_rolling_std'] = df[col].rolling(window=window, min_periods=1).std()
                df[f'{col}_rolling_min'] = df[col].rolling(window=window, min_periods=1).min()
                df[f'{col}_rolling_max'] = df[col].rolling(window=window, min_periods=1).max()
                
                # Rolling ratios
                df[f'{col}_rolling_ratio'] = df[col] / df[f'{col}_rolling_mean']
        
        return df
    
    def _create_interaction_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create interaction features"""
        logger.info("Creating interaction features")
        
        if not self.config['create_interactions']:
            return df
        
        # Byte rate
        if 'total_bytes' in df.columns and 'duration' in df.columns:
            df['byte_rate'] = df['total_bytes'] / (df['duration'] + 1)
        
        # Packet size ratio
        if 'total_bytes' in df.columns and 'total_packets' in df.columns:
            df['packet_size_ratio'] = df['total_bytes'] / (df['total_packets'] + 1)
        
        # Flow efficiency
        if 'total_packets' in df.columns and 'duration' in df.columns:
            df['flow_efficiency'] = df['total_packets'] / (df['duration'] + 1)
        
        # Protocol-port interactions
        if 'protocol' in df.columns and 'src_port' in df.columns:
            df['protocol_src_port'] = df['protocol'].astype(str) + '_' + df['src_port'].astype(str)
        
        if 'protocol' in df.columns and 'dst_port' in df.columns:
            df['protocol_dst_port'] = df['protocol'].astype(str) + '_' + df['dst_port'].astype(str)
        
        return df
    
    def _create_polynomial_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create polynomial features"""
        logger.info("Creating polynomial features")
        
        if not self.config['create_polynomial']:
            return df
        
        degree = self.config['polynomial_degree']
        numerical_cols = [col for col in self.config['numerical_features'] if col in df.columns]
        
        # Select most important numerical features for polynomial expansion
        important_cols = numerical_cols[:5]  # Limit to avoid explosion
        
        for col in important_cols:
            if col in df.columns:
                for d in range(2, degree + 1):
                    df[f'{col}_pow_{d}'] = df[col] ** d
        
        return df
    
    def _encode_categorical_features(self, df: pd.DataFrame, fit: bool = True) -> pd.DataFrame:
        """Encode categorical features"""
        logger.info("Encoding categorical features")
        
        categorical_cols = [col for col in self.config['categorical_features'] if col in df.columns]
        
        for col in categorical_cols:
            if col in df.columns:
                if fit:
                    # Fit encoder
                    if col not in self.encoders:
                        self.encoders[col] = LabelEncoder()
                    self.encoders[col].fit(df[col])
                
                # Transform
                df[f'{col}_encoded'] = self.encoders[col].transform(df[col])
        
        return df
    
    def _normalize_features(self, df: pd.DataFrame, fit: bool = True) -> pd.DataFrame:
        """Normalize numerical features"""
        logger.info("Normalizing features")
        
        if not self.config['normalize_features']:
            return df
        
        # Get all numerical columns (excluding target and ID columns)
        numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        exclude_cols = ['flow_id', 'label', 'start_time', 'end_time']
        numerical_cols = [col for col in numerical_cols if col not in exclude_cols]
        
        if fit:
            # Fit scaler
            self.scalers['standard'] = StandardScaler()
            self.scalers['standard'].fit(df[numerical_cols])
        
        # Transform
        df[numerical_cols] = self.scalers['standard'].transform(df[numerical_cols])
        
        return df
    
    def fit_transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """Fit feature engineering pipeline and transform data"""
        logger.info("Fitting and transforming features")
        
        # Create a copy to avoid modifying original
        df_transformed = df.copy()
        
        # Apply all feature engineering steps
        df_transformed = self._create_time_features(df_transformed)
        df_transformed = self._create_protocol_features(df_transformed)
        df_transformed = self._create_port_features(df_transformed)
        df_transformed = self._create_ip_features(df_transformed)
        df_transformed = self._create_tcp_flag_features(df_transformed)
        df_transformed = self._create_statistical_features(df_transformed)
        df_transformed = self._create_rolling_features(df_transformed)
        df_transformed = self._create_interaction_features(df_transformed)
        df_transformed = self._create_polynomial_features(df_transformed)
        df_transformed = self._encode_categorical_features(df_transformed, fit=True)
        df_transformed = self._normalize_features(df_transformed, fit=True)
        
        # Store feature names
        self.feature_names = [col for col in df_transformed.columns 
                            if col not in ['flow_id', 'label', 'start_time', 'end_time']]
        
        self.is_fitted = True
        logger.info(f"Created {len(self.feature_names)} features")
        
        return df_transformed
    
    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """Transform data using fitted pipeline"""
        if not self.is_fitted:
            raise ValueError("Pipeline must be fitted before transform")
        
        logger.info("Transforming features")
        
        # Create a copy to avoid modifying original
        df_transformed = df.copy()
        
        # Apply all feature engineering steps (without fitting)
        df_transformed = self._create_time_features(df_transformed)
        df_transformed = self._create_protocol_features(df_transformed)
        df_transformed = self._create_port_features(df_transformed)
        df_transformed = self._create_ip_features(df_transformed)
        df_transformed = self._create_tcp_flag_features(df_transformed)
        df_transformed = self._create_statistical_features(df_transformed)
        df_transformed = self._create_rolling_features(df_transformed)
        df_transformed = self._create_interaction_features(df_transformed)
        df_transformed = self._create_polynomial_features(df_transformed)
        df_transformed = self._encode_categorical_features(df_transformed, fit=False)
        df_transformed = self._normalize_features(df_transformed, fit=False)
        
        return df_transformed
    
    def get_feature_names(self) -> List[str]:
        """Get list of feature names"""
        return self.feature_names
    
    def save_pipeline(self, filepath: str):
        """Save the fitted pipeline"""
        pipeline_data = {
            'config': self.config,
            'scalers': self.scalers,
            'encoders': self.encoders,
            'feature_names': self.feature_names,
            'is_fitted': self.is_fitted
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(pipeline_data, f)
        
        logger.info(f"Saved pipeline to {filepath}")
    
    def load_pipeline(self, filepath: str):
        """Load a fitted pipeline"""
        with open(filepath, 'rb') as f:
            pipeline_data = pickle.load(f)
        
        self.config = pipeline_data['config']
        self.scalers = pipeline_data['scalers']
        self.encoders = pipeline_data['encoders']
        self.feature_names = pipeline_data['feature_names']
        self.is_fitted = pipeline_data['is_fitted']
        
        logger.info(f"Loaded pipeline from {filepath}")

def create_feature_engineering_pipeline(config: Optional[Dict] = None) -> FeatureEngineer:
    """
    Create a feature engineering pipeline
    
    Args:
        config: Configuration dictionary
        
    Returns:
        FeatureEngineer instance
    """
    return FeatureEngineer(config)

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Feature engineering for intrusion detection")
    parser.add_argument("input_file", help="Input CSV file")
    parser.add_argument("output_file", help="Output CSV file")
    parser.add_argument("--pipeline_file", help="Pipeline file to save/load")
    parser.add_argument("--mode", choices=['fit_transform', 'transform'], default='fit_transform',
                       help="Mode: fit_transform or transform")
    
    args = parser.parse_args()
    
    # Load data
    df = pd.read_csv(args.input_file)
    logger.info(f"Loaded {len(df)} samples")
    
    # Create feature engineer
    feature_engineer = FeatureEngineer()
    
    if args.mode == 'fit_transform':
        # Fit and transform
        df_transformed = feature_engineer.fit_transform(df)
        
        # Save pipeline
        if args.pipeline_file:
            feature_engineer.save_pipeline(args.pipeline_file)
    else:
        # Load pipeline and transform
        if args.pipeline_file:
            feature_engineer.load_pipeline(args.pipeline_file)
        else:
            logger.error("Pipeline file required for transform mode")
            exit(1)
        
        df_transformed = feature_engineer.transform(df)
    
    # Save transformed data
    df_transformed.to_csv(args.output_file, index=False)
    logger.info(f"Saved {len(df_transformed)} samples with {len(feature_engineer.get_feature_names())} features to {args.output_file}")
