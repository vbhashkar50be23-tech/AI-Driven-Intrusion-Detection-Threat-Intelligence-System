"""
Response Automation Demo for AIDTIS
⚠️ SAFETY WARNING: This is for demonstration purposes only!
Never run on production networks or host systems.
"""

import os
import subprocess
import logging
import json
import time
from typing import Dict, List, Optional, Any
from datetime import datetime
import requests
import ipaddress

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ResponseAutomation:
    """
    Demo response automation system
    ⚠️ SAFETY WARNING: Only use in isolated Docker networks!
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize response automation
        
        Args:
            config: Configuration dictionary
        """
        self.config = config or self._default_config()
        self.blocked_ips = set()
        self.response_log = []
        
        # Safety checks
        self._safety_checks()
    
    def _default_config(self) -> Dict:
        """Default configuration"""
        return {
            "api_url": "http://localhost:8000",
            "confidence_threshold": 0.8,
            "block_duration": 3600,  # 1 hour
            "max_blocks_per_hour": 10,
            "allowed_networks": ["172.20.0.0/16"],  # Docker network
            "blocked_networks": ["10.0.0.0/8", "192.168.0.0/16"],  # Never block these
            "enable_auto_blocking": False,  # Default to False for safety
            "log_file": "response_automation.log"
        }
    
    def _safety_checks(self):
        """Perform safety checks before allowing any operations"""
        logger.warning("⚠️ SAFETY CHECKS ⚠️")
        logger.warning("This system is for DEMONSTRATION PURPOSES ONLY!")
        logger.warning("Never run on production networks or host systems!")
        
        # Check if we're in a Docker container
        if not os.path.exists('/.dockerenv'):
            logger.error("❌ Not running in Docker container - ABORTING for safety!")
            raise RuntimeError("Response automation only allowed in Docker containers")
        
        # Check if auto-blocking is enabled
        if not self.config.get("enable_auto_blocking", False):
            logger.warning("⚠️ Auto-blocking is DISABLED for safety")
            logger.warning("Set enable_auto_blocking=True in config to enable (NOT RECOMMENDED)")
        
        # Check network interface
        try:
            result = subprocess.run(['ip', 'route', 'show'], capture_output=True, text=True)
            logger.info(f"Current network routes: {result.stdout}")
        except Exception as e:
            logger.warning(f"Could not check network routes: {e}")
        
        logger.info("✅ Safety checks completed")
    
    def is_ip_allowed(self, ip: str) -> bool:
        """Check if IP is in allowed networks for blocking"""
        try:
            ip_obj = ipaddress.ip_address(ip)
            
            # Check if IP is in blocked networks (never block these)
            for blocked_net in self.config.get("blocked_networks", []):
                if ip_obj in ipaddress.ip_network(blocked_net):
                    logger.warning(f"IP {ip} is in blocked network {blocked_net} - will not block")
                    return False
            
            # Check if IP is in allowed networks
            for allowed_net in self.config.get("allowed_networks", []):
                if ip_obj in ipaddress.ip_network(allowed_net):
                    return True
            
            logger.warning(f"IP {ip} not in allowed networks - will not block")
            return False
            
        except Exception as e:
            logger.error(f"Error checking IP {ip}: {e}")
            return False
    
    def block_ip_iptables(self, ip: str, duration: int = None) -> bool:
        """
        Block IP using iptables (Docker network only!)
        
        Args:
            ip: IP address to block
            duration: Block duration in seconds
            
        Returns:
            True if successful, False otherwise
        """
        if not self.config.get("enable_auto_blocking", False):
            logger.warning("Auto-blocking is disabled - simulating block")
            return self._simulate_block(ip, duration)
        
        if not self.is_ip_allowed(ip):
            return False
        
        duration = duration or self.config.get("block_duration", 3600)
        
        try:
            # Add iptables rule to block IP
            cmd = [
                'iptables', '-I', 'INPUT', '-s', ip, '-j', 'DROP'
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                logger.info(f"✅ Blocked IP {ip} for {duration} seconds")
                
                # Schedule unblock
                self._schedule_unblock(ip, duration)
                
                # Log the action
                self._log_response("block", ip, duration)
                
                return True
            else:
                logger.error(f"Failed to block IP {ip}: {result.stderr}")
                return False
                
        except Exception as e:
            logger.error(f"Error blocking IP {ip}: {e}")
            return False
    
    def unblock_ip_iptables(self, ip: str) -> bool:
        """
        Unblock IP using iptables
        
        Args:
            ip: IP address to unblock
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Remove iptables rule
            cmd = [
                'iptables', '-D', 'INPUT', '-s', ip, '-j', 'DROP'
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                logger.info(f"✅ Unblocked IP {ip}")
                self.blocked_ips.discard(ip)
                self._log_response("unblock", ip, 0)
                return True
            else:
                logger.error(f"Failed to unblock IP {ip}: {result.stderr}")
                return False
                
        except Exception as e:
            logger.error(f"Error unblocking IP {ip}: {e}")
            return False
    
    def _simulate_block(self, ip: str, duration: int) -> bool:
        """Simulate blocking without actually blocking"""
        logger.info(f"🎭 SIMULATING block of IP {ip} for {duration} seconds")
        self.blocked_ips.add(ip)
        self._log_response("simulate_block", ip, duration)
        return True
    
    def _schedule_unblock(self, ip: str, duration: int):
        """Schedule IP unblocking"""
        def unblock_later():
            time.sleep(duration)
            self.unblock_ip_iptables(ip)
        
        import threading
        thread = threading.Thread(target=unblock_later)
        thread.daemon = True
        thread.start()
    
    def _log_response(self, action: str, ip: str, duration: int):
        """Log response action"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "ip": ip,
            "duration": duration,
            "blocked_ips_count": len(self.blocked_ips)
        }
        
        self.response_log.append(log_entry)
        
        # Write to log file
        log_file = self.config.get("log_file", "response_automation.log")
        with open(log_file, "a") as f:
            f.write(json.dumps(log_entry) + "\n")
    
    def get_blocked_ips(self) -> List[str]:
        """Get list of currently blocked IPs"""
        return list(self.blocked_ips)
    
    def get_response_log(self, limit: int = 100) -> List[Dict]:
        """Get response log entries"""
        return self.response_log[-limit:]
    
    def clear_blocks(self):
        """Clear all blocked IPs"""
        for ip in list(self.blocked_ips):
            self.unblock_ip_iptables(ip)
        logger.info("Cleared all blocked IPs")

class CloudFirewallIntegration:
    """
    Mock cloud firewall integration
    This is pseudocode showing how production systems would integrate
    """
    
    def __init__(self, provider: str = "aws"):
        self.provider = provider
        logger.info(f"Initialized {provider} firewall integration (MOCK)")
    
    def block_ip_aws_waf(self, ip: str, rule_group_id: str) -> bool:
        """
        Mock AWS WAF IP blocking
        In production, this would call AWS WAF API
        """
        logger.info(f"🎭 MOCK: Would block IP {ip} in AWS WAF rule group {rule_group_id}")
        logger.info("Production implementation would:")
        logger.info("1. Call AWS WAF API")
        logger.info("2. Add IP to IP set")
        logger.info("3. Update rule group")
        logger.info("4. Deploy changes")
        return True
    
    def block_ip_cloudflare(self, ip: str, zone_id: str) -> bool:
        """
        Mock Cloudflare IP blocking
        In production, this would call Cloudflare API
        """
        logger.info(f"🎭 MOCK: Would block IP {ip} in Cloudflare zone {zone_id}")
        logger.info("Production implementation would:")
        logger.info("1. Call Cloudflare API")
        logger.info("2. Create firewall rule")
        logger.info("3. Apply to zone")
        return True
    
    def block_ip_azure_waf(self, ip: str, policy_name: str) -> bool:
        """
        Mock Azure WAF IP blocking
        In production, this would call Azure API
        """
        logger.info(f"🎭 MOCK: Would block IP {ip} in Azure WAF policy {policy_name}")
        logger.info("Production implementation would:")
        logger.info("1. Call Azure REST API")
        logger.info("2. Update WAF policy")
        logger.info("3. Deploy to application gateway")
        return True

class ThreatResponseOrchestrator:
    """
    Orchestrates threat response actions
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.response_automation = ResponseAutomation(config)
        self.cloud_firewall = CloudFirewallIntegration()
        self.api_url = config.get("api_url", "http://localhost:8000") if config else "http://localhost:8000"
    
    def process_threat_alert(self, alert_data: Dict) -> Dict:
        """
        Process threat alert and determine response
        
        Args:
            alert_data: Alert data from detection system
            
        Returns:
            Response action taken
        """
        logger.info(f"Processing threat alert: {alert_data}")
        
        # Extract threat information
        src_ip = alert_data.get("src_ip")
        confidence = alert_data.get("confidence", 0.0)
        attack_type = alert_data.get("prediction", "UNKNOWN")
        
        if not src_ip:
            logger.error("No source IP in alert data")
            return {"action": "none", "reason": "no_source_ip"}
        
        # Check confidence threshold
        confidence_threshold = self.config.get("confidence_threshold", 0.8)
        if confidence < confidence_threshold:
            logger.info(f"Confidence {confidence} below threshold {confidence_threshold}")
            return {"action": "none", "reason": "low_confidence"}
        
        # Determine response based on attack type
        response = self._determine_response(attack_type, confidence)
        
        # Execute response
        if response["action"] == "block":
            success = self.response_automation.block_ip_iptables(src_ip)
            response["success"] = success
            response["ip"] = src_ip
        
        return response
    
    def _determine_response(self, attack_type: str, confidence: float) -> Dict:
        """Determine appropriate response based on attack type"""
        # High-confidence attacks
        if confidence >= 0.9:
            if attack_type in ["DOS", "DDoS"]:
                return {"action": "block", "reason": "high_confidence_dos"}
            elif attack_type in ["R2L", "U2R"]:
                return {"action": "block", "reason": "high_confidence_privilege_escalation"}
            else:
                return {"action": "monitor", "reason": "high_confidence_other"}
        
        # Medium-confidence attacks
        elif confidence >= 0.7:
            if attack_type in ["DOS", "DDoS"]:
                return {"action": "rate_limit", "reason": "medium_confidence_dos"}
            else:
                return {"action": "monitor", "reason": "medium_confidence"}
        
        # Low-confidence attacks
        else:
            return {"action": "log", "reason": "low_confidence"}
    
    def get_response_statistics(self) -> Dict:
        """Get response statistics"""
        blocked_ips = self.response_automation.get_blocked_ips()
        response_log = self.response_automation.get_response_log()
        
        return {
            "currently_blocked_ips": len(blocked_ips),
            "total_responses": len(response_log),
            "blocked_ips": blocked_ips,
            "recent_responses": response_log[-10:]
        }

def demo_response_automation():
    """Demo function showing response automation capabilities"""
    logger.info("🚀 Starting Response Automation Demo")
    logger.warning("⚠️ This is a DEMONSTRATION - no real blocking will occur")
    
    # Initialize with safe configuration
    config = {
        "enable_auto_blocking": False,  # Safety first!
        "confidence_threshold": 0.8,
        "allowed_networks": ["172.20.0.0/16"],  # Docker network
        "blocked_networks": ["10.0.0.0/8", "192.168.0.0/16"]
    }
    
    orchestrator = ThreatResponseOrchestrator(config)
    
    # Simulate threat alerts
    test_alerts = [
        {
            "src_ip": "172.20.0.100",
            "dst_ip": "172.20.0.1",
            "prediction": "DOS",
            "confidence": 0.95
        },
        {
            "src_ip": "172.20.0.101",
            "dst_ip": "172.20.0.1",
            "prediction": "PROBE",
            "confidence": 0.75
        },
        {
            "src_ip": "10.0.0.1",  # This should not be blocked
            "dst_ip": "172.20.0.1",
            "prediction": "DOS",
            "confidence": 0.95
        }
    ]
    
    # Process alerts
    for alert in test_alerts:
        logger.info(f"Processing alert: {alert}")
        response = orchestrator.process_threat_alert(alert)
        logger.info(f"Response: {response}")
    
    # Show statistics
    stats = orchestrator.get_response_statistics()
    logger.info(f"Response statistics: {stats}")
    
    logger.info("✅ Demo completed")

if __name__ == "__main__":
    demo_response_automation()
