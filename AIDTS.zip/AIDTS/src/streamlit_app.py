"""
Streamlit Dashboard for AIDTIS
Interactive web interface for intrusion detection monitoring
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import requests
import json
import time
from datetime import datetime, timedelta
import io
import base64
from typing import Dict, List, Optional, Any
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="AIDTIS Dashboard",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #1f77b4;
    }
    .alert-card {
        background-color: #fff3cd;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #ffc107;
        margin: 0.5rem 0;
    }
    .threat-card {
        background-color: #f8d7da;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #dc3545;
        margin: 0.5rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Configuration
API_BASE_URL = "http://localhost:8000"
REFRESH_INTERVAL = 30  # seconds

class AIDTISDashboard:
    """Main dashboard class"""
    
    def __init__(self):
        self.api_url = API_BASE_URL
        self.session = requests.Session()
        
    def check_api_health(self) -> bool:
        """Check if API is healthy"""
        try:
            response = self.session.get(f"{self.api_url}/health", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def get_api_models(self) -> List[Dict]:
        """Get available models from API"""
        try:
            response = self.session.get(f"{self.api_url}/models", timeout=5)
            if response.status_code == 200:
                return response.json()
            return []
        except:
            return []
    
    def predict_flow(self, flow_data: Dict, model_name: str = "random_forest") -> Optional[Dict]:
        """Predict single flow"""
        try:
            response = self.session.post(
                f"{self.api_url}/predict",
                json={"flow": flow_data, "model_name": model_name},
                timeout=10
            )
            if response.status_code == 200:
                return response.json()
            return None
        except Exception as e:
            st.error(f"Prediction error: {e}")
            return None
    
    def predict_batch(self, flows_data: List[Dict], model_name: str = "random_forest") -> Optional[Dict]:
        """Predict batch of flows"""
        try:
            response = self.session.post(
                f"{self.api_url}/predict/batch",
                json={"flows": flows_data, "model_name": model_name},
                timeout=30
            )
            if response.status_code == 200:
                return response.json()
            return None
        except Exception as e:
            st.error(f"Batch prediction error: {e}")
            return None
    
    def predict_csv(self, csv_file, model_name: str = "random_forest") -> Optional[Dict]:
        """Predict from CSV file"""
        try:
            files = {"file": ("data.csv", csv_file, "text/csv")}
            response = self.session.post(
                f"{self.api_url}/predict/csv",
                files=files,
                data={"model_name": model_name},
                timeout=60
            )
            if response.status_code == 200:
                return response.json()
            return None
        except Exception as e:
            st.error(f"CSV prediction error: {e}")
            return None

def render_header():
    """Render dashboard header"""
    st.markdown('<h1 class="main-header">🛡️ AIDTIS Dashboard</h1>', unsafe_allow_html=True)
    st.markdown("**AI-Driven Intrusion Detection & Threat Intelligence System**")
    
    # API status
    dashboard = AIDTISDashboard()
    api_healthy = dashboard.check_api_health()
    
    if api_healthy:
        st.success("🟢 API Connected")
    else:
        st.error("🔴 API Disconnected - Please start the API server")
        st.stop()

def render_sidebar():
    """Render sidebar with controls"""
    st.sidebar.title("🎛️ Controls")
    
    # Model selection
    dashboard = AIDTISDashboard()
    models = dashboard.get_api_models()
    
    if models:
        model_names = [model["name"] for model in models]
        selected_model = st.sidebar.selectbox("Select Model", model_names)
    else:
        selected_model = "random_forest"
        st.sidebar.warning("No models available")
    
    # Refresh settings
    st.sidebar.subheader("🔄 Refresh Settings")
    auto_refresh = st.sidebar.checkbox("Auto Refresh", value=True)
    refresh_interval = st.sidebar.slider("Refresh Interval (seconds)", 10, 300, 30)
    
    # Display settings
    st.sidebar.subheader("📊 Display Settings")
    max_alerts = st.sidebar.slider("Max Alerts to Display", 10, 1000, 100)
    confidence_threshold = st.sidebar.slider("Confidence Threshold", 0.0, 1.0, 0.7)
    
    return {
        "selected_model": selected_model,
        "auto_refresh": auto_refresh,
        "refresh_interval": refresh_interval,
        "max_alerts": max_alerts,
        "confidence_threshold": confidence_threshold
    }

def render_overview_metrics():
    """Render overview metrics"""
    st.subheader("📊 Overview Metrics")
    
    # Create placeholder metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="Total Flows",
            value="1,234",
            delta="+12"
        )
    
    with col2:
        st.metric(
            label="Threats Detected",
            value="23",
            delta="+3"
        )
    
    with col3:
        st.metric(
            label="False Positives",
            value="2",
            delta="-1"
        )
    
    with col4:
        st.metric(
            label="Detection Rate",
            value="95.2%",
            delta="+2.1%"
        )

def render_threat_timeline():
    """Render threat detection timeline"""
    st.subheader("📈 Threat Detection Timeline")
    
    # Generate sample data
    dates = pd.date_range(start=datetime.now() - timedelta(hours=24), 
                         end=datetime.now(), freq='H')
    threats = np.random.poisson(2, len(dates))
    
    df_timeline = pd.DataFrame({
        'timestamp': dates,
        'threats': threats,
        'confidence': np.random.uniform(0.6, 0.95, len(dates))
    })
    
    # Create plot
    fig = make_subplots(
        rows=2, cols=1,
        subplot_titles=('Threats per Hour', 'Average Confidence'),
        vertical_spacing=0.1
    )
    
    # Threats timeline
    fig.add_trace(
        go.Scatter(
            x=df_timeline['timestamp'],
            y=df_timeline['threats'],
            mode='lines+markers',
            name='Threats',
            line=dict(color='red', width=2)
        ),
        row=1, col=1
    )
    
    # Confidence timeline
    fig.add_trace(
        go.Scatter(
            x=df_timeline['timestamp'],
            y=df_timeline['confidence'],
            mode='lines+markers',
            name='Confidence',
            line=dict(color='blue', width=2)
        ),
        row=2, col=1
    )
    
    fig.update_layout(
        height=400,
        showlegend=False,
        title_text="Real-time Threat Monitoring"
    )
    
    st.plotly_chart(fig, use_container_width=True)

def render_attack_types():
    """Render attack type distribution"""
    st.subheader("🎯 Attack Type Distribution")
    
    # Sample attack data
    attack_types = ['DOS', 'PROBE', 'R2L', 'U2R', 'WEB_ATTACK', 'BOT']
    attack_counts = [45, 23, 12, 8, 15, 7]
    
    # Create pie chart
    fig = px.pie(
        values=attack_counts,
        names=attack_types,
        title="Attack Types Detected (Last 24h)",
        color_discrete_sequence=px.colors.qualitative.Set3
    )
    
    st.plotly_chart(fig, use_container_width=True)

def render_top_attackers():
    """Render top attacking IPs"""
    st.subheader("🔴 Top Attacking IPs")
    
    # Sample attacker data
    attackers = [
        {'ip': '192.168.1.100', 'attacks': 23, 'threat_level': 'High'},
        {'ip': '10.0.0.50', 'attacks': 18, 'threat_level': 'High'},
        {'ip': '172.16.0.25', 'attacks': 15, 'threat_level': 'Medium'},
        {'ip': '203.0.113.10', 'attacks': 12, 'threat_level': 'Medium'},
        {'ip': '198.51.100.5', 'attacks': 8, 'threat_level': 'Low'}
    ]
    
    df_attackers = pd.DataFrame(attackers)
    
    # Create bar chart
    fig = px.bar(
        df_attackers,
        x='ip',
        y='attacks',
        color='threat_level',
        title="Attack Count by IP Address",
        color_discrete_map={'High': 'red', 'Medium': 'orange', 'Low': 'yellow'}
    )
    
    fig.update_layout(xaxis_title="IP Address", yaxis_title="Number of Attacks")
    st.plotly_chart(fig, use_container_width=True)

def render_recent_alerts():
    """Render recent alerts table"""
    st.subheader("🚨 Recent Alerts")
    
    # Sample alert data
    alerts = []
    for i in range(20):
        alerts.append({
            'timestamp': datetime.now() - timedelta(minutes=np.random.randint(1, 1440)),
            'src_ip': f"192.168.1.{np.random.randint(1, 255)}",
            'dst_ip': f"10.0.0.{np.random.randint(1, 255)}",
            'attack_type': np.random.choice(['DOS', 'PROBE', 'R2L', 'WEB_ATTACK']),
            'confidence': np.random.uniform(0.6, 0.95),
            'severity': np.random.choice(['Low', 'Medium', 'High'])
        })
    
    df_alerts = pd.DataFrame(alerts)
    df_alerts = df_alerts.sort_values('timestamp', ascending=False)
    
    # Color code severity
    def color_severity(val):
        if val == 'High':
            return 'background-color: #f8d7da'
        elif val == 'Medium':
            return 'background-color: #fff3cd'
        else:
            return 'background-color: #d1ecf1'
    
    styled_df = df_alerts.style.applymap(color_severity, subset=['severity'])
    st.dataframe(styled_df, use_container_width=True)

def render_single_flow_prediction():
    """Render single flow prediction interface"""
    st.subheader("🔍 Single Flow Prediction")
    
    with st.form("flow_prediction_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            src_ip = st.text_input("Source IP", value="192.168.1.100")
            dst_ip = st.text_input("Destination IP", value="10.0.0.1")
            src_port = st.number_input("Source Port", value=12345, min_value=1, max_value=65535)
            dst_port = st.number_input("Destination Port", value=80, min_value=1, max_value=65535)
            protocol = st.selectbox("Protocol", [1, 6, 17], format_func=lambda x: {1: "ICMP", 6: "TCP", 17: "UDP"}[x])
        
        with col2:
            duration = st.number_input("Duration (seconds)", value=1.5, min_value=0.0)
            total_bytes = st.number_input("Total Bytes", value=1024, min_value=0)
            total_packets = st.number_input("Total Packets", value=10, min_value=0)
            avg_pkt_size = st.number_input("Avg Packet Size", value=102.4, min_value=0.0)
            pkt_rate = st.number_input("Packet Rate", value=6.67, min_value=0.0)
            mean_iat = st.number_input("Mean IAT", value=0.15, min_value=0.0)
        
        submitted = st.form_submit_button("Predict")
        
        if submitted:
            flow_data = {
                "src_ip": src_ip,
                "dst_ip": dst_ip,
                "src_port": src_port,
                "dst_port": dst_port,
                "protocol": protocol,
                "start_time": datetime.now().isoformat(),
                "end_time": (datetime.now() + timedelta(seconds=duration)).isoformat(),
                "duration": duration,
                "total_bytes": total_bytes,
                "total_packets": total_packets,
                "avg_pkt_size": avg_pkt_size,
                "pkt_rate": pkt_rate,
                "mean_iat": mean_iat,
                "tcp_flag_counts": "0,0,0,0,0,0,0,0"
            }
            
            dashboard = AIDTISDashboard()
            result = dashboard.predict_flow(flow_data)
            
            if result:
                st.success("✅ Prediction completed!")
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Prediction", result['prediction'])
                with col2:
                    st.metric("Confidence", f"{result['confidence']:.3f}")
                with col3:
                    st.metric("Model Used", result['model_used'])
                
                # Show probabilities
                st.subheader("📊 Prediction Probabilities")
                prob_df = pd.DataFrame(list(result['probabilities'].items()), 
                                     columns=['Class', 'Probability'])
                st.bar_chart(prob_df.set_index('Class'))
                
                # Show feature importance if available
                if result.get('feature_importance'):
                    st.subheader("🔍 Top Contributing Features")
                    importance_df = pd.DataFrame(list(result['feature_importance'].items()),
                                               columns=['Feature', 'Importance'])
                    st.bar_chart(importance_df.set_index('Feature'))

def render_batch_prediction():
    """Render batch prediction interface"""
    st.subheader("📁 Batch Prediction")
    
    # File upload
    uploaded_file = st.file_uploader("Upload CSV file", type=['csv'])
    
    if uploaded_file is not None:
        try:
            # Read CSV
            df = pd.read_csv(uploaded_file)
            st.write(f"📊 Loaded {len(df)} flows")
            st.dataframe(df.head())
            
            # Model selection
            dashboard = AIDTISDashboard()
            models = dashboard.get_api_models()
            if models:
                model_names = [model["name"] for model in models]
                selected_model = st.selectbox("Select Model for Batch Prediction", model_names)
            else:
                selected_model = "random_forest"
            
            if st.button("🚀 Run Batch Prediction"):
                with st.spinner("Processing batch prediction..."):
                    # Reset file pointer
                    uploaded_file.seek(0)
                    result = dashboard.predict_csv(uploaded_file, selected_model)
                
                if result:
                    st.success(f"✅ Processed {result['total_flows']} flows in {result['processing_time']:.2f} seconds")
                    
                    # Show results summary
                    predictions = result['predictions']
                    pred_df = pd.DataFrame(predictions)
                    
                    # Summary statistics
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Flows", len(predictions))
                    with col2:
                        threats = sum(1 for p in predictions if p['prediction'] != 'BENIGN')
                        st.metric("Threats Detected", threats)
                    with col3:
                        avg_confidence = np.mean([p['confidence'] for p in predictions])
                        st.metric("Avg Confidence", f"{avg_confidence:.3f}")
                    
                    # Show detailed results
                    st.subheader("📋 Detailed Results")
                    st.dataframe(pred_df[['flow_id', 'prediction', 'confidence', 'model_used']])
                    
                    # Download results
                    csv = pred_df.to_csv(index=False)
                    st.download_button(
                        label="📥 Download Results",
                        data=csv,
                        file_name=f"prediction_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                        mime="text/csv"
                    )
        
        except Exception as e:
            st.error(f"Error processing file: {e}")

def render_model_comparison():
    """Render model comparison interface"""
    st.subheader("⚖️ Model Comparison")
    
    # Sample comparison data
    models = ['Random Forest', 'XGBoost', 'LightGBM', 'Isolation Forest', 'Autoencoder']
    metrics = ['Accuracy', 'Precision', 'Recall', 'F1-Score']
    
    # Generate sample performance data
    performance_data = []
    for model in models:
        for metric in metrics:
            performance_data.append({
                'Model': model,
                'Metric': metric,
                'Score': np.random.uniform(0.7, 0.95)
            })
    
    df_performance = pd.DataFrame(performance_data)
    
    # Create heatmap
    pivot_df = df_performance.pivot(index='Model', columns='Metric', values='Score')
    
    fig = px.imshow(
        pivot_df,
        text_auto=True,
        aspect="auto",
        title="Model Performance Comparison",
        color_continuous_scale='RdYlGn'
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Show detailed metrics table
    st.subheader("📊 Detailed Metrics")
    st.dataframe(pivot_df, use_container_width=True)

def main():
    """Main dashboard function"""
    render_header()
    
    # Get sidebar settings
    settings = render_sidebar()
    
    # Auto refresh
    if settings['auto_refresh']:
        time.sleep(settings['refresh_interval'])
        st.rerun()
    
    # Main content tabs
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "🏠 Dashboard", "🔍 Single Prediction", "📁 Batch Prediction", 
        "⚖️ Model Comparison", "📊 Analytics"
    ])
    
    with tab1:
        render_overview_metrics()
        st.divider()
        
        col1, col2 = st.columns(2)
        with col1:
            render_threat_timeline()
        with col2:
            render_attack_types()
        
        st.divider()
        
        col1, col2 = st.columns(2)
        with col1:
            render_top_attackers()
        with col2:
            render_recent_alerts()
    
    with tab2:
        render_single_flow_prediction()
    
    with tab3:
        render_batch_prediction()
    
    with tab4:
        render_model_comparison()
    
    with tab5:
        st.subheader("📊 Advanced Analytics")
        st.info("Advanced analytics features coming soon!")
        
        # Placeholder for future analytics
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Model Drift Score", "0.12", delta="-0.03")
        with col2:
            st.metric("Data Quality Score", "0.94", delta="+0.01")

if __name__ == "__main__":
    main()
