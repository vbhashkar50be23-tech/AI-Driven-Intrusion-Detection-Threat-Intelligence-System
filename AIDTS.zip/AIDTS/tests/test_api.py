"""
Unit tests for FastAPI endpoints
"""

import pytest
import json
import tempfile
import os
from unittest.mock import Mock, patch, MagicMock
import sys
from fastapi.testclient import TestClient

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from api.api import app

class TestAPI:
    """Test cases for FastAPI endpoints"""
    
    def setup_method(self):
        """Set up test fixtures"""
        self.client = TestClient(app)
        
        # Mock the global models and feature_engineer
        with patch('src.api.api.models', {}), \
             patch('src.api.api.feature_engineer', None), \
             patch('src.api.api.config', {}):
            pass
    
    def test_root_endpoint(self):
        """Test root endpoint"""
        response = self.client.get("/")
        assert response.status_code == 200
        
        data = response.json()
        assert "message" in data
        assert "version" in data
        assert "AIDTIS" in data["message"]
    
    @patch('src.api.api.models', {})
    @patch('src.api.api.feature_engineer', None)
    def test_health_endpoint(self):
        """Test health check endpoint"""
        response = self.client.get("/health")
        assert response.status_code == 200
        
        data = response.json()
        assert data["status"] == "healthy"
        assert "timestamp" in data
        assert "models_loaded" in data
        assert "version" in data
    
    @patch('src.api.api.models', {})
    def test_models_endpoint(self):
        """Test models listing endpoint"""
        response = self.client.get("/models")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
    
    @patch('src.api.api.models', {
        'random_forest': Mock(
            model_type='supervised',
            algorithm='random_forest',
            is_fitted=True,
            feature_names=['feature1', 'feature2'],
            label_encoder=Mock(classes_=['BENIGN', 'DOS'])
        )
    })
    @patch('src.api.api.feature_engineer', Mock(
        transform=Mock(return_value=Mock(columns=['feature1', 'feature2']))
    ))
    def test_predict_endpoint(self):
        """Test single flow prediction endpoint"""
        flow_data = {
            "src_ip": "192.168.1.100",
            "dst_ip": "10.0.0.1",
            "src_port": 12345,
            "dst_port": 80,
            "protocol": 6,
            "start_time": "2024-01-01T10:00:00",
            "end_time": "2024-01-01T10:00:01",
            "duration": 1.0,
            "total_bytes": 1024,
            "total_packets": 10,
            "avg_pkt_size": 102.4,
            "pkt_rate": 10.0,
            "mean_iat": 0.1,
            "tcp_flag_counts": "0,1,0,0,1,0,0,0"
        }
        
        # Mock model prediction
        mock_model = Mock()
        mock_model.predict.return_value = ['BENIGN']
        mock_model.predict_proba.return_value = [[0.8, 0.2]]
        mock_model.model_type = 'supervised'
        mock_model.label_encoder.classes_ = ['BENIGN', 'DOS']
        
        with patch('src.api.api.models', {'random_forest': mock_model}):
            response = self.client.post(
                "/predict",
                json={"flow": flow_data, "model_name": "random_forest"}
            )
            
            assert response.status_code == 200
            
            data = response.json()
            assert "prediction" in data
            assert "confidence" in data
            assert "probabilities" in data
            assert "model_used" in data
            assert data["model_used"] == "random_forest"
    
    @patch('src.api.api.models', {})
    def test_predict_endpoint_model_not_found(self):
        """Test prediction with non-existent model"""
        flow_data = {
            "src_ip": "192.168.1.100",
            "dst_ip": "10.0.0.1",
            "src_port": 12345,
            "dst_port": 80,
            "protocol": 6,
            "start_time": "2024-01-01T10:00:00",
            "end_time": "2024-01-01T10:00:01",
            "duration": 1.0,
            "total_bytes": 1024,
            "total_packets": 10,
            "avg_pkt_size": 102.4,
            "pkt_rate": 10.0,
            "mean_iat": 0.1,
            "tcp_flag_counts": "0,1,0,0,1,0,0,0"
        }
        
        response = self.client.post(
            "/predict",
            json={"flow": flow_data, "model_name": "nonexistent_model"}
        )
        
        assert response.status_code == 400
        assert "not found" in response.json()["detail"]
    
    @patch('src.api.api.models', {
        'random_forest': Mock(
            model_type='supervised',
            algorithm='random_forest',
            is_fitted=True,
            feature_names=['feature1', 'feature2'],
            label_encoder=Mock(classes_=['BENIGN', 'DOS'])
        )
    })
    @patch('src.api.api.feature_engineer', Mock(
        transform=Mock(return_value=Mock(columns=['feature1', 'feature2']))
    ))
    def test_batch_predict_endpoint(self):
        """Test batch prediction endpoint"""
        flows_data = [
            {
                "src_ip": "192.168.1.100",
                "dst_ip": "10.0.0.1",
                "src_port": 12345,
                "dst_port": 80,
                "protocol": 6,
                "start_time": "2024-01-01T10:00:00",
                "end_time": "2024-01-01T10:00:01",
                "duration": 1.0,
                "total_bytes": 1024,
                "total_packets": 10,
                "avg_pkt_size": 102.4,
                "pkt_rate": 10.0,
                "mean_iat": 0.1,
                "tcp_flag_counts": "0,1,0,0,1,0,0,0"
            }
        ]
        
        # Mock model prediction
        mock_model = Mock()
        mock_model.predict.return_value = ['BENIGN']
        mock_model.predict_proba.return_value = [[0.8, 0.2]]
        mock_model.model_type = 'supervised'
        mock_model.label_encoder.classes_ = ['BENIGN', 'DOS']
        
        with patch('src.api.api.models', {'random_forest': mock_model}):
            response = self.client.post(
                "/predict/batch",
                json={"flows": flows_data, "model_name": "random_forest"}
            )
            
            assert response.status_code == 200
            
            data = response.json()
            assert "predictions" in data
            assert "total_flows" in data
            assert "processing_time" in data
            assert "model_used" in data
            assert data["total_flows"] == 1
            assert data["model_used"] == "random_forest"
    
    @patch('src.api.api.models', {})
    def test_batch_predict_endpoint_too_large(self):
        """Test batch prediction with too many flows"""
        # Create a large batch (over the limit)
        flows_data = [{"src_ip": f"192.168.1.{i}"} for i in range(2000)]
        
        with patch('src.api.api.config', {"max_batch_size": 1000}):
            response = self.client.post(
                "/predict/batch",
                json={"flows": flows_data, "model_name": "random_forest"}
            )
            
            assert response.status_code == 400
            assert "exceeds maximum" in response.json()["detail"]
    
    @patch('src.api.api.models', {
        'random_forest': Mock(
            model_type='supervised',
            algorithm='random_forest',
            is_fitted=True,
            feature_names=['feature1', 'feature2'],
            label_encoder=Mock(classes_=['BENIGN', 'DOS'])
        )
    })
    @patch('src.api.api.feature_engineer', Mock(
        transform=Mock(return_value=Mock(columns=['feature1', 'feature2']))
    ))
    def test_csv_predict_endpoint(self):
        """Test CSV prediction endpoint"""
        # Create sample CSV data
        csv_content = "src_ip,dst_ip,src_port,dst_port,protocol,start_time,end_time,duration,total_bytes,total_packets,avg_pkt_size,pkt_rate,mean_iat,tcp_flag_counts\n"
        csv_content += "192.168.1.100,10.0.0.1,12345,80,6,2024-01-01T10:00:00,2024-01-01T10:00:01,1.0,1024,10,102.4,10.0,0.1,0,1,0,0,1,0,0,0\n"
        
        # Mock model prediction
        mock_model = Mock()
        mock_model.predict.return_value = ['BENIGN']
        mock_model.predict_proba.return_value = [[0.8, 0.2]]
        mock_model.model_type = 'supervised'
        mock_model.label_encoder.classes_ = ['BENIGN', 'DOS']
        
        with patch('src.api.api.models', {'random_forest': mock_model}):
            response = self.client.post(
                "/predict/csv",
                files={"file": ("test.csv", csv_content, "text/csv")},
                data={"model_name": "random_forest"}
            )
            
            assert response.status_code == 200
            
            data = response.json()
            assert "predictions" in data
            assert "total_flows" in data
            assert "processing_time" in data
            assert "model_used" in data
            assert data["total_flows"] == 1
            assert data["model_used"] == "random_forest"
    
    @patch('src.api.api.models', {})
    def test_csv_predict_endpoint_invalid_file(self):
        """Test CSV prediction with invalid file"""
        response = self.client.post(
            "/predict/csv",
            files={"file": ("test.txt", "invalid content", "text/plain")},
            data={"model_name": "random_forest"}
        )
        
        assert response.status_code == 400
    
    @patch('src.api.api.models', {})
    def test_stats_endpoint(self):
        """Test statistics endpoint"""
        response = self.client.get("/stats")
        assert response.status_code == 200
        
        data = response.json()
        assert "models_loaded" in data
        assert "available_models" in data
        assert "feature_engineer_loaded" in data
        assert "version" in data
    
    @patch('src.api.api.models', {})
    @patch('os.getenv', return_value='dev')
    def test_ingest_pcap_endpoint_dev_mode(self):
        """Test PCAP ingestion in dev mode"""
        # Create a temporary PCAP file
        with tempfile.NamedTemporaryFile(suffix='.pcap', delete=False) as f:
            temp_pcap = f.name
            f.write(b"dummy pcap content")
        
        try:
            with open(temp_pcap, 'rb') as f:
                response = self.client.post(
                    "/ingest/pcap",
                    files={"file": ("test.pcap", f, "application/octet-stream")},
                    data={"model_name": "random_forest"}
                )
            
            # Should return 400 since no model is loaded
            assert response.status_code == 400
            
        finally:
            if os.path.exists(temp_pcap):
                os.unlink(temp_pcap)
    
    @patch('src.api.api.models', {})
    @patch('os.getenv', return_value='prod')
    def test_ingest_pcap_endpoint_prod_mode(self):
        """Test PCAP ingestion in prod mode (should be disabled)"""
        response = self.client.post(
            "/ingest/pcap",
            files={"file": ("test.pcap", b"dummy content", "application/octet-stream")},
            data={"model_name": "random_forest"}
        )
        
        assert response.status_code == 403
        assert "development mode" in response.json()["detail"]

class TestAPIValidation:
    """Test cases for API input validation"""
    
    def setup_method(self):
        """Set up test fixtures"""
        self.client = TestClient(app)
    
    def test_predict_endpoint_invalid_flow_data(self):
        """Test prediction with invalid flow data"""
        invalid_flow_data = {
            "src_ip": "invalid_ip",  # Invalid IP
            "dst_ip": "10.0.0.1",
            "src_port": "invalid_port",  # Invalid port
            "dst_port": 80,
            "protocol": 6,
            "start_time": "invalid_time",  # Invalid time
            "end_time": "2024-01-01T10:00:01",
            "duration": 1.0,
            "total_bytes": 1024,
            "total_packets": 10,
            "avg_pkt_size": 102.4,
            "pkt_rate": 10.0,
            "mean_iat": 0.1,
            "tcp_flag_counts": "0,1,0,0,1,0,0,0"
        }
        
        response = self.client.post(
            "/predict",
            json={"flow": invalid_flow_data, "model_name": "random_forest"}
        )
        
        # Should return validation error
        assert response.status_code == 422
    
    def test_predict_endpoint_missing_required_fields(self):
        """Test prediction with missing required fields"""
        incomplete_flow_data = {
            "src_ip": "192.168.1.100",
            "dst_ip": "10.0.0.1",
            # Missing required fields
        }
        
        response = self.client.post(
            "/predict",
            json={"flow": incomplete_flow_data, "model_name": "random_forest"}
        )
        
        # Should return validation error
        assert response.status_code == 422
    
    def test_batch_predict_endpoint_empty_flows(self):
        """Test batch prediction with empty flows list"""
        response = self.client.post(
            "/predict/batch",
            json={"flows": [], "model_name": "random_forest"}
        )
        
        # Should return 400 for empty batch
        assert response.status_code == 400

if __name__ == "__main__":
    pytest.main([__file__])
