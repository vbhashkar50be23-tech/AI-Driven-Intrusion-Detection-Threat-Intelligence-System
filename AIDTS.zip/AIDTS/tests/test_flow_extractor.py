"""
Unit tests for flow extractor
"""

import pytest
import pandas as pd
import numpy as np
import tempfile
import os
from unittest.mock import Mock, patch
import sys

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from data.flow_extractor import FlowExtractor, extract_pcap_to_flows

class TestFlowExtractor:
    """Test cases for FlowExtractor class"""
    
    def setup_method(self):
        """Set up test fixtures"""
        self.extractor = FlowExtractor(flow_timeout=600, max_flows=1000)
    
    def test_init(self):
        """Test FlowExtractor initialization"""
        assert self.extractor.flow_timeout == 600
        assert self.extractor.max_flows == 1000
        assert self.extractor.flows == {}
        assert self.extractor.flow_id_counter == 0
    
    def test_get_flow_key(self):
        """Test flow key generation"""
        # Mock packet with IP and TCP
        mock_packet = Mock()
        mock_packet.ip = Mock()
        mock_packet.ip.src = "192.168.1.1"
        mock_packet.ip.dst = "10.0.0.1"
        mock_packet.ip.proto = 6
        mock_packet.tcp = Mock()
        mock_packet.tcp.sport = 12345
        mock_packet.tcp.dport = 80
        
        flow_key = self.extractor._get_flow_key(mock_packet)
        expected_key = ("10.0.0.1", "192.168.1.1", 80, 12345, 6)  # Reordered for consistency
        
        assert flow_key == expected_key
    
    def test_extract_tcp_flags(self):
        """Test TCP flag extraction"""
        # Test valid TCP flags string
        flags_string = "1,1,0,0,1,0,0,0"
        flags = self.extractor._extract_tcp_flags(flags_string)
        expected_flags = [1, 1, 0, 0, 1, 0, 0, 0]
        assert flags == expected_flags
        
        # Test invalid TCP flags string
        flags_string = "invalid"
        flags = self.extractor._extract_tcp_flags(flags_string)
        expected_flags = [0, 0, 0, 0, 0, 0, 0, 0]
        assert flags == expected_flags
    
    def test_update_flow(self):
        """Test flow update functionality"""
        flow_key = ("192.168.1.1", "10.0.0.1", 12345, 80, 6)
        
        # Mock packet
        mock_packet = Mock()
        mock_packet.len = 1000
        mock_packet.tcp = Mock()
        mock_packet.tcp.flags = 0x02  # SYN flag
        
        timestamp = 1234567890.0
        
        # Update flow
        self.extractor._update_flow(flow_key, mock_packet, timestamp)
        
        # Check flow was created
        assert flow_key in self.extractor.flows
        flow = self.extractor.flows[flow_key]
        
        assert flow['src_ip'] == "192.168.1.1"
        assert flow['dst_ip'] == "10.0.0.1"
        assert flow['src_port'] == 12345
        assert flow['dst_port'] == 80
        assert flow['protocol'] == 6
        assert flow['start_time'] == timestamp
        assert flow['end_time'] == timestamp
        assert flow['packet_count'] == 1
        assert flow['byte_count'] == 1000
    
    def test_finalize_flow(self):
        """Test flow finalization"""
        # Create a mock flow
        flow_key = ("192.168.1.1", "10.0.0.1", 12345, 80, 6)
        self.extractor.flows[flow_key] = {
            'flow_id': 0,
            'src_ip': "192.168.1.1",
            'dst_ip': "10.0.0.1",
            'src_port': 12345,
            'dst_port': 80,
            'protocol': 6,
            'start_time': 1234567890.0,
            'end_time': 1234567892.0,
            'packet_count': 10,
            'byte_count': 10000,
            'tcp_flags': {'FIN': 1, 'SYN': 1, 'RST': 0, 'PSH': 0, 'ACK': 1, 'URG': 0, 'ECE': 0, 'CWR': 0},
            'packet_sizes': [1000] * 10,
            'inter_arrival_times': [0.2] * 9,
            'last_timestamp': 1234567892.0
        }
        
        # Finalize flow
        finalized_flow = self.extractor._finalize_flow(flow_key)
        
        # Check finalized flow
        assert finalized_flow['flow_id'] == 0
        assert finalized_flow['src_ip'] == "192.168.1.1"
        assert finalized_flow['dst_ip'] == "10.0.0.1"
        assert finalized_flow['duration'] == 2.0
        assert finalized_flow['total_bytes'] == 10000
        assert finalized_flow['total_packets'] == 10
        assert finalized_flow['avg_pkt_size'] == 1000.0
        assert finalized_flow['pkt_rate'] == 5.0
        assert finalized_flow['mean_iat'] == 0.2
        assert finalized_flow['tcp_flag_counts'] == "1,1,0,0,1,0,0,0"
        assert finalized_flow['label'] == 'UNKNOWN'
    
    def test_cleanup_expired_flows(self):
        """Test expired flow cleanup"""
        current_time = 1234567890.0
        
        # Add some flows
        flow_key1 = ("192.168.1.1", "10.0.0.1", 12345, 80, 6)
        flow_key2 = ("192.168.1.2", "10.0.0.1", 12346, 80, 6)
        
        self.extractor.flows[flow_key1] = {
            'last_timestamp': current_time - 100,  # Old flow
            'packet_count': 1,
            'byte_count': 100
        }
        
        self.extractor.flows[flow_key2] = {
            'last_timestamp': current_time - 10,  # Recent flow
            'packet_count': 1,
            'byte_count': 100
        }
        
        # Cleanup expired flows
        self.extractor._cleanup_expired_flows(current_time)
        
        # Check that only recent flow remains
        assert flow_key1 not in self.extractor.flows
        assert flow_key2 in self.extractor.flows
    
    def test_save_flows_to_csv(self):
        """Test saving flows to CSV"""
        # Create sample flows
        flows = [
            {
                'flow_id': 0,
                'src_ip': '192.168.1.1',
                'dst_ip': '10.0.0.1',
                'src_port': 12345,
                'dst_port': 80,
                'protocol': 6,
                'start_time': 1234567890.0,
                'end_time': 1234567892.0,
                'duration': 2.0,
                'total_bytes': 1000,
                'total_packets': 10,
                'avg_pkt_size': 100.0,
                'pkt_rate': 5.0,
                'mean_iat': 0.2,
                'tcp_flag_counts': '0,1,0,0,1,0,0,0',
                'label': 'BENIGN'
            }
        ]
        
        # Save to temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            temp_file = f.name
        
        try:
            self.extractor.save_flows_to_csv(flows, temp_file)
            
            # Check file was created and has correct content
            assert os.path.exists(temp_file)
            
            df = pd.read_csv(temp_file)
            assert len(df) == 1
            assert df.iloc[0]['src_ip'] == '192.168.1.1'
            assert df.iloc[0]['dst_ip'] == '10.0.0.1'
            assert df.iloc[0]['label'] == 'BENIGN'
            
        finally:
            # Clean up
            if os.path.exists(temp_file):
                os.unlink(temp_file)
    
    def test_save_flows_to_csv_empty(self):
        """Test saving empty flows list"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            temp_file = f.name
        
        try:
            # Should not create file for empty flows
            self.extractor.save_flows_to_csv([], temp_file)
            assert not os.path.exists(temp_file)
            
        finally:
            if os.path.exists(temp_file):
                os.unlink(temp_file)

class TestExtractPcapToFlows:
    """Test cases for extract_pcap_to_flows function"""
    
    def test_extract_pcap_to_flows_success(self):
        """Test successful PCAP extraction"""
        # Create a temporary PCAP file (empty for testing)
        with tempfile.NamedTemporaryFile(suffix='.pcap', delete=False) as f:
            temp_pcap = f.name
        
        with tempfile.NamedTemporaryFile(suffix='.csv', delete=False) as f:
            temp_csv = f.name
        
        try:
            # Mock the extractor to return sample flows
            with patch('src.data.flow_extractor.FlowExtractor') as mock_extractor_class:
                mock_extractor = Mock()
                mock_extractor_class.return_value = mock_extractor
                
                sample_flows = [
                    {
                        'flow_id': 0,
                        'src_ip': '192.168.1.1',
                        'dst_ip': '10.0.0.1',
                        'label': 'BENIGN'
                    }
                ]
                
                mock_extractor.extract_flows_scapy.return_value = sample_flows
                
                # Test extraction
                result = extract_pcap_to_flows(temp_pcap, temp_csv, method='scapy')
                
                assert result is True
                mock_extractor.extract_flows_scapy.assert_called_once_with(temp_pcap)
                mock_extractor.save_flows_to_csv.assert_called_once_with(sample_flows, temp_csv)
                
        finally:
            # Clean up
            for temp_file in [temp_pcap, temp_csv]:
                if os.path.exists(temp_file):
                    os.unlink(temp_file)
    
    def test_extract_pcap_to_flows_failure(self):
        """Test PCAP extraction failure"""
        with tempfile.NamedTemporaryFile(suffix='.pcap', delete=False) as f:
            temp_pcap = f.name
        
        with tempfile.NamedTemporaryFile(suffix='.csv', delete=False) as f:
            temp_csv = f.name
        
        try:
            # Mock the extractor to return empty flows
            with patch('src.data.flow_extractor.FlowExtractor') as mock_extractor_class:
                mock_extractor = Mock()
                mock_extractor_class.return_value = mock_extractor
                mock_extractor.extract_flows_scapy.return_value = []
                
                # Test extraction
                result = extract_pcap_to_flows(temp_pcap, temp_csv, method='scapy')
                
                assert result is False
                
        finally:
            # Clean up
            for temp_file in [temp_pcap, temp_csv]:
                if os.path.exists(temp_file):
                    os.unlink(temp_file)
    
    def test_extract_pcap_to_flows_invalid_method(self):
        """Test PCAP extraction with invalid method"""
        with tempfile.NamedTemporaryFile(suffix='.pcap', delete=False) as f:
            temp_pcap = f.name
        
        with tempfile.NamedTemporaryFile(suffix='.csv', delete=False) as f:
            temp_csv = f.name
        
        try:
            # Test with invalid method
            result = extract_pcap_to_flows(temp_pcap, temp_csv, method='invalid')
            assert result is False
            
        finally:
            # Clean up
            for temp_file in [temp_pcap, temp_csv]:
                if os.path.exists(temp_file):
                    os.unlink(temp_file)

if __name__ == "__main__":
    pytest.main([__file__])
