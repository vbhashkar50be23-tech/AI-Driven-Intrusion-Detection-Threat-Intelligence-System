"""
Unit tests for feature engineering
"""

import pytest
import pandas as pd
import numpy as np
import tempfile
import os
from unittest.mock import Mock, patch
import sys

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from utils.feature_engineering import FeatureEngineer, create_feature_engineering_pipeline

class TestFeatureEngineer:
    """Test cases for FeatureEngineer class"""
    
    def setup_method(self):
        """Set up test fixtures"""
        self.feature_engineer = FeatureEngineer()
        
        # Create sample data
        self.sample_data = pd.DataFrame({
            'flow_id': [0, 1, 2, 3, 4],
            'src_ip': ['192.168.1.1', '192.168.1.2', '192.168.1.3', '192.168.1.4', '192.168.1.5'],
            'dst_ip': ['10.0.0.1', '10.0.0.2', '10.0.0.3', '10.0.0.4', '10.0.0.5'],
            'src_port': [12345, 12346, 12347, 12348, 12349],
            'dst_port': [80, 443, 22, 25, 53],
            'protocol': [6, 6, 6, 6, 17],
            'start_time': pd.date_range('2024-01-01', periods=5, freq='1H'),
            'end_time': pd.date_range('2024-01-01 00:00:01', periods=5, freq='1H'),
            'duration': [1.0, 2.0, 3.0, 4.0, 5.0],
            'total_bytes': [1000, 2000, 3000, 4000, 5000],
            'total_packets': [10, 20, 30, 40, 50],
            'avg_pkt_size': [100.0, 100.0, 100.0, 100.0, 100.0],
            'pkt_rate': [10.0, 10.0, 10.0, 10.0, 10.0],
            'mean_iat': [0.1, 0.1, 0.1, 0.1, 0.1],
            'tcp_flag_counts': ['0,1,0,0,1,0,0,0'] * 5,
            'label': ['BENIGN', 'DOS', 'PROBE', 'R2L', 'BENIGN']
        })
    
    def test_init(self):
        """Test FeatureEngineer initialization"""
        assert self.feature_engineer.config is not None
        assert self.feature_engineer.scalers == {}
        assert self.feature_engineer.encoders == {}
        assert self.feature_engineer.feature_names == []
        assert self.feature_engineer.is_fitted == False
    
    def test_default_config(self):
        """Test default configuration"""
        config = self.feature_engineer._default_config()
        
        assert 'numerical_features' in config
        assert 'categorical_features' in config
        assert 'ip_features' in config
        assert 'port_features' in config
        assert 'time_features' in config
        assert 'tcp_flag_features' in config
        assert 'rolling_window' in config
        assert 'entropy_window' in config
        assert 'normalize_features' in config
        assert 'create_interactions' in config
        assert 'create_polynomial' in config
    
    def test_extract_tcp_flags(self):
        """Test TCP flag extraction"""
        # Test valid TCP flags string
        flags_string = "1,1,0,0,1,0,0,0"
        flags = self.feature_engineer._extract_tcp_flags(flags_string)
        expected_flags = [1, 1, 0, 0, 1, 0, 0, 0]
        assert flags == expected_flags
        
        # Test invalid TCP flags string
        flags_string = "invalid"
        flags = self.feature_engineer._extract_tcp_flags(flags_string)
        expected_flags = [0, 0, 0, 0, 0, 0, 0, 0]
        assert flags == expected_flags
    
    def test_calculate_entropy(self):
        """Test entropy calculation"""
        series = pd.Series(['A', 'A', 'B', 'B', 'C'])
        entropy_series = self.feature_engineer._calculate_entropy(series, window=3)
        
        # Check that entropy is calculated
        assert len(entropy_series) == len(series)
        assert not entropy_series.isna().all()
    
    def test_create_time_features(self):
        """Test time feature creation"""
        df_with_time = self.feature_engineer._create_time_features(self.sample_data.copy())
        
        # Check that time features are created
        assert 'hour' in df_with_time.columns
        assert 'day_of_week' in df_with_time.columns
        assert 'is_weekend' in df_with_time.columns
        assert 'is_night' in df_with_time.columns
        assert 'is_business_hours' in df_with_time.columns
        assert 'time_since_epoch' in df_with_time.columns
        
        # Check that time features have correct values
        assert df_with_time['hour'].dtype == 'int64'
        assert df_with_time['day_of_week'].dtype == 'int64'
        assert df_with_time['is_weekend'].dtype == 'int64'
        assert df_with_time['is_night'].dtype == 'int64'
        assert df_with_time['is_business_hours'].dtype == 'int64'
    
    def test_create_protocol_features(self):
        """Test protocol feature creation"""
        df_with_protocol = self.feature_engineer._create_protocol_features(self.sample_data.copy())
        
        # Check that protocol features are created
        assert 'protocol_frequency' in df_with_protocol.columns
        assert 'protocol_entropy' in df_with_protocol.columns
        assert 'is_protocol_1' in df_with_protocol.columns
        assert 'is_protocol_6' in df_with_protocol.columns
        assert 'is_protocol_17' in df_with_protocol.columns
        
        # Check that protocol features have correct values
        assert df_with_protocol['protocol_frequency'].dtype == 'int64'
        assert df_with_protocol['is_protocol_6'].dtype == 'int64'
        assert df_with_protocol['is_protocol_17'].dtype == 'int64'
    
    def test_create_port_features(self):
        """Test port feature creation"""
        df_with_port = self.feature_engineer._create_port_features(self.sample_data.copy())
        
        # Check that port features are created
        assert 'src_port_range' in df_with_port.columns
        assert 'dst_port_range' in df_with_port.columns
        assert 'src_port_is_well_known' in df_with_port.columns
        assert 'dst_port_is_well_known' in df_with_port.columns
        assert 'src_port_entropy' in df_with_port.columns
        assert 'dst_port_entropy' in df_with_port.columns
        assert 'src_port_frequency' in df_with_port.columns
        assert 'dst_port_frequency' in df_with_port.columns
        
        # Check that port features have correct values
        assert df_with_port['src_port_is_well_known'].dtype == 'int64'
        assert df_with_port['dst_port_is_well_known'].dtype == 'int64'
    
    def test_create_ip_features(self):
        """Test IP feature creation"""
        df_with_ip = self.feature_engineer._create_ip_features(self.sample_data.copy())
        
        # Check that IP features are created
        assert 'src_ip_frequency' in df_with_ip.columns
        assert 'dst_ip_frequency' in df_with_ip.columns
        assert 'src_ip_entropy' in df_with_ip.columns
        assert 'dst_ip_entropy' in df_with_ip.columns
        assert 'src_ip_is_private' in df_with_ip.columns
        assert 'dst_ip_is_private' in df_with_ip.columns
        assert 'src_ip_class' in df_with_ip.columns
        assert 'dst_ip_class' in df_with_ip.columns
        
        # Check that IP features have correct values
        assert df_with_ip['src_ip_is_private'].dtype == 'int64'
        assert df_with_ip['dst_ip_is_private'].dtype == 'int64'
        assert df_with_ip['src_ip_class'].dtype == 'int64'
        assert df_with_ip['dst_ip_class'].dtype == 'int64'
    
    def test_create_tcp_flag_features(self):
        """Test TCP flag feature creation"""
        df_with_tcp = self.feature_engineer._create_tcp_flag_features(self.sample_data.copy())
        
        # Check that TCP flag features are created
        assert 'tcp_fin' in df_with_tcp.columns
        assert 'tcp_syn' in df_with_tcp.columns
        assert 'tcp_rst' in df_with_tcp.columns
        assert 'tcp_psh' in df_with_tcp.columns
        assert 'tcp_ack' in df_with_tcp.columns
        assert 'tcp_urg' in df_with_tcp.columns
        assert 'tcp_ece' in df_with_tcp.columns
        assert 'tcp_cwr' in df_with_tcp.columns
        assert 'tcp_syn_ack' in df_with_tcp.columns
        assert 'tcp_fin_ack' in df_with_tcp.columns
        assert 'tcp_rst_ack' in df_with_tcp.columns
        assert 'tcp_total_flags' in df_with_tcp.columns
        assert 'tcp_flag_entropy' in df_with_tcp.columns
        
        # Check that TCP flag features have correct values
        assert df_with_tcp['tcp_syn'].dtype == 'int64'
        assert df_with_tcp['tcp_ack'].dtype == 'int64'
        assert df_with_tcp['tcp_total_flags'].dtype == 'int64'
    
    def test_create_statistical_features(self):
        """Test statistical feature creation"""
        df_with_stats = self.feature_engineer._create_statistical_features(self.sample_data.copy())
        
        # Check that statistical features are created
        assert 'duration_log' in df_with_stats.columns
        assert 'total_bytes_log' in df_with_stats.columns
        assert 'total_packets_log' in df_with_stats.columns
        assert 'duration_sqrt' in df_with_stats.columns
        assert 'total_bytes_sqrt' in df_with_stats.columns
        assert 'total_packets_sqrt' in df_with_stats.columns
        assert 'duration_zscore' in df_with_stats.columns
        assert 'total_bytes_zscore' in df_with_stats.columns
        assert 'total_packets_zscore' in df_with_stats.columns
        assert 'duration_percentile' in df_with_stats.columns
        assert 'total_bytes_percentile' in df_with_stats.columns
        assert 'total_packets_percentile' in df_with_stats.columns
        
        # Check that statistical features have correct values
        assert df_with_stats['duration_log'].dtype == 'float64'
        assert df_with_stats['total_bytes_log'].dtype == 'float64'
        assert df_with_stats['duration_sqrt'].dtype == 'float64'
        assert df_with_stats['total_bytes_sqrt'].dtype == 'float64'
    
    def test_create_interaction_features(self):
        """Test interaction feature creation"""
        df_with_interactions = self.feature_engineer._create_interaction_features(self.sample_data.copy())
        
        # Check that interaction features are created
        assert 'byte_rate' in df_with_interactions.columns
        assert 'packet_size_ratio' in df_with_interactions.columns
        assert 'flow_efficiency' in df_with_interactions.columns
        assert 'protocol_src_port' in df_with_interactions.columns
        assert 'protocol_dst_port' in df_with_interactions.columns
        
        # Check that interaction features have correct values
        assert df_with_interactions['byte_rate'].dtype == 'float64'
        assert df_with_interactions['packet_size_ratio'].dtype == 'float64'
        assert df_with_interactions['flow_efficiency'].dtype == 'float64'
    
    def test_create_polynomial_features(self):
        """Test polynomial feature creation"""
        df_with_poly = self.feature_engineer._create_polynomial_features(self.sample_data.copy())
        
        # Check that polynomial features are created
        assert 'duration_pow_2' in df_with_poly.columns
        assert 'total_bytes_pow_2' in df_with_poly.columns
        assert 'total_packets_pow_2' in df_with_poly.columns
        
        # Check that polynomial features have correct values
        assert df_with_poly['duration_pow_2'].dtype == 'float64'
        assert df_with_poly['total_bytes_pow_2'].dtype == 'float64'
        assert df_with_poly['total_packets_pow_2'].dtype == 'float64'
    
    def test_encode_categorical_features(self):
        """Test categorical feature encoding"""
        df_with_encoded = self.feature_engineer._encode_categorical_features(self.sample_data.copy(), fit=True)
        
        # Check that encoded features are created
        assert 'protocol_encoded' in df_with_encoded.columns
        
        # Check that encoded features have correct values
        assert df_with_encoded['protocol_encoded'].dtype == 'int64'
        
        # Check that encoder was fitted
        assert 'protocol' in self.feature_engineer.encoders
    
    def test_normalize_features(self):
        """Test feature normalization"""
        df_with_normalized = self.feature_engineer._normalize_features(self.sample_data.copy(), fit=True)
        
        # Check that scaler was fitted
        assert 'standard' in self.feature_engineer.scalers
        
        # Check that numerical features are normalized
        numerical_cols = df_with_normalized.select_dtypes(include=[np.number]).columns.tolist()
        exclude_cols = ['flow_id', 'label', 'start_time', 'end_time']
        numerical_cols = [col for col in numerical_cols if col not in exclude_cols]
        
        for col in numerical_cols:
            if col in df_with_normalized.columns:
                # Check that values are roughly normalized (mean close to 0, std close to 1)
                mean_val = df_with_normalized[col].mean()
                std_val = df_with_normalized[col].std()
                assert abs(mean_val) < 0.1  # Mean should be close to 0
                assert abs(std_val - 1.0) < 0.1  # Std should be close to 1
    
    def test_fit_transform(self):
        """Test fit and transform pipeline"""
        df_transformed = self.feature_engineer.fit_transform(self.sample_data)
        
        # Check that pipeline was fitted
        assert self.feature_engineer.is_fitted == True
        assert len(self.feature_engineer.feature_names) > 0
        
        # Check that transformed data has more features
        assert len(df_transformed.columns) > len(self.sample_data.columns)
        
        # Check that feature names are stored
        assert len(self.feature_engineer.feature_names) > 0
    
    def test_transform_without_fit(self):
        """Test transform without fitting (should raise error)"""
        with pytest.raises(ValueError, match="Pipeline must be fitted before transform"):
            self.feature_engineer.transform(self.sample_data)
    
    def test_transform_after_fit(self):
        """Test transform after fitting"""
        # Fit the pipeline
        self.feature_engineer.fit_transform(self.sample_data)
        
        # Transform new data
        new_data = self.sample_data.copy()
        df_transformed = self.feature_engineer.transform(new_data)
        
        # Check that transformation was successful
        assert len(df_transformed.columns) > len(new_data.columns)
        assert df_transformed.shape[0] == new_data.shape[0]
    
    def test_get_feature_names(self):
        """Test getting feature names"""
        # Before fitting
        assert len(self.feature_engineer.get_feature_names()) == 0
        
        # After fitting
        self.feature_engineer.fit_transform(self.sample_data)
        feature_names = self.feature_engineer.get_feature_names()
        
        assert len(feature_names) > 0
        assert isinstance(feature_names, list)
    
    def test_save_and_load_pipeline(self):
        """Test saving and loading pipeline"""
        # Fit the pipeline
        self.feature_engineer.fit_transform(self.sample_data)
        
        # Save pipeline
        with tempfile.NamedTemporaryFile(suffix='.pkl', delete=False) as f:
            temp_file = f.name
        
        try:
            self.feature_engineer.save_pipeline(temp_file)
            assert os.path.exists(temp_file)
            
            # Create new feature engineer and load pipeline
            new_feature_engineer = FeatureEngineer()
            new_feature_engineer.load_pipeline(temp_file)
            
            # Check that pipeline was loaded correctly
            assert new_feature_engineer.is_fitted == True
            assert len(new_feature_engineer.feature_names) > 0
            assert 'standard' in new_feature_engineer.scalers
            assert 'protocol' in new_feature_engineer.encoders
            
        finally:
            if os.path.exists(temp_file):
                os.unlink(temp_file)
    
    def test_create_feature_engineering_pipeline(self):
        """Test creating feature engineering pipeline"""
        pipeline = create_feature_engineering_pipeline()
        
        assert isinstance(pipeline, FeatureEngineer)
        assert pipeline.config is not None
        assert pipeline.scalers == {}
        assert pipeline.encoders == {}
        assert pipeline.feature_names == []
        assert pipeline.is_fitted == False

class TestFeatureEngineeringIntegration:
    """Integration tests for feature engineering"""
    
    def setup_method(self):
        """Set up test fixtures"""
        self.feature_engineer = FeatureEngineer()
        
        # Create larger sample data for integration testing
        np.random.seed(42)
        n_samples = 100
        
        self.large_sample_data = pd.DataFrame({
            'flow_id': range(n_samples),
            'src_ip': [f'192.168.1.{i%254+1}' for i in range(n_samples)],
            'dst_ip': [f'10.0.0.{i%254+1}' for i in range(n_samples)],
            'src_port': np.random.randint(1024, 65535, n_samples),
            'dst_port': np.random.choice([80, 443, 22, 25, 53, 110, 143, 993, 995], n_samples),
            'protocol': np.random.choice([1, 6, 17], n_samples),
            'start_time': pd.date_range('2024-01-01', periods=n_samples, freq='1min'),
            'end_time': pd.date_range('2024-01-01 00:00:01', periods=n_samples, freq='1min'),
            'duration': np.random.uniform(0.1, 10.0, n_samples),
            'total_bytes': np.random.randint(100, 10000, n_samples),
            'total_packets': np.random.randint(1, 100, n_samples),
            'avg_pkt_size': np.random.uniform(50, 1500, n_samples),
            'pkt_rate': np.random.uniform(1, 100, n_samples),
            'mean_iat': np.random.uniform(0.01, 1.0, n_samples),
            'tcp_flag_counts': [f'{np.random.randint(0,2)},{np.random.randint(0,2)},0,0,{np.random.randint(0,2)},0,0,0' for _ in range(n_samples)],
            'label': np.random.choice(['BENIGN', 'DOS', 'PROBE', 'R2L', 'U2R'], n_samples)
        })
    
    def test_full_pipeline_integration(self):
        """Test full feature engineering pipeline"""
        # Fit and transform
        df_transformed = self.feature_engineer.fit_transform(self.large_sample_data)
        
        # Check that transformation was successful
        assert self.feature_engineer.is_fitted == True
        assert len(df_transformed.columns) > len(self.large_sample_data.columns)
        assert df_transformed.shape[0] == self.large_sample_data.shape[0]
        
        # Check that no NaN values were introduced
        assert not df_transformed.isnull().any().any()
        
        # Check that feature names are stored
        feature_names = self.feature_engineer.get_feature_names()
        assert len(feature_names) > 0
        
        # Check that all feature names exist in transformed data
        for feature_name in feature_names:
            assert feature_name in df_transformed.columns
    
    def test_pipeline_consistency(self):
        """Test that pipeline produces consistent results"""
        # Fit pipeline
        df_transformed1 = self.feature_engineer.fit_transform(self.large_sample_data)
        
        # Transform same data again
        df_transformed2 = self.feature_engineer.transform(self.large_sample_data)
        
        # Check that results are consistent
        assert df_transformed1.shape == df_transformed2.shape
        assert df_transformed1.columns.tolist() == df_transformed2.columns.tolist()
        
        # Check that numerical values are consistent (within tolerance)
        numerical_cols = df_transformed1.select_dtypes(include=[np.number]).columns
        for col in numerical_cols:
            if col in df_transformed1.columns and col in df_transformed2.columns:
                diff = (df_transformed1[col] - df_transformed2[col]).abs().max()
                assert diff < 1e-10  # Should be identical
    
    def test_pipeline_with_different_data(self):
        """Test pipeline with different data"""
        # Fit pipeline
        self.feature_engineer.fit_transform(self.large_sample_data)
        
        # Create different data
        different_data = self.large_sample_data.copy()
        different_data['src_ip'] = [f'172.16.0.{i%254+1}' for i in range(len(different_data))]
        different_data['dst_ip'] = [f'192.168.0.{i%254+1}' for i in range(len(different_data))]
        
        # Transform different data
        df_transformed = self.feature_engineer.transform(different_data)
        
        # Check that transformation was successful
        assert df_transformed.shape[0] == different_data.shape[0]
        assert len(df_transformed.columns) > len(different_data.columns)
        assert not df_transformed.isnull().any().any()

if __name__ == "__main__":
    pytest.main([__file__])
