"""
AIDTIS - Deployment Demo Notebook
Convert this to Jupyter notebook for interactive execution
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
import sys
import requests
import json
import time
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Add src to path
sys.path.append('../src')

# Set up plotting
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

print("✅ Libraries imported successfully")

# API Configuration
API_BASE_URL = "http://localhost:8000"
DASHBOARD_URL = "http://localhost:8501"

print("🚀 AIDTIS Deployment Demo")
print("=" * 40)

# Check API health
print("1. Checking API health...")
try:
    response = requests.get(f"{API_BASE_URL}/health", timeout=5)
    if response.status_code == 200:
        health_data = response.json()
        print(f"   ✅ API is healthy")
        print(f"   📊 Models loaded: {health_data['models_loaded']}")
        print(f"   🕒 Timestamp: {health_data['timestamp']}")
    else:
        print(f"   ❌ API health check failed: {response.status_code}")
        print("   Please start the API server first: make serve")
except Exception as e:
    print(f"   ❌ Cannot connect to API: {e}")
    print("   Please start the API server first: make serve")

# List available models
print("\n2. Listing available models...")
try:
    response = requests.get(f"{API_BASE_URL}/models", timeout=5)
    if response.status_code == 200:
        models = response.json()
        print(f"   📊 Available models: {len(models)}")
        for model in models:
            print(f"   🔹 {model['name']} ({model['type']}) - {model['algorithm']}")
    else:
        print(f"   ❌ Failed to get models: {response.status_code}")
except Exception as e:
    print(f"   ❌ Error getting models: {e}")

# Single flow prediction demo
print("\n3. Single flow prediction demo...")
sample_flow = {
    "src_ip": "192.168.1.100",
    "dst_ip": "10.0.0.1",
    "src_port": 12345,
    "dst_port": 80,
    "protocol": 6,
    "start_time": "2024-01-01T10:00:00",
    "end_time": "2024-01-01T10:00:01",
    "duration": 1.0,
    "total_bytes": 1024,
    "total_packets": 10,
    "avg_pkt_size": 102.4,
    "pkt_rate": 10.0,
    "mean_iat": 0.1,
    "tcp_flag_counts": "0,1,0,0,1,0,0,0"
}

try:
    response = requests.post(
        f"{API_BASE_URL}/predict",
        json={"flow": sample_flow, "model_name": "random_forest"},
        timeout=10
    )
    
    if response.status_code == 200:
        prediction = response.json()
        print(f"   ✅ Prediction successful")
        print(f"   🎯 Prediction: {prediction['prediction']}")
        print(f"   📊 Confidence: {prediction['confidence']:.3f}")
        print(f"   🤖 Model used: {prediction['model_used']}")
        print(f"   📈 Probabilities: {prediction['probabilities']}")
    else:
        print(f"   ❌ Prediction failed: {response.status_code}")
        print(f"   Response: {response.text}")
except Exception as e:
    print(f"   ❌ Error in prediction: {e}")

# Batch prediction demo
print("\n4. Batch prediction demo...")
sample_flows = []
for i in range(5):
    flow = sample_flow.copy()
    flow["src_ip"] = f"192.168.1.{100 + i}"
    flow["src_port"] = 12345 + i
    sample_flows.append(flow)

try:
    response = requests.post(
        f"{API_BASE_URL}/predict/batch",
        json={"flows": sample_flows, "model_name": "random_forest"},
        timeout=30
    )
    
    if response.status_code == 200:
        batch_result = response.json()
        print(f"   ✅ Batch prediction successful")
        print(f"   📊 Processed {batch_result['total_flows']} flows")
        print(f"   ⏱️ Processing time: {batch_result['processing_time']:.2f} seconds")
        print(f"   🤖 Model used: {batch_result['model_used']}")
        
        # Show predictions
        for i, pred in enumerate(batch_result['predictions'][:3]):  # Show first 3
            print(f"   🔹 Flow {i+1}: {pred['prediction']} (confidence: {pred['confidence']:.3f})")
    else:
        print(f"   ❌ Batch prediction failed: {response.status_code}")
except Exception as e:
    print(f"   ❌ Error in batch prediction: {e}")

# CSV prediction demo
print("\n5. CSV file prediction demo...")
# Create sample CSV data
sample_data = []
for i in range(10):
    flow = {
        "flow_id": i,
        "src_ip": f"192.168.1.{100 + i}",
        "dst_ip": "10.0.0.1",
        "src_port": 12345 + i,
        "dst_port": 80,
        "protocol": 6,
        "start_time": f"2024-01-01T10:00:{i:02d}",
        "end_time": f"2024-01-01T10:00:{i+1:02d}",
        "duration": 1.0,
        "total_bytes": 1024 + i * 100,
        "total_packets": 10 + i,
        "avg_pkt_size": 102.4,
        "pkt_rate": 10.0,
        "mean_iat": 0.1,
        "tcp_flag_counts": "0,1,0,0,1,0,0,0"
    }
    sample_data.append(flow)

# Save to CSV
sample_csv_path = "sample_flows.csv"
df_sample = pd.DataFrame(sample_data)
df_sample.to_csv(sample_csv_path, index=False)

try:
    with open(sample_csv_path, 'rb') as f:
        files = {"file": ("sample_flows.csv", f, "text/csv")}
        response = requests.post(
            f"{API_BASE_URL}/predict/csv",
            files=files,
            data={"model_name": "random_forest"},
            timeout=60
        )
    
    if response.status_code == 200:
        csv_result = response.json()
        print(f"   ✅ CSV prediction successful")
        print(f"   📊 Processed {csv_result['total_flows']} flows")
        print(f"   ⏱️ Processing time: {csv_result['processing_time']:.2f} seconds")
        
        # Show summary
        predictions = csv_result['predictions']
        threat_count = sum(1 for p in predictions if p['prediction'] != 'BENIGN')
        avg_confidence = np.mean([p['confidence'] for p in predictions])
        
        print(f"   🚨 Threats detected: {threat_count}")
        print(f"   📊 Average confidence: {avg_confidence:.3f}")
    else:
        print(f"   ❌ CSV prediction failed: {response.status_code}")
except Exception as e:
    print(f"   ❌ Error in CSV prediction: {e}")
finally:
    # Clean up
    if os.path.exists(sample_csv_path):
        os.remove(sample_csv_path)

# Dashboard demo
print("\n6. Dashboard demo...")
print(f"   🌐 Dashboard URL: {DASHBOARD_URL}")
print(f"   📊 Features available:")
print(f"      - Real-time threat monitoring")
print(f"      - Interactive visualizations")
print(f"      - Single flow prediction")
print(f"      - Batch CSV processing")
print(f"      - Model comparison")
print(f"   💡 Open the dashboard in your browser to explore!")

# Performance testing
print("\n7. Performance testing...")
test_flows = []
for i in range(100):
    flow = sample_flow.copy()
    flow["src_ip"] = f"192.168.1.{100 + (i % 50)}"
    flow["src_port"] = 12345 + i
    test_flows.append(flow)

try:
    start_time = time.time()
    response = requests.post(
        f"{API_BASE_URL}/predict/batch",
        json={"flows": test_flows, "model_name": "random_forest"},
        timeout=60
    )
    end_time = time.time()
    
    if response.status_code == 200:
        result = response.json()
        total_time = end_time - start_time
        throughput = len(test_flows) / total_time
        
        print(f"   ✅ Performance test completed")
        print(f"   📊 Flows processed: {len(test_flows)}")
        print(f"   ⏱️ Total time: {total_time:.2f} seconds")
        print(f"   🚀 Throughput: {throughput:.1f} flows/second")
        print(f"   📈 API processing time: {result['processing_time']:.2f} seconds")
    else:
        print(f"   ❌ Performance test failed: {response.status_code}")
except Exception as e:
    print(f"   ❌ Error in performance test: {e}")

# Docker deployment demo
print("\n8. Docker deployment demo...")
print("   🐳 Docker services available:")
print("      - API server (port 8000)")
print("      - Dashboard (port 8501)")
print("      - Jupyter (port 8888)")
print("      - PostgreSQL (port 5432)")
print("      - Redis (port 6379)")
print("      - Grafana (port 3000)")
print("      - Prometheus (port 9090)")

print("\n   🚀 To start all services:")
print("      make docker-up")

print("\n   📊 To view logs:")
print("      make docker-logs")

print("\n   🛑 To stop services:")
print("      make docker-down")

# Security and safety reminders
print("\n9. Security and safety reminders...")
print("   ⚠️ IMPORTANT SAFETY NOTICES:")
print("      - This system is for educational purposes only")
print("      - Never run on production networks")
print("      - All traffic generation must be in isolated environments")
print("      - Use Docker containers for testing")
print("      - Monitor system resources and performance")

print("\n   🔒 Security best practices:")
print("      - Change default passwords")
print("      - Use HTTPS in production")
print("      - Implement proper authentication")
print("      - Regular security updates")
print("      - Monitor for suspicious activity")

# Summary
print("\n📋 Deployment Demo Summary:")
print("=" * 40)
print("✅ API health check completed")
print("✅ Model listing successful")
print("✅ Single flow prediction working")
print("✅ Batch prediction working")
print("✅ CSV prediction working")
print("✅ Performance testing completed")
print("✅ Dashboard accessible")
print("✅ Docker services ready")

print(f"\n🎯 Next Steps:")
print(f"   1. Explore the dashboard at {DASHBOARD_URL}")
print(f"   2. Test with your own data")
print(f"   3. Set up monitoring and alerting")
print(f"   4. Deploy to production (with proper security)")

print(f"\n📚 Documentation:")
print(f"   - API docs: {API_BASE_URL}/docs")
print(f"   - README: ../README.md")
print(f"   - Notebooks: ../notebooks/")

print("✅ Deployment demo completed successfully!")
