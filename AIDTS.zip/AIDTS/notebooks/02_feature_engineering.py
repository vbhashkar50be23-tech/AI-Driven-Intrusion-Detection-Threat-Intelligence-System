"""
AIDTIS - Feature Engineering Notebook
Convert this to Jupyter notebook for interactive execution
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
import sys
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Add src to path
sys.path.append('../src')

# Import AIDTIS modules
from utils.feature_engineering import FeatureEngineer, create_feature_engineering_pipeline

# Set up plotting
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

print("✅ Libraries imported successfully")

# Load data
train_file = "../data/splits/train.csv"
val_file = "../data/splits/val.csv"
test_file = "../data/splits/test.csv"

if os.path.exists(train_file):
    train_df = pd.read_csv(train_file)
    val_df = pd.read_csv(val_file)
    test_df = pd.read_csv(test_file)
    
    print(f"📊 Loaded data:")
    print(f"   Train: {len(train_df)} samples")
    print(f"   Validation: {len(val_df)} samples")
    print(f"   Test: {len(test_df)} samples")
else:
    print("❌ Data files not found. Please run notebook 01 first.")

# Initialize feature engineer
feature_engineer = FeatureEngineer()

# Fit and transform training data
print("🔧 Fitting feature engineering pipeline...")
train_transformed = feature_engineer.fit_transform(train_df)

# Transform validation and test data
print("🔧 Transforming validation and test data...")
val_transformed = feature_engineer.transform(val_df)
test_transformed = feature_engineer.transform(test_df)

print(f"✅ Feature engineering completed:")
print(f"   Original features: {len(train_df.columns)}")
print(f"   Engineered features: {len(feature_engineer.get_feature_names())}")

# Save transformed data
output_dir = "../data/processed"
os.makedirs(output_dir, exist_ok=True)

train_transformed.to_csv(f"{output_dir}/train_processed.csv", index=False)
val_transformed.to_csv(f"{output_dir}/val_processed.csv", index=False)
test_transformed.to_csv(f"{output_dir}/test_processed.csv", index=False)

# Save feature pipeline
feature_engineer.save_pipeline(f"{output_dir}/feature_pipeline.pkl")

print(f"💾 Saved processed data to: {output_dir}")

# Feature analysis
print("📊 Feature Analysis:")
print(f"   Feature names: {feature_engineer.get_feature_names()[:10]}...")  # Show first 10

# Visualize feature distributions
numerical_features = train_transformed.select_dtypes(include=[np.number]).columns.tolist()
numerical_features = [col for col in numerical_features if col not in ['flow_id']]

plt.figure(figsize=(15, 10))
n_features = min(12, len(numerical_features))
n_cols = 3
n_rows = (n_features + n_cols - 1) // n_cols

for i, feature in enumerate(numerical_features[:n_features]):
    plt.subplot(n_rows, n_cols, i + 1)
    plt.hist(train_transformed[feature], bins=50, alpha=0.7)
    plt.title(feature)
    plt.xlabel('Value')
    plt.ylabel('Frequency')

plt.tight_layout()
plt.savefig(f"{output_dir}/feature_distributions.png", dpi=300, bbox_inches='tight')
plt.show()

print("✅ Feature engineering notebook completed!")
