"""
AIDTIS - Model Training and Evaluation Notebook
Convert this to Jupyter notebook for interactive execution
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
import sys
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Add src to path
sys.path.append('../src')

# Import AIDTIS modules
from models.train_model import train_intrusion_detection_models, ModelTrainer

# Set up plotting
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

print("✅ Libraries imported successfully")

# Load processed data
train_file = "../data/processed/train_processed.csv"
val_file = "../data/processed/val_processed.csv"
test_file = "../data/processed/test_processed.csv"

if os.path.exists(train_file):
    train_df = pd.read_csv(train_file)
    val_df = pd.read_csv(val_file)
    test_df = pd.read_csv(test_file)
    
    print(f"📊 Loaded processed data:")
    print(f"   Train: {len(train_df)} samples")
    print(f"   Validation: {len(val_df)} samples")
    print(f"   Test: {len(test_df)} samples")
else:
    print("❌ Processed data files not found. Please run notebook 02 first.")

# Training configuration
config = {
    'supervised_algorithms': ['random_forest', 'xgboost', 'lightgbm'],
    'unsupervised_algorithms': ['isolation_forest', 'autoencoder'],
    'hyperparameter_tuning': True,
    'cv_folds': 5,
    'random_state': 42,
    'test_size': 0.2,
    'val_size': 0.1,
    'n_trials': 20,  # Reduced for demo
    'output_dir': '../models'
}

# Train models
print("🚀 Starting model training...")
results = train_intrusion_detection_models(
    train_file, val_file, test_file, 
    config['output_dir'], config
)

print("✅ Model training completed!")

# Display results
print("📊 Model Performance Summary:")
print("=" * 50)

for model_name, metrics in results.items():
    print(f"\n🔹 {model_name.upper()}:")
    print(f"   Accuracy: {metrics['accuracy']:.4f}")
    print(f"   Precision: {metrics['precision']:.4f}")
    print(f"   Recall: {metrics['recall']:.4f}")
    print(f"   F1-Score: {metrics['f1']:.4f}")
    if metrics['roc_auc'] > 0:
        print(f"   ROC-AUC: {metrics['roc_auc']:.4f}")

# Find best model
best_model = max(results.items(), key=lambda x: x[1]['f1'])
print(f"\n🏆 Best Model: {best_model[0]} (F1: {best_model[1]['f1']:.4f})")

# Create performance comparison plot
model_names = list(results.keys())
accuracies = [results[name]['accuracy'] for name in model_names]
f1_scores = [results[name]['f1'] for name in model_names]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

# Accuracy comparison
ax1.bar(model_names, accuracies, color='skyblue', alpha=0.7)
ax1.set_title('Model Accuracy Comparison')
ax1.set_ylabel('Accuracy')
ax1.set_ylim(0, 1)
for i, v in enumerate(accuracies):
    ax1.text(i, v + 0.01, f'{v:.3f}', ha='center', va='bottom')

# F1-Score comparison
ax2.bar(model_names, f1_scores, color='lightcoral', alpha=0.7)
ax2.set_title('Model F1-Score Comparison')
ax2.set_ylabel('F1-Score')
ax2.set_ylim(0, 1)
for i, v in enumerate(f1_scores):
    ax2.text(i, v + 0.01, f'{v:.3f}', ha='center', va='bottom')

plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(f"{config['output_dir']}/model_comparison.png", dpi=300, bbox_inches='tight')
plt.show()

# Confusion matrix for best model
from sklearn.metrics import confusion_matrix
import seaborn as sns

best_predictions = best_model[1]['predictions']
y_test = test_df['label']

# Create confusion matrix
cm = confusion_matrix(y_test, best_predictions)
plt.figure(figsize=(10, 8))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=np.unique(y_test), 
            yticklabels=np.unique(y_test))
plt.title(f'Confusion Matrix - {best_model[0]}')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.tight_layout()
plt.savefig(f"{config['output_dir']}/confusion_matrix_{best_model[0]}.png", dpi=300, bbox_inches='tight')
plt.show()

# Feature importance for tree-based models
if best_model[0] in ['random_forest', 'xgboost', 'lightgbm']:
    try:
        # Load the best model to get feature importance
        import joblib
        model_path = f"{config['output_dir']}/{best_model[0]}_model.joblib"
        model_data = joblib.load(model_path)
        
        if hasattr(model_data['model'], 'feature_importances_'):
            feature_importance = model_data['model'].feature_importances_
            feature_names = model_data['feature_names']
            
            # Get top 20 features
            importance_df = pd.DataFrame({
                'feature': feature_names,
                'importance': feature_importance
            }).sort_values('importance', ascending=False).head(20)
            
            plt.figure(figsize=(12, 8))
            sns.barplot(data=importance_df, x='importance', y='feature')
            plt.title(f'Top 20 Feature Importance - {best_model[0]}')
            plt.xlabel('Importance')
            plt.tight_layout()
            plt.savefig(f"{config['output_dir']}/feature_importance_{best_model[0]}.png", dpi=300, bbox_inches='tight')
            plt.show()
            
    except Exception as e:
        print(f"Could not generate feature importance plot: {e}")

# Model evaluation summary
print("\n📋 Model Evaluation Summary:")
print("=" * 50)
print(f"✅ Trained {len(results)} models")
print(f"✅ Best model: {best_model[0]}")
print(f"✅ Best F1-score: {best_model[1]['f1']:.4f}")
print(f"✅ Models saved to: {config['output_dir']}")
print(f"✅ Evaluation reports generated")

print(f"\n🚀 Next Steps:")
print(f"   1. Deploy the best model using the API")
print(f"   2. Set up monitoring and alerting")
print(f"   3. Run deployment demo (notebook 04)")

print(f"\n⚠️ Safety Reminder:")
print(f"   - Models are trained on historical data")
print(f"   - Regular retraining recommended")
print(f"   - Monitor for model drift in production")

print("✅ Model training and evaluation completed!")
